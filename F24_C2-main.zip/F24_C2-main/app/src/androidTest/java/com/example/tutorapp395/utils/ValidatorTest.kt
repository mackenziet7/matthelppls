package com.example.tutorapp395.utils

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.ZoneId

@RunWith(AndroidJUnit4::class)
class ValidatorTest {

    // Test for validateDateOfBirth
    @Test
    fun validateDateOfBirth() {
        // should return False for null dates
        val result = Validator.validateDateOfBirth(null)
        assertEquals(false, result.status)

        // should return False for future dates
        val futureDate =
            LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant()
                .toEpochMilli()
        val result2 = Validator.validateDateOfBirth(futureDate)
        assertEquals(false, result2.status)

        // should return True for today's date
        val today = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val result3 = Validator.validateDateOfBirth(today)
        assertEquals(true, result3.status)

        // should return true for past date
        val pastDate =
            LocalDate.now().minusYears(20).atStartOfDay(ZoneId.systemDefault()).toInstant()
                .toEpochMilli()
        val result4 = Validator.validateDateOfBirth(pastDate)
        assertEquals(true, result4.status)
    }

    // Test for validatePhoneNumber
    @Test
    fun validatePhoneNumber() {
        // should return True for a valid 10-digit phone number
        val result = Validator.validatePhoneNumber("1234567890")
        assertEquals(true, result.status)

        // should return False for a phone number with incorrect length
        val result2 = Validator.validatePhoneNumber("12345")
        assertEquals(false, result2.status)

        // should return False for an empty phone number
        val result3 = Validator.validatePhoneNumber("")
        assertEquals(false, result3.status)
    }

    // Test for validateEmail
    @Test
    fun validateEmail() {
        // should return True for non-empty email
        val result = Validator.validateEmail("test@example.com")
        assertEquals(true, result.status)

        // should return False for an empty email
        val result2 = Validator.validateEmail("")
        assertEquals(false, result2.status)
    }

    // Test for validateUsername
    @Test
    fun validateUsername() {
        // should return True for a non-empty username with length >= 3
        val result = Validator.validateUsername("user123")
        assertEquals(true, result.status)

        // should return False for a username with length < 3
        val result2 = Validator.validateUsername("ab")
        assertEquals(false, result2.status)

        // should return False for an empty username
        val result3 = Validator.validateUsername("")
        assertEquals(false, result3.status)
    }

    // Test for validateUsernameExisting
    @Test
    fun validateUsernameExisting() {
        // should return True if username does not already exist
        val existingUsernames = listOf("user1", "user2", "user3")
        val result = Validator.validateUsernameExisting("newUser", existingUsernames)
        assertEquals(true, result.status)

        // should return False if username already exists
        val result2 = Validator.validateUsernameExisting("user2", existingUsernames)
        assertEquals(false, result2.status)
    }

    // Test for validatePassword
    @Test
    fun validatePassword() {
        // should return True for a valid password (non-empty and length >= 4)
        val result = Validator.validatePassword("password123")
        assertEquals(true, result.status)

        // should return False for a password with length < 4
        val result2 = Validator.validatePassword("abc")
        assertEquals(false, result2.status)

        // should return False for an empty password
        val result3 = Validator.validatePassword("")
        assertEquals(false, result3.status)
    }

    // Test for validatePasswordMatch
    @Test
    fun validatePasswordMatch() {
        // should return True if passwords match
        val result = Validator.validatePasswordMatch("password123", "password123")
        assertEquals(true, result.status)

        // should return False if passwords do not match
        val result2 = Validator.validatePasswordMatch("password123", "differentPassword")
        assertEquals(false, result2.status)
    }
}


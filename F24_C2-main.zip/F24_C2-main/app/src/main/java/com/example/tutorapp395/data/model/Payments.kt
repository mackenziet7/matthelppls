package com.example.tutorapp395.data.model

data class Payments(
    val paymentsId: String, // PK
    val hourlyRate: Float,
    val tutorFee: Float,
    val studentFee: Float,
    val announcementDateTime: String,
    val changeDateTime: String,
    val createdAt: String,
    )


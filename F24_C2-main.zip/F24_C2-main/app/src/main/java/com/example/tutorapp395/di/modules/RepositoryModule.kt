package com.example.tutorapp395.di.modules

import com.example.tutorapp395.data.model.SubjectLevel
import com.example.tutorapp395.data.repository.ChatCloudRepositoryImpl
import com.example.tutorapp395.data.repository.MessageCloudRepositoryImpl
import com.example.tutorapp395.data.repository.QualificationsCloudRepositoryImpl
import com.example.tutorapp395.data.repository.SessionCloudRepositoryImpl
import com.example.tutorapp395.data.repository.SessionRequestCloudRepositoryImpl
import com.example.tutorapp395.data.repository.StudentAvailabilityCloudRepositoryImpl
import com.example.tutorapp395.data.repository.SubjectLevelCloudRepositoryImpl
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.data.repository.UserCloudRepositoryImpl
import com.example.tutorapp395.domain.repository.ChatRepository
import com.example.tutorapp395.domain.repository.MessageRepository
import com.example.tutorapp395.domain.repository.QualificationsRepository
import com.example.tutorapp395.domain.repository.SessionRepository
import com.example.tutorapp395.domain.repository.SessionRequestRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.domain.repository.SubjectLevelRepository
import com.example.tutorapp395.domain.usecase.FindATutorUseCase
import com.example.tutorapp395.domain.usecase.RegisterUseCase
import com.example.tutorapp395.domain.usecase.UserAnalyticsUseCase
import com.example.tutorapp395.domain.usecase.ViewUserAccountsUseCase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.auth.User
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideUserRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): UserRepository {
        return UserCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideSessionRequestRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): SessionRequestRepository {
        return SessionRequestCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideSessionRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): SessionRepository {
        return SessionCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideQualificationsRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): QualificationsRepository {
        return QualificationsCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideSubjectLevelRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): SubjectLevelRepository {
        return SubjectLevelCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideStudentAvailabilityRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): StudentAvailabilityRepository {
        return StudentAvailabilityCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideChatRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): ChatRepository {
        return ChatCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideMessageRepository(
        firebaseFirestore: FirebaseFirestore,
        @IoDispatcher ioDispatcher: CoroutineDispatcher,
    ): MessageRepository {
        return MessageCloudRepositoryImpl(
            cloudDb = firebaseFirestore,
            ioDispatcher = ioDispatcher,
        )
    }

    @Provides
    @Singleton
    fun provideRegisterUseCase(repository: UserRepository): RegisterUseCase {
        return RegisterUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideViewUserAccountsUseCase(repository: UserRepository): ViewUserAccountsUseCase {
        return ViewUserAccountsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideUserAnalyticsUseCase(repository: UserRepository): UserAnalyticsUseCase {
        return UserAnalyticsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideFindATutorCase(
        repository1: SessionRequestRepository,
        repository2: SessionRepository,
        repository3: StudentAvailabilityRepository,
    ): FindATutorUseCase {
        return FindATutorUseCase(repository1, repository2, repository3)
    }
}
package com.example.tutorapp395.domain

import android.net.Network
import com.example.tutorapp395.data.network.models.NetworkUser


sealed class Result<out T: Any> {
    data class Success<out T: Any>(val data: T): Result<T>()
    data class Failure(val exception: Exception): Result<Nothing>()
}
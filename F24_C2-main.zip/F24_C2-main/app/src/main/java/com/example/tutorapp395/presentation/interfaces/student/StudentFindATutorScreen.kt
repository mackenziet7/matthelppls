package com.example.tutorapp395.presentation.interfaces.student

import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.FilterNone
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.TypeSpecimen
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.DatePickerDocked
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.presentation.interfaces.components.DropdownMenuComponent
import com.example.tutorapp395.presentation.interfaces.components.NumberPickerComponent
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.RegisterUiEvent
import com.example.tutorapp395.presentation.interfaces.student.viewmodel.FindATutorUiEvent
import com.example.tutorapp395.presentation.interfaces.student.viewmodel.StudentViewModel
import com.example.tutorapp395.presentation.navigation.common.StudentFindATutor
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import com.example.tutorapp395.presentation.navigation.common.TutorProfile
import kotlinx.coroutines.time.delay
import java.time.Duration

@Composable
fun StudentFindATutorScreen(navController: NavController){
    val context = LocalContext.current
    val weekDays = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    var selectedDay by remember { mutableStateOf(0) }

    var availability by remember { mutableStateOf(mutableMapOf<String, String>()) }

    // State for selected start and end time
    var startTime by remember { mutableStateOf("Select Start Time") }
    var endTime by remember { mutableStateOf("Select End Time") }

    // States for time picker dialog visibility
    var showStartTimePicker by remember { mutableStateOf(false) }
    var showEndTimePicker by remember { mutableStateOf(false) }

    // Column Composable,
    Box{
        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = 90.dp)
              //  .background(Color.White)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 40.dp),
            // Parameters set to place the items in center
            horizontalAlignment = Alignment.CenterHorizontally,
           // verticalArrangement = Arrangement.Center
        ) {
            DatePickerDocked(
                onDateSelected = {},
                false,
                "Start Date"
            )
            DatePickerDocked(
                onDateSelected = {},
                false,
                "End Date"
            )
            DropdownMenuComponent(
                listOf("Math", "Science"),
                icon2 = Icons.Default.School,
                title = "Subject")

            DropdownMenuComponent(
                listOf("Preschool", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "College/University"),
                icon2 = Icons.Default.Numbers,
                title = "Grade Level")


            // Total Sessions - max. 1 session per day
            NumberPickerComponent("Total Sessions: ")

            // Session duration - recommended 1-2 hours per session
            NumberPickerComponent("Session Duration (Hour): ")

            TabRow(selectedTabIndex = selectedDay, modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 10.dp)) {
                weekDays.forEachIndexed { index, day ->
                    Tab(selected = selectedDay == index, onClick = { selectedDay = index }) {
                        Text(text = day.first().toString(), fontSize = 18.sp, modifier = Modifier.padding(bottom = 5.dp))
                    }
                }
            }

            // Time inputs for setting availability
            Text(text = "From", fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))
            TextButton(onClick = { showStartTimePicker = true }) {
                Text(text = startTime)
            }
            Text(text = "To", fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))
            TextButton(onClick = { showEndTimePicker = true }) {
                Text(text = endTime)
            }


            TextButton(
                onClick = {
                    // Save availability for the selected day
                    availability[weekDays[selectedDay]] = "$startTime - $endTime"
                },
                modifier = Modifier.border(width = 2.dp, color = Color.DarkGray, shape = RoundedCornerShape(8.dp))
            ) {
                Text(text = "Save")
            }


            //Text(text = "Preferences", fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))

//            LazyColumn {
//                items(5) { item ->
//                    Row(
//                        modifier = Modifier
//                            .padding(vertical = 5.dp)
//                            .height(150.dp)
//                            .fillParentMaxWidth()
//                            .shadow(5.dp, RoundedCornerShape(28.dp))
//                            .clip(RoundedCornerShape(28.dp))
//                            .background(MaterialTheme.colorScheme.background)
//
//                    ) {}
//
//                }
//            }
            Spacer(modifier = Modifier.height(10.dp)) // Space before login button


            LargeButtonComponent(
                "Submit",
                onButtonClicked = {
                    //Toast.makeText(context, "Looking for a tutor...", Toast.LENGTH_SHORT).show() // Error message

                    //studentViewModel.sendFindATutorEvent(event = FindATutorUiEvent.submitClicked)
                    Toast.makeText(context, "Found a tutor!", Toast.LENGTH_SHORT).show() // Error message
                    navController.navigate(route = TutorProfile)

                },
                true)

            // Start Time Picker Dialog
            if (showStartTimePicker) {
                TimePickerDialog(
                    LocalContext.current,
                    { _, hourOfDay, minute ->
                        // Convert to 12-hour format for display
                        val formattedHour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                        val amPm = if (hourOfDay < 12) "AM" else "PM"
                        startTime = String.format("%02d:%02d %s", formattedHour, minute, amPm) // Format the time
                        showStartTimePicker = false
                    },
                    0, 0, false // Default to 0:00 hours in 12-hour format
                ).show()
            }

            // End Time Picker Dialog
            if (showEndTimePicker) {
                TimePickerDialog(
                    LocalContext.current,
                    { _, hourOfDay, minute ->
                        // Convert to 12-hour format for display
                        val formattedHour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                        val amPm = if (hourOfDay < 12) "AM" else "PM"
                        endTime = String.format("%02d:%02d %s", formattedHour, minute, amPm) // Format the time
                        showEndTimePicker = false
                    },
                    0, 0, false // Default to 0:00 hours in 12-hour format
                ).show()
            }
        }

        // Top Bar Navigation
        SubTopBar(navController, "Find A Tutor")


    }
}
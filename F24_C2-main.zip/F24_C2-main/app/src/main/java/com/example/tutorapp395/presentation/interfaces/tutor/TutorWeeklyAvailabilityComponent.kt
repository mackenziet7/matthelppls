package com.example.tutorapp395.presentation.interfaces.tutor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tutorapp395.presentation.navigation.common.TutorWeeklySubmission


@Composable
fun TutorWeeklyAvailabilityComponent(navController: NavController) {
    val weekdays = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {navController.navigate(route = TutorWeeklySubmission)
            }
            .background(color = MaterialTheme.colorScheme.primary)
            .padding(vertical = 20.dp, horizontal = 20.dp),

        horizontalArrangement = Arrangement.SpaceBetween

    ){
        Text(text = "Weekly Availability")
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
            contentDescription = null,
            modifier = Modifier
                .padding(start = 16.dp, end = 8.dp)
                .size(27.dp)
        )
    }
    // Column Composable,
    LazyRow(
        modifier = Modifier,
        verticalAlignment = Alignment.CenterVertically,
       // horizontalArrangement = Arrangement
    ) {
        items(weekdays) { item ->
            Column(
                modifier = Modifier
                  //  .height(150.dp)
                    .width(100.dp)
                    .padding(5.dp)
                 //   .fillParentMaxWidth()
            ){
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Text(text = item)
                    Text(text = "Start Time")
                    Text(text = "End Time")
                }


            }
        }
    }
}
package com.example.tutorapp395.presentation.navigation.admin

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.interfaces.admin.AdminMainScreen
import com.example.tutorapp395.presentation.interfaces.admin.AdminSetupNewAccountScreen
import com.example.tutorapp395.presentation.navigation.common.AdminMain
import com.example.tutorapp395.presentation.navigation.common.Profile
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.AdminViewModel
import com.example.tutorapp395.presentation.navigation.common.ProfileScreen
import com.example.tutorapp395.presentation.navigation.common.viewmodel.UserUiEvent
import com.example.tutorapp395.presentation.navigation.common.viewmodel.UserViewModel
import com.example.tutorapp395.presentation.navigation.common.Chat


@Composable
fun AdminNavGraph(navController: NavHostController, userId: String) {
    val adminViewModel: AdminViewModel = hiltViewModel()
    val userViewModel: UserViewModel = hiltViewModel()
    userViewModel.setUserId(userId)
    val modifier = Modifier
        .padding(top = 100.dp)
        .fillMaxSize()
    NavHost(
        navController = navController,
        startDestination = AdminMain
    ) {
        composable<AdminMain> {
            AdminMainScreen(navController)
        }
        composable<Profile> {
            userViewModel.sendEvent(event = UserUiEvent.OnProfileClicked)
            ProfileScreen(userViewModel, navController, modifier)
        }
        composable<AdminCreateNewAccount> {
            AdminSetupNewAccountScreen(navController, adminViewModel, modifier)
        }


    }

}

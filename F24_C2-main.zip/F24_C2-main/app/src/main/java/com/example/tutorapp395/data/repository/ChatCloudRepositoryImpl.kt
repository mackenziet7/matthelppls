package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.Chat
import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.network.models.NetworkChat
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkStudentAvailability
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.ChatRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_CHAT
import com.example.tutorapp395.utils.COLLECTION_PATH_STUDENT_AVAILABILITY
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class ChatCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): ChatRepository {
    override fun getChats(): Flow<List<NetworkChat>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertChat(chat: Chat): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_CHAT).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkChat = chat.copy(chatId = id).asNetworkModel()
                Log.d(TAG, "$networkChat")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_CHAT)
                        .document(id)
                        .set(networkChat)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }

    override suspend fun getAllChatByUserId(): Result<List<NetworkChat?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_CHAT)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkChat>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteChat(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_CHAT)
                        .document(id)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateChat(chat: Chat): Result<Unit> {
        return try {
            val modifiedChat = chat.asNetworkModel()
            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    modifiedChat.chatId?.let {
                        cloudDb.collection(COLLECTION_PATH_CHAT)
                            .document(it)
                            .set(modifiedChat)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
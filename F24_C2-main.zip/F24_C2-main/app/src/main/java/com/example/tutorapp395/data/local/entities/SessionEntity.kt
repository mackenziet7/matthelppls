package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Session
import java.util.UUID

@Entity(tableName = "session", foreignKeys = [ForeignKey(
    entity = SessionRequestEntity::class,
    parentColumns = arrayOf("sessionRequestId"),
    childColumns = arrayOf("sessionRequestId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class SessionEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val sessionId: String, // PK
    @ColumnInfo(index = true)
    val startDateTime: String,
    @ColumnInfo(index = true)
    val endDateTime: String,
    @ColumnInfo(index = true)
    val cancelledDate: String,
    @ColumnInfo(index = true)
    val cancelAccommodation: String,
    @ColumnInfo(index = true)
    val sessionRequestId: String, //FK
)

fun SessionEntity.asExternalModel() = Session(
    sessionId = sessionId,
    startDateTime = startDateTime,
    endDateTime = endDateTime,
    cancelledDate = cancelledDate,
    cancelAccommodation = cancelAccommodation,
    sessionRequestId = sessionId, // Foreign Key
)


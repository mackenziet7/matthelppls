package com.example.tutorapp395.presentation.interfaces.admin.viewmodel

import android.view.View

sealed class CreateAccountUiEvent {

    // Register Account / Change
    data class UsernameChanged( val username: String) : CreateAccountUiEvent()
    data class EmailChanged( val email: String) : CreateAccountUiEvent()
    data class PasswordChanged( val password: String) : CreateAccountUiEvent()
    data class Password2Changed( val password2: String) : CreateAccountUiEvent()
    data class FirstNameChanged( val firstName: String) : CreateAccountUiEvent()
    data class LastNameChanged( val lastName: String) : CreateAccountUiEvent()
    data class AdminTutorChanged(val isAdmin: Boolean) : CreateAccountUiEvent()


    // Buttons
    object CreateAccountButtonClicked : CreateAccountUiEvent()
    object Reset : CreateAccountUiEvent()
}

sealed class ViewAccountsUiEvent {
    object ShowAllUserAccounts: ViewAccountsUiEvent()
}

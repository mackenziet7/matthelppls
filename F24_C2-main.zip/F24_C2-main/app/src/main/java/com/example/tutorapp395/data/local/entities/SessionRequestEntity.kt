package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.SessionRequest
import java.util.UUID

@Entity(tableName = "sessionRequest", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("tutorUserId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
), ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("studentUserId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE)
])data class SessionRequestEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val sessionRequestId: String, // PK
    @ColumnInfo(index = true)
    val requestDateTime: String,
    @ColumnInfo(index = true)
    val acceptDateTime: String,
    @ColumnInfo(index = true)
    val confirmDateTime: String,
    @ColumnInfo(index = true)
    val startDateTime: String,
    @ColumnInfo(index = true)
    val endDateTime: String,
    @ColumnInfo(index = true)
    val totalHours: Int,
    @ColumnInfo(index = true)
    val totalCost: Float,
    @ColumnInfo(index = true)
    val gradeLevel: String,
    @ColumnInfo(index = true)
    val subject: String, // FK
    @ColumnInfo(index = true)
    val tutorUserId: String, // FK - userId
    @ColumnInfo(index = true)
    val studentUserId: String, // FK - userId
)

//fun SessionRequestEntity.asExternalModel() = SessionRequest(
//    sessionRequestId = sessionRequestId, // PK
//    requestDateTime = requestDateTime,
//    acceptDateTime = acceptDateTime,
//    confirmDateTime = confirmDateTime,
//    startDateTime = startDateTime,
//    endDateTime = endDateTime,
//    totalHours = totalHours,
//    totalCost = totalCost,
//    gradeLevel = gradeLevel,
//    subject = subject,
//    tutorUserId = tutorUserId, // FK - userId
//    studentUserId = tutorUserId, // FK - userId,
//    studentColorLabel =
//)

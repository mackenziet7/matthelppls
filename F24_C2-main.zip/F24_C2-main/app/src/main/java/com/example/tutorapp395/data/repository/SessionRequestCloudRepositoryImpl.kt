package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.utils.COLLECTION_PATH_USER
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.SessionRequestRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_SESSION_REQUEST
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class SessionRequestCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): SessionRequestRepository {
    override fun getSessionRequests(): Flow<List<NetworkSessionRequest>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertSessionRequest(sessionRequest: SessionRequest): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkSessionRequest = sessionRequest.copy(sessionRequestId = id).asNetworkModel()
                Log.d(TAG, "$networkSessionRequest")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST)
                        .document(id)
                        .set(networkSessionRequest)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }

    override suspend fun getAllSessionRequests(): Result<List<NetworkSessionRequest?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkSessionRequest>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun getSessionRequestById(id: String): Result<List<NetworkSessionRequest?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST)
                        .whereEqualTo("sessionRequestId", id)
                        .limit(1)
                        .get()
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkSessionRequest>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteSessionRequest(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST)
                        .document(id)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateSessionRequest(sessionRequest: SessionRequest): Result<Unit> {
        return try {
            val modifiedSessionRequest = sessionRequest.asNetworkModel()
            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    modifiedSessionRequest.sessionRequestId?.let {
                        cloudDb.collection(COLLECTION_PATH_SESSION_REQUEST)
                            .document(it)
                            .set(modifiedSessionRequest)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
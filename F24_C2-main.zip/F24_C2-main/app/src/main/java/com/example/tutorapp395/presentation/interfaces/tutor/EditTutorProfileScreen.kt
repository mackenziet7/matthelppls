package com.example.tutorapp395.presentation.interfaces.tutor

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Label
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tutorapp395.domain.SubjectsAndGradeLevels
import com.example.tutorapp395.interfaces.components.FullNameTextComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent2
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.MediumButtonComponent
import com.example.tutorapp395.interfaces.components.NormalButtonComponent
import com.example.tutorapp395.interfaces.components.SubHeaderTextComponent
import com.example.tutorapp395.presentation.interfaces.components.DropdownMenuComponent
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import com.example.tutorapp395.presentation.uistate.ContactsItem

@Composable
fun EditTutorProfileScreen(navController: NavController, modifier: Modifier){
    val index = 0
    val labels = listOf(
        "Math", "Science", "Social Studies"
    )
    val qualifications = listOf(
        ContactsItem("X", "University", "Bachelor of Education", "2012-2015", "Math 12", "12", "123"),
        ContactsItem("Y", "Institute", "English Diploma", "2011", "Math 12", "12", "123"),
    )

    Box {
        Column(
            modifier = modifier
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                ContentHeader("Subjects")
                IconButtonComponent(Icons.Default.Add, onButtonClicked = {}, title = "")
            }
            for (item in labels) {
                Row(
                    modifier = Modifier
                        .padding(vertical = 5.dp)
                        .shadow(5.dp, RoundedCornerShape(28.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.background)
                        .padding(20.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            FullNameTextComponent(item, "")
                            val grades = listOf("9-12", "College/University")
                            for (item in grades) {
                                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                    LabelTextComponent(item)
                                }
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.Top,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            IconButtonComponent2(
                                Icons.Default.Delete,
                                "Delete",
                                onButtonClicked = {}
                            )

                            IconButtonComponent2(
                                Icons.Default.Edit,
                                "Edit",
                                onButtonClicked = {}
                            )
                        }

                    }
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                ContentHeader("Qualifications")
                IconButtonComponent(Icons.Default.Add, onButtonClicked = {}, title = "")
            }

            for (item in qualifications) {
                Row(
                    modifier = Modifier
                        .padding(vertical = 5.dp)
                        .shadow(5.dp, RoundedCornerShape(28.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.background)
                        .padding(20.dp)

                ) {
                    Column(
                        modifier = Modifier
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth() ,
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                FullNameTextComponent(item.firstName, item.lastName)
                                Spacer(modifier = Modifier.height(5.dp)) // Space before login button
                                Text(item.lastDateTime)
                                Text(item.lastMessage, color = Color.Black, maxLines = 2)
                                Spacer(modifier = Modifier.height(5.dp)) // Space before login button
                            }
                            Column(
                                verticalArrangement = Arrangement.Top,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ){
                                IconButtonComponent2(
                                    Icons.Default.Delete,
                                    "Delete",
                                    onButtonClicked = {}
                                )
                                IconButtonComponent2(
                                    Icons.Default.Edit,
                                    "Edit",
                                    onButtonClicked = {}
                                )
                            }
                        }


                    }

                }
            }

        }

        SubTopBar(navController, "Edit Profile")

    }

}
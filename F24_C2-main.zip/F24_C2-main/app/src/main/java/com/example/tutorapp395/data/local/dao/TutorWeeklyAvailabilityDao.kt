package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.TutorWeeklyAvailabilityEntity
import com.example.tutorapp395.data.model.TutorWeeklyAvailability
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface TutorWeeklyAvailabilityDao {
    @Query("SELECT * FROM tutorWeeklyAvailability")
    fun getAll(): List<TutorWeeklyAvailabilityEntity>

    @Insert
    fun insertAll(vararg tutorWeeklyAvailability: TutorWeeklyAvailabilityEntity)

    @Delete
    fun delete(tutorWeeklyAvailability: TutorWeeklyAvailabilityEntity)

    @Update
    fun update(tutorWeeklyAvailability: TutorWeeklyAvailabilityEntity)
    
    @Query("DELETE FROM tutorWeeklyAvailability")
    fun deleteAllValuesInTable()
}

package com.example.tutorapp395.data.network.models

import androidx.room.PrimaryKey
import com.example.tutorapp395.data.local.entities.SubjectLevelEntity
import kotlinx.serialization.Serializable

@Serializable
data class NetworkSubjectLevel(
    val subjectLevelId: String? = null,
    val userId: String? = null,
    val subject: String? = null, // FK
    val gradeLevels: List<String>? = null,
    val sortIndex: Int? = null,
    )

//fun NetworkSubjectLevel.asEntity() = SubjectLevelEntity(
//    subjectLevelId = subjectLevelId, // PK
//    subjectId = subjectId, // PK, FK
//    gradeLevels = gradeLevels,
//)

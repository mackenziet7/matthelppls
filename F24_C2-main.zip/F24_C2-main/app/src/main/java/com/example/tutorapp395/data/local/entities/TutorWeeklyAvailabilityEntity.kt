package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.TutorWeeklyAvailability

@Entity(tableName = "tutorWeeklyAvailability", foreignKeys = [ForeignKey(
    entity = TutorAvailabilityEntity::class,
    parentColumns = arrayOf("tutorAvailabilityId"),
    childColumns = arrayOf("tutorAvailabilityId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class TutorWeeklyAvailabilityEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val weeklyAvailabilityId: String, // PK
    @ColumnInfo(index = true)
    val weekday: String,
    @ColumnInfo(index = true)
    val startTime: String,
    @ColumnInfo(index = true)
    val endTime: String,
    @ColumnInfo(index = true)
    val tutorAvailabilityId: String, // FK
)

fun TutorWeeklyAvailabilityEntity.asExternalModel() = TutorWeeklyAvailability(
    weeklyAvailabilityId = weeklyAvailabilityId, // PK
    weekday = weekday,
    startTime = startTime,
    endTime = endTime,
    tutorAvailabilityId = tutorAvailabilityId,
)
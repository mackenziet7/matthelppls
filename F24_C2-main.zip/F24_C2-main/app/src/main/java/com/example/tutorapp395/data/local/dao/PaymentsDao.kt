package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.PaymentsEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface PaymentsDao {
    @Query("SELECT * FROM payments")
    fun getAll(): List<PaymentsEntity>

    @Insert
    fun insertAll(vararg payments: PaymentsEntity)

    @Delete
    fun delete(payments: PaymentsEntity)

    @Update
    fun update(payments: PaymentsEntity)
    
    @Query("DELETE FROM payments")
    fun deleteAllValuesInTable()
}
package com.example.tutorapp395.interfaces.admin
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent

// a sub-main screen that will display analytics of the app as an admin
@Composable
fun AdminAnalyticsScreen(modifier: Modifier) {

    // Column Composable,
    Column(
        modifier = Modifier
            .padding(top = 100.dp)
            .fillMaxWidth()
            .height(1000.dp)
            .background(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(40.dp))
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),

        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ){
            IconButtonComponent(Icons.Default.Refresh, "", onButtonClicked = {})
        }
        HeaderTextComponent(value = "Total User Accounts: ${null}", textAlign = TextAlign.Start)
        HeaderTextComponent(value = "Total Admin Accounts: ${null}", textAlign = TextAlign.Start)
        HeaderTextComponent(value = "Total Student Accounts: ${null}", textAlign = TextAlign.Start)
        HeaderTextComponent(value = "Total Tutor Accounts: ${null}", textAlign = TextAlign.Start)

    }
}

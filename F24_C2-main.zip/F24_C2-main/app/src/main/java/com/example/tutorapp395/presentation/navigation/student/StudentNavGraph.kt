package com.example.tutorapp395.presentation.navigation.student

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.interfaces.student.StudentMainScreen
import com.example.tutorapp395.presentation.navigation.common.ProfileScreen
import com.example.tutorapp395.presentation.navigation.common.TempTutorProfileScreen
import com.example.tutorapp395.presentation.navigation.common.viewmodel.UserUiEvent
import com.example.tutorapp395.presentation.interfaces.student.StudentFindATutorScreen
import com.example.tutorapp395.presentation.navigation.common.Profile
import com.example.tutorapp395.presentation.navigation.common.StudentFindATutor
import com.example.tutorapp395.presentation.navigation.common.StudentMain
import com.example.tutorapp395.presentation.navigation.common.viewmodel.UserViewModel
import com.example.tutorapp395.presentation.interfaces.student.viewmodel.StudentViewModel
import com.example.tutorapp395.presentation.navigation.common.Chat
import com.example.tutorapp395.presentation.navigation.common.TutorProfile


@Composable
fun StudentNavGraph(navController: NavHostController, userId: String) {
    val studentViewModel: StudentViewModel = hiltViewModel()
    val userViewModel: UserViewModel = hiltViewModel()
    userViewModel.setUserId(userId)

    val modifier = Modifier
        .padding(top = 85.dp)
        .fillMaxSize()
    NavHost(
        navController = navController,
        startDestination = StudentMain
    ) {
        composable<StudentMain> {
            StudentMainScreen(navController)
        }
        composable<Profile> {
            userViewModel.sendEvent(event = UserUiEvent.OnProfileClicked)
            ProfileScreen(userViewModel, navController, modifier)
        }
        composable<StudentFindATutor> {
            StudentFindATutorScreen(navController)
        }
        composable<TutorProfile> {
            TempTutorProfileScreen(navController, "Find A Tutor")
        }

    }

}

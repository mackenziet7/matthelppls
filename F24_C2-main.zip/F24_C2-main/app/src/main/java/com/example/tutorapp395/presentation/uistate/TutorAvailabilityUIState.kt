package com.example.tutorapp395.presentation.uistate

import com.example.tutorapp395.utils.Weekday

data class TutorAvailabilityUIState(
    val updatedOn: String,
    val month: Int,
    val year: Int,
    val tutorWeeklyAvailabilityList: List<TutorWeeklyAvailabilityItem>,
    val tutorUnavailableTimeList: List<TutorUnavailableTimeItem>,
    val subjectsList: List<SubjectLevelItems>
)

data class SubjectLevelItems(
    val subject: String,
    val level: String,
)

data class TutorWeeklyAvailabilityItem(
    val day: Weekday,
    val startTime: String,
    val endTime: String,
)

data class TutorUnavailableTimeItem(
    val startDate: String,
    val endDate: String,
)
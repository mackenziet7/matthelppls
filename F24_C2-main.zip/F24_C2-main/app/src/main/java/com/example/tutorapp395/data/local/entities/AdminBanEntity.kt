package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.app.admin
import com.example.tutorapp395.data.model.AdminBan
import java.util.UUID

@Entity(tableName = "adminBan", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class AdminBanEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val userId: String, // PK, FK
    @ColumnInfo(index = true)
    val adminId: String,
    @ColumnInfo(index = true)
    val banDateTime: String,
    @ColumnInfo(index = true)
    val unbanDateTime: String,
    @ColumnInfo(index = true)
    val reason: String,
    @ColumnInfo(index = true)
    val content: String,
)

fun AdminBanEntity.asExternalModel() = AdminBan(
    userId = userId, // PK, FK
    adminId = adminId,
    banDateTime = banDateTime,
    unbanDateTime = unbanDateTime,
    reason = reason,
    content = content,
)
package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkQualifications

data class Qualifications(
    val qualificationsId: String, // PK
    val degree: String,
    val startDate: String,
    val endDate: String,
    val institute: String,
    val sortIndex: Int,
    val userId: String // FK
)

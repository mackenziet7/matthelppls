package com.example.tutorapp395.data.network.models

import kotlinx.serialization.Serializable

@Serializable
data class NetworkRescheduledSession(
    val cancelledSessionId: String,
    val newSessionId: String
)

//fun NetworkRescheduledSession.asEntity() = RescheduledSessionEntity(
//    cancelledSessionId = cancelledSessionId, //PK, FK -> Session
//    newSessionId = newSessionId
//)

package com.example.tutorapp395.data.model

data class TutorPayout(
    val tutorPayoutId: String, // PK
    val payoutTotal: Float,
    val payoutDateTime: String,
    val paymentStatus: String,
    val sessionId: String // FK
)
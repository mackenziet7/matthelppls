package com.example.tutorapp395.utils

enum class Weekday {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}

enum class AccessLevel {
    ALL_ACCESS, LEVEL_A, LEVEL_B, GENERAL_ACCESS
}

enum class GradeLevel {
    NURSERY_TO_KINDERGARTEN, ONE_TO_THREE, FOUR_TO_SIX, SEVEN_TO_NINE, NINE_TO_TWELVE, UNIVERSITY_AND_COLLEGE
}

enum class ColorLabel {
    GREEN, YELLOW, RED, BLUE, LIGHT_BLUE, PINK, BROWN
}

enum class PaymentStatus {
    PENDING, CANCELLED, CONFIRMED
}

enum class CancelAccommodations {
    FULL_REFUND, RESCHEDULE, NONE, PARTIAL_REFUND, NO_REFUND
}
package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.RescheduledSessionEntity
import com.example.tutorapp395.data.model.RescheduledSession
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.TutorPayout
import com.example.tutorapp395.data.model.TutorWeeklyAvailability
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface RescheduledSessionDao {
    @Query("SELECT * FROM rescheduledSession")
    fun getAll(): List<RescheduledSessionEntity>

    @Insert
    fun insertAll(vararg rescheduledSession: RescheduledSessionEntity)

    @Delete
    fun delete(rescheduledSession: RescheduledSessionEntity)

    @Update
    fun update(rescheduledSession: RescheduledSessionEntity)
    
    @Query("DELETE FROM rescheduledSession")
    fun deleteAllValuesInTable()
}

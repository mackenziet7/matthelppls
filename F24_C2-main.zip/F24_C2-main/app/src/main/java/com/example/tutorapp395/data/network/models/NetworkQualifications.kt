package com.example.tutorapp395.data.network.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.local.entities.QualificationsEntity
import com.example.tutorapp395.data.model.Qualifications
import kotlinx.serialization.Serializable
import java.time.LocalDate

@Serializable
data class NetworkQualifications(
    val qualificationsId: String? = null,
    val degree: String? = null,
    val startDate: String? = null,
    val endDate: String? = null,
    val institute: String? = null,
    val sortIndex: Int? = null,
    val userId: String? = null // FK
)

fun Qualifications.asNetworkModel() = NetworkQualifications(
    qualificationsId = qualificationsId,
    degree = degree,
    startDate = startDate,
    endDate = endDate,
    institute = institute,
    sortIndex = sortIndex,
    userId = userId
)
//
//fun NetworkQualifications.asEntity() = QualificationsEntity(
//    qualificationsId = qualificationsId, // PK
//    degree = degree,
//    startDate = startDate,
//    endDate = endDate,
//    institute = institute,
//    sortIndex = sortIndex,
//    userId = userId // FK
//)
package com.example.tutorapp395.domain

import com.example.tutorapp395.presentation.uistate.CalendarUiState
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.stream.Collectors
import java.util.stream.Stream

/**
 * based on the calender app created by meyta.taliti
 */
class CalendarUseCase {

    val today: LocalDate
        get() {
            return LocalDate.now()
        }

    fun getMonthData(month: YearMonth = YearMonth.now()): CalendarUiState {
        val firstDayOfMonth = month.atDay(1)
        val lastDayOfMonth = month.atEndOfMonth()

        // Create a list to hold the visible dates
        val visibleDates = mutableListOf<LocalDate>()

        // Add the current month's days
        visibleDates.addAll(getDatesBetween(firstDayOfMonth, lastDayOfMonth))

        return toUiModel(visibleDates, today)
    }




    private fun getDatesBetween(startDate: LocalDate, endDate: LocalDate): List<LocalDate> {
        val numOfDays = ChronoUnit.DAYS.between(startDate, endDate) + 1 // Add 1 to include the end date
        return Stream.iterate(startDate) { date ->
            date.plusDays(1)
        }
            .limit(numOfDays) // Ensure we include the end date
            .collect(Collectors.toList())
    }


    private fun toUiModel(
        dateList: List<LocalDate>,
        lastSelectedDate: LocalDate
    ): CalendarUiState {
        return CalendarUiState(
            selectedDate = toItemUiModel(lastSelectedDate, true),
            visibleDates = dateList.map {
                toItemUiModel(it, it.isEqual(lastSelectedDate))
            },
        )
    }

    private fun toItemUiModel(date: LocalDate, isSelectedDate: Boolean) = CalendarUiState.Date(
        isSelected = isSelectedDate,
        isToday = date.isEqual(today),
        date = date,
    )
}
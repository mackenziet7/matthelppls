package com.example.tutorapp395.data.local

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.tutorapp395.data.local.dao.AdminBanDao
import com.example.tutorapp395.data.local.dao.ChatDao
import com.example.tutorapp395.data.local.dao.MessageDao
import com.example.tutorapp395.data.local.dao.PaymentsDao
import com.example.tutorapp395.data.local.dao.QualificationsDao
import com.example.tutorapp395.data.local.dao.RefundedSessionDao
import com.example.tutorapp395.data.local.dao.RescheduledSessionDao
import com.example.tutorapp395.data.local.dao.SessionDao
import com.example.tutorapp395.data.local.dao.SessionDeclinedDao
import com.example.tutorapp395.data.local.dao.SubjectLevelDao
import com.example.tutorapp395.data.local.dao.TutorAvailabilityDao
import com.example.tutorapp395.data.local.dao.TutorDao
import com.example.tutorapp395.data.local.dao.TutorPayoutDao
import com.example.tutorapp395.data.local.dao.TutorUnavailableDatesDao
import com.example.tutorapp395.data.local.dao.TutorWeeklyAvailabilityDao
import com.example.tutorapp395.data.local.dao.UserDao
import com.example.tutorapp395.data.local.entities.AdminBanEntity
import com.example.tutorapp395.data.local.entities.ChatEntity
import com.example.tutorapp395.data.local.entities.MessageEntity
import com.example.tutorapp395.data.local.entities.PaymentsEntity
import com.example.tutorapp395.data.local.entities.QualificationsEntity
import com.example.tutorapp395.data.local.entities.RefundedSessionEntity
import com.example.tutorapp395.data.local.entities.RescheduledSessionEntity
import com.example.tutorapp395.data.local.entities.SessionDeclinedEntity
import com.example.tutorapp395.data.local.entities.SessionEntity
import com.example.tutorapp395.data.local.entities.SessionRequestEntity
import com.example.tutorapp395.data.local.entities.StudentAvailabilityEntity
import com.example.tutorapp395.data.local.entities.SubjectLevelEntity
import com.example.tutorapp395.data.local.entities.TutorAvailabilityEntity
import com.example.tutorapp395.data.local.entities.TutorEntity
import com.example.tutorapp395.data.local.entities.TutorPayoutEntity
import com.example.tutorapp395.data.local.entities.TutorUnavailableDatesEntity
import com.example.tutorapp395.data.local.entities.TutorWeeklyAvailabilityEntity
import android.content.Context
import com.example.tutorapp395.data.local.entities.UserEntity


@Database(entities = [
    UserEntity::class,
    TutorWeeklyAvailabilityEntity::class,
    TutorUnavailableDatesEntity::class,
    TutorPayoutEntity::class,
    TutorAvailabilityEntity::class,
    TutorEntity::class,
    SubjectLevelEntity::class,
    StudentAvailabilityEntity::class,
    SessionRequestEntity::class,
    SessionDeclinedEntity::class,
    SessionEntity::class,
    RescheduledSessionEntity::class,
    RefundedSessionEntity::class,
    QualificationsEntity::class,
    PaymentsEntity::class,
    MessageEntity::class,
    ChatEntity::class,
    AdminBanEntity::class,
                     ], version = 1,
   // autoMigrations = [
  //      AutoMigration(from = 1, to = 2)
  //  ],
    exportSchema = true)
abstract class TutorAppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun tutorWeeklyAvailabilityDao(): TutorWeeklyAvailabilityDao
    abstract fun tutorUnavailableDatesDao(): TutorUnavailableDatesDao
    abstract fun tutorPayoutDao(): TutorPayoutDao
    abstract fun tutorDao(): TutorDao
    abstract fun tutorAvailabilityDao(): TutorAvailabilityDao
    abstract fun subjectLevelDao(): SubjectLevelDao
    abstract fun sessionDeclinedDao(): SessionDeclinedDao
    abstract fun sessionDao(): SessionDao
    abstract fun rescheduledSessionDao(): RescheduledSessionDao
    abstract fun refundedSessionDao(): RefundedSessionDao
    abstract fun qualificationsDao(): QualificationsDao
    abstract fun paymentsDao(): PaymentsDao
    abstract fun messageDao(): MessageDao
    abstract fun chatDao(): ChatDao
    abstract fun adminBanDao(): AdminBanDao

    companion object {
        private var INSTANCE: TutorAppDatabase? = null
        fun getDatabase(context: Context): TutorAppDatabase {
            if (INSTANCE == null) {
                synchronized(this) {
                    INSTANCE =
                        Room.databaseBuilder(
                            context,
                            TutorAppDatabase::class.java,
                            "tutor_app_database"
                        )
                            .build()
                }
            }
            return INSTANCE!!
        }
    }
}

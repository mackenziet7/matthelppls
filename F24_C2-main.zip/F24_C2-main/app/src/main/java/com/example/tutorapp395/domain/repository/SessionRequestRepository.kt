package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface SessionRequestRepository {
    fun getSessionRequests(): Flow<List<NetworkSessionRequest>>

    suspend fun insertSessionRequest(sessionRequest: SessionRequest): Result<String>

    suspend fun getAllSessionRequests(): Result<List<NetworkSessionRequest?>>
    suspend fun getSessionRequestById(id: String):  Result<List<NetworkSessionRequest?>>

    suspend fun deleteSessionRequest(id: String): Result<Unit>

    suspend fun updateSessionRequest(sessionRequest: SessionRequest): Result<Unit>
}

package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkTutorUnavailableTime

data class TutorUnavailableTime(
    val tutorUnavailableTimeId: String? = null, // PK
    val startDateTime: String? = null,
    val endDateTime: String? = null,
    val tutorAvailabilityId: String? = null,
)

fun TutorUnavailableTime.asNetworkModel() = NetworkTutorUnavailableTime(
    tutorUnavailableTimeId = tutorUnavailableTimeId,
    startDateTime = startDateTime,
    endDateTime = endDateTime,
    tutorAvailabilityId = tutorAvailabilityId,
)
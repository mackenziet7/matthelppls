package com.example.tutorapp395.presentation.uistate

data class TutorProfileUIState(
    val firstName: String,
    val lastName: String,
    val username: String,
    val tutorSince: String, //Date user became a tutor
    val qualificationsList: List<QualificationsItem>
)

data class QualificationsItem(
    val degree: String,
    val institute: String,
    val startDate: String,
    val endDate: String,
    val sortIndex: Int,
)
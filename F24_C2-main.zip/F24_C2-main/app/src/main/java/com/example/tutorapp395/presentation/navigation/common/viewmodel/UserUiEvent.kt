package com.example.tutorapp395.presentation.navigation.common.viewmodel

sealed class UserUiEvent {
    // Register Account / Change
    object OnProfileClicked : UserUiEvent()
    object Refresh: UserUiEvent()
    object GoBack: UserUiEvent()
}
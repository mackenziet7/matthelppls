package com.example.tutorapp395.presentation.uistate

data class StudentFindATutorUIState(
    val studentAvailabilityList: List<StudentAvailabilityItem>  // Convert To Hashmap with key as Day
)

data class StudentAvailabilityItem(
    val day: String,
    val startTime: String,
    val endTime: String,
    val sessionDuration: Int,

    )
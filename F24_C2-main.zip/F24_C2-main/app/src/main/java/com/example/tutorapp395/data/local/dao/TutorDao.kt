package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.TutorEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface TutorDao {
    @Query("SELECT * FROM tutor")
    fun getAll(): List<TutorEntity>

    @Insert
    fun insertAll(vararg tutor: TutorEntity)

    @Delete
    fun delete(tutor: TutorEntity)

    @Update
    fun update(tutor: TutorEntity)
    
    @Query("DELETE FROM tutor")
    fun deleteAllValuesInTable()
}
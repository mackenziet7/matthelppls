package com.example.tutorapp395.data.model

data class RefundedSession(
    val cancelledSessionId: String, //PK, FK -> Session
    val refundCost: Float,
    val refundZonedDateTime: String,
    val refundStatus: String,
)
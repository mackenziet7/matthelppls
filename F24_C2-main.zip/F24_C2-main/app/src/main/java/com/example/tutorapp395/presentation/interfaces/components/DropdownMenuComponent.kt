package com.example.tutorapp395.presentation.interfaces.components

import android.graphics.drawable.Icon
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.rounded.AddModerator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuBoxScope
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusModifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import org.intellij.lang.annotations.JdkConstants.HorizontalAlignment
import kotlin.math.exp

// Resource Used: https://www.geeksforgeeks.org/drop-down-menu-in-android-using-jetpack-compose/
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownMenuComponent(values: List<String>, icon2: ImageVector, title: String){

    // Declaring a boolean value to store
    var expanded by remember { mutableStateOf(false) }
    var selectedOptionText by remember { mutableStateOf(values[0]) }

    // Up Icon when expanded and down icon when collapsed
    var icon: @Composable() (() -> Unit)? = null
    if (expanded) {
        icon = @Composable {
            Icon(
                Icons.Filled.KeyboardArrowUp,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
    else {
        icon = @Composable {
            Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }

    val leadingIcon = @Composable {
        Icon(
            icon2,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
        )
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = {
            expanded = !expanded
        }
    ) {
        OutlinedTextField(
            readOnly = true,
            value = selectedOptionText,
            onValueChange = { },
            label = { Text(title) },
            leadingIcon = leadingIcon,
            trailingIcon = icon,
            modifier = Modifier.menuAnchor().fillMaxWidth(),
        )
        ExposedDropdownMenu(
            modifier = Modifier,
                    expanded = expanded,
            onDismissRequest = {
                expanded = false
            },
        ) {
            values.forEach { selectionOption ->
                DropdownMenuItem(
                    onClick = {
                        selectedOptionText = selectionOption
                        expanded = false
                    },
                    text = { Text(text = selectionOption) }
                )
            }
        }
    }
}

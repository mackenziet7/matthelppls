package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Qualifications
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.model.SubjectLevel
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkQualifications
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkSubjectLevel
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface SubjectLevelRepository {
    fun getSubjectLevels(): Flow<List<NetworkSubjectLevel>>

    suspend fun insertSubjectLevel(subjectLevel: SubjectLevel): Result<String>
    suspend fun getAllSubjectLevelsByUserId(userId: String): Result<List<NetworkSubjectLevel?>>
    suspend fun deleteSubjectLevel(subjectLevelId: String):  Result<Unit>
    suspend fun updateSubjectLevel(subjectLevel: SubjectLevel): Result<Unit>

}

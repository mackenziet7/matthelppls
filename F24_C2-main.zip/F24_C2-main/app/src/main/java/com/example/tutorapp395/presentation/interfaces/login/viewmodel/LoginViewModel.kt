package com.example.tutorapp395.presentation.interfaces.login.viewmodel

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tutorapp395.app.AdminMainActivity
import com.example.tutorapp395.app.StudentMainActivity
import com.example.tutorapp395.app.TutorMainActivity
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.usecase.RegisterUseCase
import com.example.tutorapp395.domain.usecase.UnexpectedResult
import com.example.tutorapp395.utils.Validator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.time.ZonedDateTime
import javax.inject.Inject


@HiltViewModel
class LoginViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val registerUseCase: RegisterUseCase
)
    : ViewModel() {
    // Register Screen
    private val _registerState: MutableStateFlow<RegisterUiState> = MutableStateFlow(RegisterUiState())
    val registerState: StateFlow<RegisterUiState> = _registerState.asStateFlow()

    private val _loginState: MutableStateFlow<LoginUiState> = MutableStateFlow(LoginUiState())
    val loginState: StateFlow<LoginUiState> = _loginState.asStateFlow()

    private val _effect: Channel<SideEffects> = Channel()
    val effect = _effect.receiveAsFlow()

    fun sendLoginEvent(event: LoginUiEvent){
        reduceLogin(event = event, oldState = loginState.value)
    }

    fun sendRegisterEvent(event: RegisterUiEvent){
        reduceRegister(event = event, oldState = registerState.value)
    }

    private fun reduceLogin(event: LoginUiEvent, oldState: LoginUiState){
        when(event){
            is LoginUiEvent.UsernameChanged -> {
                // Using validateName so user can register as long as its not empty
                val usernameResult = Validator.validateNonEmpty(event.username)
                setLoginState(
                    oldState.copy(
                        usernameError = !usernameResult.status,
                        username = event.username
                    )
                )
                Log.d(TAG, loginState.value.toString())

            }
            is LoginUiEvent.PasswordChanged -> {
                val passwordResult = Validator.validateNonEmpty(event.password)
                Log.d(TAG, loginState.value.toString())
                setLoginState(
                    oldState.copy(
                        usernameError = !passwordResult.status,
                        password = event.password
                    )
                )
                Log.d(TAG, loginState.value.toString())
            }
            is LoginUiEvent.RememberChanged -> {
                if (event.rememberMe) {
                    setLoginState(oldState.copy(
                        rememberMe = true))
                }
                else {
                    setLoginState(oldState.copy(
                        rememberMe = false))
                }
                Log.d(TAG, "${loginState.value}")

            }
            LoginUiEvent.LoginButtonClicked -> {
                loginAccount()
            }

            LoginUiEvent.Reset -> {
                setLoginState(LoginUiState())
            }
        }
        if (loginInputsValid(newState = _loginState.value)){
            setLoginState(_loginState.value.copy(loginButtonEnabled = true))
        }
        else{
            setLoginState(_loginState.value.copy(loginButtonEnabled = false))
        }
    }

    private fun reduceRegister(event: RegisterUiEvent, oldState: RegisterUiState){
        when(event){
            is RegisterUiEvent.UsernameChanged -> {
                // Validate username
                val usernameResult = Validator.validateUsername(event.username)
                val usernameExistingResult = Validator.validateUsernameExisting(event.username, oldState.existingUsernames)
                // Check all errors
                setRegisterState(oldState.copy(
                    username = event.username,
                    usernameError = !usernameResult.status,
                    usernameExistingError = !usernameExistingResult.status,
                ))
            }
            is RegisterUiEvent.EmailChanged -> {
                // Validate email
                val emailResult = Validator.validateEmail(event.email)
                setRegisterState(oldState.copy(
                    email = event.email,
                    emailError = !emailResult.status))
            }
            is RegisterUiEvent.PasswordChanged -> {
                // Check if passwords match
                val passwordMatchResult = Validator.validatePasswordMatch(event.password, oldState.password2)
                // Validate password
                val passwordResult = Validator.validatePassword(event.password)
                setRegisterState(oldState.copy(
                    passwordMatchError = !passwordMatchResult.status,
                    password = event.password,
                    passwordError = !passwordResult.status))
            }
            is RegisterUiEvent.Password2Changed -> {
                // Check if passwords match
                val passwordMatchResult = Validator.validatePasswordMatch(oldState.password, event.password2)
                // Validate re-entered password
                val password2Result = Validator.validatePassword(event.password2)
                setRegisterState(oldState.copy(
                    passwordMatchError = !passwordMatchResult.status,
                    password2 = event.password2,
                    password2Error = !password2Result.status))
            }
            is RegisterUiEvent.PhoneNumberChanged -> {
                // Validate phone number
                val phoneNumberResult = Validator.validatePhoneNumber(event.phoneNumber)
                setRegisterState(oldState.copy(
                    phoneNumber = event.phoneNumber,
                    phoneNumberError = !phoneNumberResult.status))

            }
            is RegisterUiEvent.FirstNameChanged -> {
                // Validate firstname
                val firstNameResult = Validator.validateNonEmpty(event.firstName)
                setRegisterState(oldState.copy(
                    firstName = event.firstName,
                    firstNameError = !firstNameResult.status))

            }
            is RegisterUiEvent.LastNameChanged -> {
                Log.d(TAG, "${registerState.value}")
                // Validate last name
                val lastNameResult = Validator.validateNonEmpty(event.lastName)
                setRegisterState(oldState.copy(
                    lastName = event.lastName,
                    lastNameError = !lastNameResult.status))
            }
            is RegisterUiEvent.DateOfBirthChanged -> {
                // Validate date of birth
                val dOBResult = Validator.validateDateOfBirth(event.dateOfBirth)
                setRegisterState(oldState.copy(
                    dateOfBirth = event.dateOfBirth,
                    dateOfBirthError = !dOBResult.status))

            }
            is RegisterUiEvent.AcceptedTCChanged -> {
                if (event.acceptedTC) {
                        setRegisterState(oldState.copy(
                            acceptedTC = ZonedDateTime.now().toString(),
                            acceptedTCError = false))
                }
                else {
                    setRegisterState(oldState.copy(
                        acceptedTC = "",
                        acceptedTCError = true))
                }
            }
            is RegisterUiEvent.TimezoneChanged -> {
                setRegisterState(oldState.copy(timezone = event.timezone))
            }
            is RegisterUiEvent.RegisterButtonClicked -> {
                //getUserByUsername(oldState)
                // Check if username already exists
                val usernameExistingResult = Validator.validateUsernameExisting(oldState.username, registerState.value.existingUsernames)
                setRegisterState(oldState.copy(
                    usernameExistingError = !usernameExistingResult.status))

                // Register account if no validation errors exist/no username exists
                if ((registerInputsValid(registerState.value))) {
                    registerAccount()
                }
            }

            RegisterUiEvent.Reset -> {
                setRegisterState(
                    RegisterUiState()
                )
            }
        }

        // For every action check if user inputs are valid
        // Must get directly from state due to changes from above
        if (registerInputsValid(newState = _registerState.value)){
            setRegisterState(_registerState.value.copy(registerButtonEnabled = true))
        }
        else{
            setRegisterState(_registerState.value.copy(registerButtonEnabled = false))
        }
    }

    private fun setRegisterState(newState: RegisterUiState) {
        _registerState.value = newState
    }

    private fun setLoginState(newState: LoginUiState) {
        _loginState.value = newState
    }

    private fun setEffect(builder: () -> SideEffects){
        val effectValue = builder()
        viewModelScope.launch {
            _effect.send(effectValue)
        }
    }

    // User clicks register button
    private fun registerAccount(){
        Log.d(TAG, registerState.value.toString())

        setRegisterState(
            _registerState.value.copy(
                isLoading = true,
                registerButtonEnabled = false

            )
        )
        // Check if username exists
        viewModelScope.launch {
           // getUserByUsername(_registerState.value)
            createNewUser(_registerState.value)
        }
    }

    // User clicks login button
    private fun loginAccount(){
        Log.d(TAG, loginState.value.toString())
        setLoginState(
            _loginState.value.copy(
                isLoading = true,
                loginButtonEnabled = false
            )
        )
        // Check if username exists
        viewModelScope.launch {
            getUserByUsernameLogin(_loginState.value)
        }
    }

    private suspend fun createNewUser(oldState: RegisterUiState) {
        when (val result = registerUseCase(registerState.value.asExternalModel())) {
            is Result.Failure -> {
                Log.d(TAG, "CONNECTION FAILURE")
                setRegisterState(
                    oldState.copy(
                        isLoading = false,
                        registerButtonEnabled = true

                    )
                )
            }
            is Result.Success -> {
                Log.d(TAG, "Username Exists")
                if (result.data == UnexpectedResult.ExistingInput) { // Username exists
                    oldState.existingUsernames.add(oldState.username)
                    setRegisterState(
                        oldState.copy(
                            isLoading = false,
                            usernameExistingError = true,
                            registerButtonEnabled = true

                        )
                    )
                }
                else {
                    Log.d(TAG, "Created User")
                    setRegisterState(
                        oldState.copy(
                            isLoading = false,
                            registerSuccessful = true,
                            retrievedUserId = result.data.toString(),
                            registerButtonEnabled = true
                        )
                    )
                }
            }
        }
    }
    // For Login
    private suspend fun getUserByUsernameLogin(oldState: LoginUiState){
        when (val result = userRepository.getUserByUsername(oldState.username)){
            // Account creation failed to connect to database
            is Result.Failure -> {
                Log.d(TAG, "CONNECTION FAILURE")
                setLoginState(
                    oldState.copy(
                        isLoading = false,
                        loginButtonEnabled = true

                    )
                )
                val errorMessage = result.exception.message ?: "An error occurred when connecting to the internet"
                setEffect { SideEffects.ShowSnackBarMessage(message = errorMessage) }
            }
            // New Account c
            is Result.Success -> {

                if (result.data.isEmpty()) {
                    Log.d(TAG, "CONNECTION SUCCESS: No such username found ${result.data}")
                    setLoginState(
                        oldState.copy(
                            isLoading = false ,
                            wrongInputError = true,
                            loginButtonEnabled = true
                        )
                    )
                }
                else {
                    if (result.data[0]?.password != oldState.password) {
                        Log.d(TAG, "CONNECTION SUCCESS: password does not match")
                        setLoginState(
                            oldState.copy(
                                isLoading = false,
                                wrongInputError = true,
                                loginButtonEnabled = true

                            )
                        )
                    } else {
                        Log.d(TAG, "CONNECTION SUCCESS ${result.data[0]}")

                        // User found, store user if not empty
                        result.data[0]?.let {
                            oldState.copy(
                                isLoading = false,
                                loginSuccessful = true,
                                retrievedUser = it,
                                loginButtonEnabled = true

                            )
                        }?.let {
                            setLoginState(
                                it
                            )
                        }

                    }
                }
            }
        }
    }

    // Check if user inputs are valid and updates UI state
    private fun registerInputsValid(newState: RegisterUiState): Boolean {
        val usernameResult = Validator.validateUsername(newState.username)
        val usernameExistingResult = Validator.validateUsernameExisting(newState.username, newState.existingUsernames)
        val emailResult = Validator.validateEmail(newState.email)
        val passwordResult = Validator.validatePassword(newState.password)
        val password2Result = Validator.validatePassword(newState.password2)
        val phoneNumberResult = Validator.validatePhoneNumber(newState.phoneNumber)
        val firstNameResult = Validator.validateNonEmpty(newState.firstName)
        val lastNameResult = Validator.validateNonEmpty(newState.lastName)
        val dOBResult = Validator.validateDateOfBirth(newState.dateOfBirth)
        val passwordMatchResult = Validator.validatePasswordMatch(newState.password, newState.password2)
        // False = No error, True = Error,
        // input is valid if it has no error
        return usernameResult.status
                && lastNameResult.status
                && dOBResult.status
                && phoneNumberResult.status
                && emailResult.status
                && firstNameResult.status
                && passwordResult.status
                && password2Result.status
                && passwordMatchResult.status
                && usernameExistingResult.status
                && !newState.acceptedTCError
    }

    private fun loginInputsValid(newState: LoginUiState): Boolean {
        val usernameResult = Validator.validateNonEmpty(newState.username)
        val passwordResult = Validator.validateNonEmpty(newState.password)

        // False = No error, True = Error,
        // input is valid if it has no error
        return usernameResult.status
                && passwordResult.status
    }

    fun login(userId: String, isAdmin: Boolean, isTutor: Boolean, name: String, context: Context, isNewAccount: Boolean){
        if (isAdmin) { // Simple credential check
            // Starts the MainActivity if credentials are correct
            val intent = Intent(context, AdminMainActivity::class.java)
            intent.putExtra("userId", userId)

            context.startActivity(intent)
            (context as Activity).finish() // Closes the login activity
        } else { if (isTutor) { // Simple credential check
                // Starts the MainActivity if credentials are correct
                val intent = Intent(context, TutorMainActivity::class.java)
                intent.putExtra("userId", userId)

                context.startActivity(intent)
                (context as Activity).finish() // Closes the login activity
            }
        else { // Simple credential check
                // Starts the MainActivity if credentials are correct
                val intent = Intent(context, StudentMainActivity::class.java)
                intent.putExtra("userId", userId)

                context.startActivity(intent)
                (context as Activity).finish() // Closes the login activity
            }
        }
        if(isNewAccount){
           Toast.makeText(context, "Welcome, ${name}!", Toast.LENGTH_SHORT).show() // Error message
        }
        else{
            Toast.makeText(context, "Welcome, ${name}!", Toast.LENGTH_SHORT).show() // Error message
        }
    }
}

package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkTutorUnavailableTime(
    val tutorUnavailableTimeId: String? = null,
    val startDateTime: String? = null,
    val endDateTime: String? = null,
    val tutorAvailabilityId: String? = null, // FK
)

//fun NetworkTutorUnavailableDates.asEntity() = TutorUnavailableDatesEntity(
//    tutorUnavailableTimeId = tutorUnavailableTimeId, // PK
//    startDateTime = startDateTime.toString(),
//    endDateTime = endDateTime.toString(),
//    tutorAvailabilityId = tutorAvailabilityId,
//)
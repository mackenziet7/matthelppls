package com.example.tutorapp395.presentation.interfaces.login.viewmodel

sealed class RegisterUiEvent {

    // Register Account / Change
    data class UsernameChanged( val username: String) : RegisterUiEvent()
    data class EmailChanged( val email: String) : RegisterUiEvent()
    data class PasswordChanged( val password: String) : RegisterUiEvent()
    data class Password2Changed( val password2: String) : RegisterUiEvent()
    data class PhoneNumberChanged( val phoneNumber: String) : RegisterUiEvent()
    data class FirstNameChanged( val firstName: String) : RegisterUiEvent()
    data class LastNameChanged( val lastName: String) : RegisterUiEvent()
    data class DateOfBirthChanged( val dateOfBirth: Long) : RegisterUiEvent()
    data class AcceptedTCChanged( val acceptedTC: Boolean) : RegisterUiEvent()
    data class TimezoneChanged( val timezone: String) : RegisterUiEvent()

    object RegisterButtonClicked : RegisterUiEvent()
    object Reset : RegisterUiEvent()
}


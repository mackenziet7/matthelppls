package com.example.tutorapp395.presentation.interfaces.components

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment

@Composable
fun RadioButtonComponent(
    text: String,
    onButtonSelected: (Boolean) -> Unit
){
    val selected = remember {
        mutableStateOf(false)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected.value, onClick = {
                selected.value = !selected.value
                onButtonSelected(selected.value)
            })
        Text(text = text)
    }
}

@Composable
fun DoubleRadioButtonComponent(
    text: String,
    text2: String,
    onButtonSelected: (Boolean) -> Unit,

    ){
    val selected = remember {
        mutableStateOf(true)
    }
    val selected2 = remember {
        mutableStateOf(false)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Button 1
        RadioButton(
            selected = selected.value,
            // Prevent alternating values when clicking the same radio button over and over again
            // When one button is true, the other button is false and vice versa (no value is same)
            onClick = {
                if (!selected.value){ // Stay true if user keeps clicking button
                selected.value = !selected.value // False, if user clicks other button
                selected2.value = !selected.value
            }
                onButtonSelected(selected.value)

            })

        Text(text = text, color = MaterialTheme.colorScheme.onBackground)

        // Button 2
        RadioButton(
            selected = selected2.value,
            onClick = {if (!selected2.value){
                selected2.value = !selected2.value
                selected.value = !selected2.value
            }
                onButtonSelected(selected.value)

            }
        )
        Text(text = text2, color = MaterialTheme.colorScheme.onBackground)
    }

}
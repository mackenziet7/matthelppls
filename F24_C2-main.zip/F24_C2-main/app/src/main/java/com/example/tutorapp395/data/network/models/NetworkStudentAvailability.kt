package com.example.tutorapp395.data.network.models

import kotlinx.serialization.Serializable

@Serializable
data class NetworkStudentAvailability(
    val studentAvailabilityId: String? = null, // PK
    val sessionRequestId: String? = null,
    val weekday: String? = null,
    val startTime: String? = null,
    val endTime: String? = null,
    val sessionDuration: Int? = null,
)

//fun NetworkStudentAvailability.asEntity() = StudentAvailabilityEntity(
//    studentAvailabilityId = studentAvailabilityId, // PK
//    sessionRequestId = sessionRequestId , // PK, FK
//    weekday = weekday,
//    startTime = startTime,
//    endTime = endTime,
//    sessionDuration = sessionDuration
//)
package com.example.tutorapp395.presentation.uistate

data class AdminAccountsUIState(
    val userAccountsList: List<AccountItem>
)

data class AccountItem(
    val userId: String,
    val username: String,

    val firstName: String,
    val lastName: String,

    val isTutor: Boolean,
    val isAdmin: Boolean,
    val isStudent: Boolean,
)

data class FullAccountProfileUIState(
    val userId: String,
    val username: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val phoneNumber: String,

    val isTutor: Boolean,
    val isAdmin: Boolean,
    val isDeactivated: Boolean,
)
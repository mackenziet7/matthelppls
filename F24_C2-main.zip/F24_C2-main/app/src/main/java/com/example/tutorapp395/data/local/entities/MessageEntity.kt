package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Message
import java.util.UUID

@Entity(tableName = "message", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("senderId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
),ForeignKey(
    entity = ChatEntity::class,
    parentColumns = arrayOf("chatId"),
    childColumns = arrayOf("chatId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class MessageEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val messageId: String, // PK
    @ColumnInfo(index = true)
    val content: String,
    @ColumnInfo(index = true)
    val type: String,
    @ColumnInfo(index = true)
    val sentDateTime: String,
    @ColumnInfo(index = true)
    val senderId: String, // FK
    @ColumnInfo(index = true)
    val chatId: String, //Fk
)

//fun MessageEntity.asExternalModel() = Message(
//    messageId = messageId,
//    content = content,
//    type = type,
//    sentDateTime = sentDateTime,
//    senderId = senderId,
//    chatId = chatId
//)
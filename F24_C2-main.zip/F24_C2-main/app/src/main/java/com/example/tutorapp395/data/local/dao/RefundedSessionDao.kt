package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.RefundedSessionEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface RefundedSessionDao {
    @Query("SELECT * FROM refundedSession")
    fun getAll(): List<RefundedSessionEntity>

    @Insert
    fun insertAll(vararg refundedSession: RefundedSessionEntity)

    @Delete
    fun delete(refundedSession: RefundedSessionEntity)

    @Update
    fun update(refundedSession: RefundedSessionEntity)
    
    @Query("DELETE FROM refundedSession")
    fun deleteAllValuesInTable()
}
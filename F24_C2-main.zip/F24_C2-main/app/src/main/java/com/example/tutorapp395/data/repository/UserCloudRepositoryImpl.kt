package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.model.asNewNetworkModel
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_USER
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class UserCloudRepositoryImpl @Inject constructor(
    //private val userDao: UserDao,
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): UserRepository {
    override fun getUsers(): Flow<List<User>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertUser(user: User): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_USER).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkUser = user.asNewNetworkModel(Timestamp.now(), id)
                Log.d(TAG, "$networkUser")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_USER)
                        .document(id)
                        .set(networkUser)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }


    override suspend fun getAllUsers(): Result<List<NetworkUser?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_USER)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkUser>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun getUserById(id: String): Result<List<NetworkUser?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_USER)
                        .whereEqualTo("userId", id)
                        .limit(1)
                        .get()
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkUser>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun getUserByUsername(username: String):  Result<List<NetworkUser?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(15000L){
                    cloudDb.collection(COLLECTION_PATH_USER)
                        .whereEqualTo("username", username)
                        .limit(1)
                        .get()
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully found")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkUser>()
                        }

                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())

            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteUser(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_USER)
                        .document(id)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateUser(user: User): Result<Unit> {
        return try {
            val modifiedUser = user.copy(modifiedAt = Timestamp.now()).asNetworkModel()

            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    modifiedUser.userId?.let {
                        cloudDb.collection(COLLECTION_PATH_USER)
                            .document(it)
                            .set(modifiedUser)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
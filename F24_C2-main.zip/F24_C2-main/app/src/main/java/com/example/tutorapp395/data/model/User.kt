package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.firebase.Timestamp

data class User(
    val userId: String? = null, // PK
    val username: String? = null,
    val email: String? = null,
    val password: String? = null,
    val isDeactivated: Boolean? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val phoneNumber: String? = null,
    val dateOfBirth: String? = null,
    val isAdmin: Boolean? = null,
    val isTutor: Boolean? = null,
    val acceptedTC: String? = null,
    val timezone: String? = null,
    val createdAt: Timestamp? = null,
    val modifiedAt: Timestamp? = null,
    val completedOnboarding: String? = null,
    )


fun User.asNewNetworkModel(timestamp: Timestamp, userId: String) = NetworkUser(
    userId = userId,
    username = username,
    email = email,
    password = password,
    isDeactivated = isDeactivated,
    firstName = firstName,
    lastName = lastName,
    phoneNumber = phoneNumber,
    dateOfBirth = dateOfBirth,
    isAdmin = isAdmin,
    isTutor = isTutor,
    acceptedTC = acceptedTC,
    timezone = timezone,
    createdAt = timestamp,
    modifiedAt = timestamp,
    completedOnboarding = completedOnboarding,
)

fun User.asNetworkModel() = NetworkUser(
    userId = userId,
    username = username,
    email = email,
    password = password,
    isDeactivated = isDeactivated,
    firstName = firstName,
    lastName = lastName,
    phoneNumber = phoneNumber,
    dateOfBirth = dateOfBirth,
    isAdmin = isAdmin,
    isTutor = isTutor,
    acceptedTC = acceptedTC,
    timezone = timezone,
    createdAt = createdAt,
    modifiedAt = modifiedAt,
    completedOnboarding = completedOnboarding,
)
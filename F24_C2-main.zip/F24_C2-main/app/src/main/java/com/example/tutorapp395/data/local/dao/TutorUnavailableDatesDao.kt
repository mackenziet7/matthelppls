package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.TutorUnavailableDatesEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface TutorUnavailableDatesDao {
    @Query("SELECT * FROM tutorUnavailableDates")
    fun getAll(): List<TutorUnavailableDatesEntity>

    @Insert
    fun insertAll(vararg tutorUnavailableDates: TutorUnavailableDatesEntity)

    @Delete
    fun delete(tutorUnavailableDates: TutorUnavailableDatesEntity)

    @Update
    fun update(tutorUnavailableDates: TutorUnavailableDatesEntity)
    
    @Query("DELETE FROM tutorUnavailableDates")
    fun deleteAllValuesInTable()
}

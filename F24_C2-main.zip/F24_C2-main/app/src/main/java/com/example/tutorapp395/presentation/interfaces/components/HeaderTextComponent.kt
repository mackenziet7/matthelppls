package com.example.tutorapp395.interfaces.components

import android.graphics.Paint
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun HeaderTextComponent(value: String, textAlign: TextAlign = TextAlign.Center) {
    Text(text = value,
        textAlign = textAlign,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
           // .fillMaxWidth()
            .heightIn(min = 40.dp)
            .padding(top = 30.dp, bottom = 10.dp),
        style = MaterialTheme.typography.titleLarge,
    )
}

package com.example.tutorapp395.interfaces.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.tutorapp395.domain.NanpVisualTransformation


// Code Used :https://developer.android.com/quick-guides/content/auto-format-phone-number
@Composable
fun PhoneNumberTextFieldComponent(
    labelValue:String,
    icon: ImageVector,
    onTextSelected: (String) -> Unit,
    errorStatus: Boolean
) {
    var phoneNumber by rememberSaveable { mutableStateOf("") }
    val numericRegex = Regex("[^0-9]")

    val leadingIcon = @Composable {
        Icon(
            icon,
            contentDescription = labelValue,
            tint = MaterialTheme.colorScheme.primary
        )
    }

    OutlinedTextField(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
        value = phoneNumber,
        onValueChange = {
            // Remove non-numeric characters.
            val stripped = numericRegex.replace(it, "")
            phoneNumber = if (stripped.length >= 10) {
                stripped.substring(0..9)
            } else {
                stripped
            }
            onTextSelected(phoneNumber)
        },
        label = { Text(labelValue) },
        singleLine = true,
        leadingIcon = leadingIcon,
        visualTransformation = NanpVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        isError = errorStatus
    )
}


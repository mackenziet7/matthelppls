package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.SessionEntity
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.TutorPayout
import com.example.tutorapp395.data.model.TutorWeeklyAvailability
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface SessionDao {
    @Query("SELECT * FROM session")
    fun getAll(): List<SessionEntity>

    @Insert
    fun insertAll(vararg session: SessionEntity)

    @Delete
    fun delete(session: SessionEntity)

    @Update
    fun update(session: SessionEntity)
    
    @Query("DELETE FROM session")
    fun deleteAllValuesInTable()
}

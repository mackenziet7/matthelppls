package com.example.tutorapp395.data.model

data class Tutor(
    val userId: String, //PK, FK
    val createdAt: String,
    val isDeactivated: Boolean,
)
package com.example.tutorapp395.domain.usecase

import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.UserRepository

class ViewUserAccountsUseCase(
    private val repository: UserRepository
) {
    suspend operator fun invoke(
    ): Result<List<NetworkUser?>> {
        return repository.getAllUsers()
    }
}
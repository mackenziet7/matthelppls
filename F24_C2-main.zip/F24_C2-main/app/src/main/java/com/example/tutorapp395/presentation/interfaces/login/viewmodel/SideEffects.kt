package com.example.tutorapp395.presentation.interfaces.login.viewmodel

sealed class SideEffects {
    data class ShowSnackBarMessage(val message: String) : SideEffects()
}
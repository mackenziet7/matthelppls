package com.example.tutorapp395.presentation.interfaces.login.viewmodel

import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.utils.AccessLevel
import com.example.tutorapp395.domain.DateAndTimeUseCase

data class LoginUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,

    val loginSuccessful: Boolean = false,
    val retrievedUser: NetworkUser = NetworkUser(),

    val loginButtonEnabled: Boolean = false,

    val username: String = "",
    val password: String = "",
    val rememberMe: Boolean = false,

    val usernameError: Boolean = false,
    val passwordError: Boolean = false,
    val wrongInputError: Boolean = false,
)

data class RegisterUiState(
    // Screen State
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val registerButtonEnabled: Boolean = false,
    val registerSuccessful: Boolean = false,

    // Stored values
    val retrievedUserId: String = "",
    val isAdmin: Boolean = false,

    // Input Data
    val existingUsernames: MutableList<String> = ArrayList(),
    val username: String = "",
    val email: String = "",
    val password: String = "",
    val password2: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val phoneNumber: String = "",
    val dateOfBirth: Long? = null,
    val acceptedTC: String = "",
    val timezone: String = "",

    // Error
    val firstNameError: Boolean = false,
    val lastNameError: Boolean = false,
    val usernameError: Boolean = false,
    val usernameExistingError: Boolean = false,
    val emailError: Boolean = false,
    val passwordError: Boolean = false,
    val password2Error: Boolean = false,
    val passwordMatchError: Boolean = false,
    val phoneNumberError: Boolean = false,
    val dateOfBirthError: Boolean = false,
    val acceptedTCError: Boolean = true,
)


fun RegisterUiState.asExternalModel() = User(
    username = username,
    phoneNumber = phoneNumber,
    email = email,
    dateOfBirth = dateOfBirth.toString(),
    acceptedTC = acceptedTC,
    firstName = firstName,
    lastName = lastName,
    isTutor = false,
    isDeactivated = false,
    isAdmin = false,
    password = password,
    timezone = DateAndTimeUseCase.getUserTimeZone().id,
    )
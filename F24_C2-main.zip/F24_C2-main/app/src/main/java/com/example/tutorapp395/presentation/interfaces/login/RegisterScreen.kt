package com.example.tutorapp395.presentation.interfaces.login

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.CheckboxComponent
import com.example.tutorapp395.interfaces.components.DatePickerDocked
import com.example.tutorapp395.interfaces.components.TextFieldComponent
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.PasswordFieldComponent
import com.example.tutorapp395.interfaces.components.PhoneNumberTextFieldComponent
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginViewModel
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.RegisterUiEvent
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.SideEffects
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach

// Resource Used: Native Mobile Bits - "Login Registration"
@Composable
fun RegisterAccountScreen(navController: NavController, loginViewModel: LoginViewModel) {
    val context = LocalContext.current // Gets the current context
    val uiState = loginViewModel.registerState.collectAsState().value
    val effect = loginViewModel.effect

    val snackbarHostState = remember { SnackbarHostState()}

    LaunchedEffect(key1 = true) {
        effect.onEach{ effect ->
            when (effect){
                is SideEffects.ShowSnackBarMessage -> {
                    snackbarHostState.showSnackbar(
                        message = effect.message,
                        duration = SnackbarDuration.Short,
                        actionLabel = "DISMISS",
                    )
                }
            }
        }.collect()
    }

    if (uiState.isLoading){
        CircularProgressIndicator()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 45.dp), // Adds padding to the sides

       // verticalArrangement = Arrangement.Center
    ) {

        // Header
       // Spacer(modifier = Modifier.height(30.dp)) // Space before login button
        HeaderTextComponent("Create An Account")

        // Identity
        TextFieldComponent(
            "First Name",
            Icons.Default.Person,
            onTextSelected = { loginViewModel.sendRegisterEvent(event = RegisterUiEvent.FirstNameChanged(it)) },
            uiState.firstNameError
        )
        TextFieldComponent(
            "Last Name",
            Icons.Default.Person,
            onTextSelected = { loginViewModel.sendRegisterEvent(event = RegisterUiEvent.LastNameChanged(it)) },
            uiState.lastNameError
        )
        // Date Of Birth
        DatePickerDocked(
            onDateSelected = {
                it?.let { it1 -> RegisterUiEvent.DateOfBirthChanged(it1) }
                    ?.let { it2 -> loginViewModel.sendRegisterEvent(it2) }
             },
            uiState.dateOfBirthError,
            "Date of Birth"
        )

        // Contacts
        Spacer(modifier = Modifier.height(20.dp)) // Space before login button
        PhoneNumberTextFieldComponent(
            "Phone Number",
            Icons.Default.Phone,
            onTextSelected = { loginViewModel.sendRegisterEvent(RegisterUiEvent.PhoneNumberChanged(it)) },
            uiState.phoneNumberError
        )

        TextFieldComponent(
            "Email",
            Icons.Default.Email,
            onTextSelected = {
                loginViewModel.sendRegisterEvent(RegisterUiEvent.EmailChanged(it)) },
            uiState.emailError
        )
        // Account
        Spacer(modifier = Modifier.height(20.dp)) // Space before login button
        TextFieldComponent(
            "Username",
            Icons.Default.AccountCircle,
            onTextSelected = {
                loginViewModel.sendRegisterEvent(RegisterUiEvent.UsernameChanged(it)) },
            errorStatus = uiState.usernameError || uiState.usernameExistingError
        )
        if  (uiState.usernameError){
            Text(text ="Username length must be at least 3 characters long",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        if  (uiState.usernameExistingError){
            Text(text ="Username already exists",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        // Passwords
        PasswordFieldComponent(
            "Password",
            onTextSelected = {
                loginViewModel.sendRegisterEvent(RegisterUiEvent.PasswordChanged(it)) },
            uiState.passwordError || uiState.passwordMatchError
        )
        PasswordFieldComponent(
            "Re-enter Password",
            onTextSelected = {
                loginViewModel.sendRegisterEvent(RegisterUiEvent.Password2Changed(it)) },
            uiState.passwordError || uiState.passwordMatchError

        )
        //TODO: REFACTOR ERROR TEXTS
        if  (uiState.passwordMatchError){
            Text(text ="*Passwords do not match",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        if (uiState.passwordError){
            Text(text ="*Password length must be at least 4 character long",
                color = Color.Red,
                fontSize = 12.sp
            )
        }

        // Back Button: that returns user to Login Screen
        Row(modifier = Modifier
            .fillMaxWidth()
      //      .wrapContentSize()
            .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CheckboxComponent("I agree to the ",
                onCheckedChanged = {loginViewModel.sendRegisterEvent(RegisterUiEvent.AcceptedTCChanged(it))})
            Text(
                text = "terms & conditions",
                color = MaterialTheme.colorScheme.primary,

                modifier = Modifier
                    .clickable { })
        }
        Spacer(modifier = Modifier.height(20.dp)) // Space before login button


        // Register Account Button
        LargeButtonComponent("Register",
            onButtonClicked = {
                loginViewModel.sendRegisterEvent(RegisterUiEvent.RegisterButtonClicked)
            },
            enabledStatus = uiState.registerButtonEnabled
        )

        if (uiState.registerSuccessful){
            loginViewModel.login(
                uiState.retrievedUserId,
                uiState.isAdmin,
                false, // cannot create tutor
                uiState.firstName,
                context,
                true)
        }

        Spacer(modifier = Modifier.height(20.dp)) // Space before login button
        // TODO: temporary code to get to CreateAccount Screen, REFACTOR below
        Row(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Text(
                text = "Already have an account? ",
                color = MaterialTheme.colorScheme.onBackground)
            Text(
                text = "Log In",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable {
                        navController.navigateUp()
                        loginViewModel.sendRegisterEvent(RegisterUiEvent.Reset)
                    })
        }
        Spacer(modifier = Modifier.height(40.dp)) // Space before login button

    }
}
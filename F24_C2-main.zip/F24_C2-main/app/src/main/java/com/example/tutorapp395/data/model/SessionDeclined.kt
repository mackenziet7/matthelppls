package com.example.tutorapp395.data.model

data class SessionDeclined(
    val sessionRequestId: String, //PK, FK
    val declinedDateTime: String,
    val reason: String,
    val content: String,
    val userId: String, // FK
    )
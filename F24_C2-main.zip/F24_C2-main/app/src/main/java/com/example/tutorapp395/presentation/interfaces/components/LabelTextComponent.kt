package com.example.tutorapp395.interfaces.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun LabelTextComponent(value: String, color: Color = MaterialTheme.colorScheme.primary) {
    Text(text = value,
        color = Color.Black,
        modifier = Modifier
          //  .heightIn(min = 40.dp)
            .background(color = color, shape = RoundedCornerShape(50.dp))
            .padding(horizontal = 10.dp),
        style = MaterialTheme.typography.titleMedium,
    )
}
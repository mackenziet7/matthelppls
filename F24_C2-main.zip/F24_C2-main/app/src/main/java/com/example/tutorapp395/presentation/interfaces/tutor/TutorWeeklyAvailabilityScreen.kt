package com.example.tutorapp395.interfaces.tutor

import android.app.TimePickerDialog
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.twotone.ArrowBack
import androidx.compose.material.icons.twotone.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.*


@Composable
fun TutorMonthlyAvailabilityScreen(navController: NavController) {
    var currentDate by remember { mutableStateOf(LocalDate.now()) }
    val month = currentDate.month.getDisplayName(TextStyle.FULL, Locale.getDefault())
    val year = currentDate.year.toString()

    var selectedDay by remember { mutableStateOf(0) }
    val weekDays = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    // Map to store availability per weekday
    var availability by remember { mutableStateOf(mutableMapOf<String, String>()) }

    // State for selected start and end time
    var startTime by remember { mutableStateOf("Select Start Time") }
    var endTime by remember { mutableStateOf("Select End Time") }

    // States for time picker dialog visibility
    var showStartTimePicker by remember { mutableStateOf(false) }
    var showEndTimePicker by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(state = rememberScrollState())
    ) {
        SubTopBar(navController, "Weekly Availability Submission")

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 90.dp),
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Month and Year Navigation Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { currentDate = currentDate.minusMonths(1) }) {
                    Icon(imageVector = Icons.TwoTone.ArrowBack, contentDescription = "Back a month")
                }
                Text(text = "$month $year")
                IconButton(onClick = { currentDate = currentDate.plusMonths(1) }) {
                    Icon(imageVector = Icons.TwoTone.ArrowForward, contentDescription = "Forward a month")
                }
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp, horizontal = 20.dp), color = Color.Black)

            // Weekly Availability Section
            Text(text = "Weekly Availability", fontSize = 20.sp, modifier = Modifier.padding(top = 20.dp))

            // Display day tabs
            TabRow(selectedTabIndex = selectedDay, modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 10.dp)) {
                weekDays.forEachIndexed { index, day ->
                    Tab(selected = selectedDay == index, onClick = { selectedDay = index }) {
                        Text(text = day.first().toString(), fontSize = 18.sp, modifier = Modifier.padding(bottom = 5.dp))
                    }
                }
            }

            // Time inputs for setting availability
            Text(text = "From", fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))
            TextButton(onClick = { showStartTimePicker = true }) {
                Text(text = startTime)
            }
            Text(text = "To", fontSize = 20.sp, modifier = Modifier.padding(bottom = 10.dp))
            TextButton(onClick = { showEndTimePicker = true }) {
                Text(text = endTime)
            }

            TextButton(
                onClick = {
                    // Save availability for the selected day
                    availability[weekDays[selectedDay]] = "$startTime - $endTime"
                },
                modifier = Modifier.border(width = 2.dp, color = Color.DarkGray, shape = RoundedCornerShape(8.dp))
            ) {
                Text(text = "Save")
            }

            // Display the saved availability for the selected day below the Save button
            val selectedDayName = weekDays[selectedDay]
            val savedAvailability = availability[selectedDayName] ?: "Not set"
            Text(
                text = "Availability: $savedAvailability",
                fontSize = 16.sp,
                modifier = Modifier.padding(vertical = 10.dp)
            )
        }
    }

    // Start Time Picker Dialog
    if (showStartTimePicker) {
        TimePickerDialog(
            LocalContext.current,
            { _, hourOfDay, minute ->
                // Convert to 12-hour format for display
                val formattedHour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                val amPm = if (hourOfDay < 12) "AM" else "PM"
                startTime = String.format("%02d:%02d %s", formattedHour, minute, amPm) // Format the time
                showStartTimePicker = false
            },
            0, 0, false // Default to 0:00 hours in 12-hour format
        ).show()
    }

    // End Time Picker Dialog
    if (showEndTimePicker) {
        TimePickerDialog(
            LocalContext.current,
            { _, hourOfDay, minute ->
                // Convert to 12-hour format for display
                val formattedHour = if (hourOfDay % 12 == 0) 12 else hourOfDay % 12
                val amPm = if (hourOfDay < 12) "AM" else "PM"
                endTime = String.format("%02d:%02d %s", formattedHour, minute, amPm) // Format the time
                showEndTimePicker = false
            },
            0, 0, false // Default to 0:00 hours in 12-hour format
        ).show()
    }
}

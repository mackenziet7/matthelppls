package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.TutorUnavailableTime

@Entity(tableName = "tutorUnavailableDates", foreignKeys = [ForeignKey(
    entity = TutorAvailabilityEntity::class,
    parentColumns = arrayOf("tutorAvailabilityId"),
    childColumns = arrayOf("tutorAvailabilityId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class TutorUnavailableDatesEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val tutorUnavailableDatesId: String, // PK
    @ColumnInfo(index = true)
    val startDateTime: String,
    @ColumnInfo(index = true)
    val endDateTime: String,
    @ColumnInfo(index = true)
    val tutorAvailabilityId: String, // FK
)

//fun TutorUnavailableDatesEntity.asExternalModel() = TutorUnavailableTime(
//    tutorUnavailableDatesId = tutorUnavailableDatesId, // PK
//    startDateTime = startDateTime,
//    endDateTime = endDateTime,
//    tutorAvailabilityId = tutorAvailabilityId,
//)
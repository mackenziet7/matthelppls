package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.MessageEntity
import com.example.tutorapp395.data.model.Chat
import com.example.tutorapp395.data.model.Message
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface MessageDao {
    @Query("SELECT * FROM message")
    fun getAll(): List<MessageEntity>

    @Insert
    fun insertAll(vararg message: MessageEntity)

    @Delete
    fun delete(message: MessageEntity)

    @Update
    fun update(message: MessageEntity)

    @Query("DELETE FROM message")
    fun deleteAllValuesInTable()
}

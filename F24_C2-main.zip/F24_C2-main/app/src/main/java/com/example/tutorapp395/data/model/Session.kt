package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkSession
import java.util.Date

data class Session(
    val sessionId: String,
    val startDateTime: String,
    val endDateTime: String,
    val cancelledDate: String,
    val cancelAccommodation: String,
    val sessionRequestId: String, // Foreign Key
)

fun Session.asNetworkModel() = NetworkSession(
    sessionId = sessionId,
    startDateTime = Date(startDateTime),
    endDateTime = Date(endDateTime),
    cancelledDate = Date(cancelledDate),
    cancelAccommodation = cancelAccommodation,
    sessionRequestId = sessionRequestId
)
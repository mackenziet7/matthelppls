package com.example.tutorapp395.presentation.navigation.common.viewmodel

import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkUser




data class UserProfileUiState(
    // Screen states
    val isLoading: Boolean = false,
    val profile: SimpleProfileState = SimpleProfileState(),

    val retrievalSuccessful: Boolean = false,
    val retrievalError: Boolean = false,
)




data class SimpleProfileState(
    val userId: String? = "",

    // Screen values
    val username: String? = "",
    val firstName: String? = "",
    val lastName: String? = "",
    val label: String? = "",
)

fun NetworkUser.asSimpleProfileState(label: String?) = SimpleProfileState(
    userId = userId,
    username = username,
    firstName = firstName,
    lastName = lastName,
    label = label
)
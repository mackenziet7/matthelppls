package com.example.tutorapp395.presentation.interfaces.tutor

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.FullNameTextComponent
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.MediumButtonComponent
import com.example.tutorapp395.interfaces.components.SubHeaderTextComponent
import com.example.tutorapp395.presentation.navigation.common.EditTutorProfile
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import com.example.tutorapp395.presentation.uistate.ContactsItem
import com.example.tutorapp395.presentation.uistate.InboxUIState

@Composable
fun TutorProfileScreen(navController: NavController, modifier: Modifier, header: String) {

    val qualifications = listOf(
        ContactsItem("X", "University", "Bachelor of Education", "2012-2015", "Math 12", "12", "123"),
        ContactsItem("Y", "Institute", "English Diploma", "2011", "Math 12", "12", "123"),
    )
    val inbox = InboxUIState(qualifications)

//    val uiState = userViewModel.profileState.collectAsState().value
//
    val firstName = "John"
    val lastName = "Doe"
    val label = "Tutor"
    val username = "johndoe"
    // Top Profile
    Column(
        modifier = Modifier
            .padding(top = 80.dp, bottom = 5.dp)
            .verticalScroll(rememberScrollState()),

        ){
        // Header -> Full name and username
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(color = MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 25.dp)
                .padding(top = 20.dp)
        ) {

            // Refresh Button
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButtonComponent(Icons.Rounded.Refresh, "", onButtonClicked = {})
            }
            // Full name
            HeaderTextComponent("$firstName $lastName", textAlign = TextAlign.Start)
            // username and account type
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween

            ) {
                SubHeaderTextComponent("@${username.toString()}")
                LabelTextComponent(label.toString())
            }

        }

        // Content
        Column(
            modifier = Modifier
                .padding(top = 20.dp)
                .padding(horizontal = 20.dp)
        ) {
            MediumButtonComponent(
                Icons.Default.Edit,
                "Edit Profile",
                onButtonClicked = {
                    navController.navigate(route = EditTutorProfile)
                },
                true
            )
        }
        ContentHeader("Subjects")
        val labels = listOf(
            "Math 12", "Science 10"
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(40.dp)
                )
                .padding(20.dp)
        ) {
            for (item in labels) {
                LabelTextComponent(item, Color.Gray)
                Spacer(modifier = Modifier.width(10.dp)) // Space before login button

            }
        }
        ContentHeader("Qualifications")


        Column(
            modifier = Modifier
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(40.dp)
                )
                .padding(20.dp)
            ,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            for (item in inbox.contactsList) {
                Row(
                    modifier = Modifier
                        .padding(vertical = 5.dp)
                        .height(120.dp)
                        //    .fillParentMaxWidth()
                        .shadow(5.dp, RoundedCornerShape(28.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.background)

                ) {
                    Column(
                        modifier = Modifier
                            .padding(horizontal = 20.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            FullNameTextComponent(item.firstName, item.lastName)
                            Text(item.lastDateTime)
                        }

                        Spacer(modifier = Modifier.height(5.dp)) // Space before login button

                        Text(item.lastMessage, color = Color.Black, maxLines = 2)

                    }

                }
            }
        }
        ContentHeader("Availability")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(40.dp)
                )
                .height(100.dp)
                .padding(20.dp),

            horizontalAlignment = Alignment.CenterHorizontally){}

    }

    //  Calendar()


    SubTopBar(navController, "My Profile")
}


@Composable
fun ContentHeader(title: String){
    Column (
        modifier = Modifier.padding(horizontal = 20.dp)
    ){
        HeaderTextComponent(title, textAlign = TextAlign.Start)
    }

}
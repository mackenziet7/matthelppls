package com.example.tutorapp395.presentation.interfaces.admin.viewmodel

import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.presentation.navigation.common.viewmodel.SimpleProfileState

data class CreateAccountUiState(
    val isLoading: Boolean = false,
    val registerSuccessful: Boolean = false,
    val retrievedUserId: String = "",
    // Input Data
    val firstName: String = "",
    val lastName: String = "",
    val existingUsernames: MutableList<String> = ArrayList(),
    val username: String = "",
    val email: String = "",
    val password: String = "",
    val password2: String = "",
    val isAdmin: Boolean = true,
    // Admin Input Data

    val firstNameError: Boolean = false,
    val lastNameError: Boolean = false,
    val existingUsernameError: Boolean = false,
    val usernameError: Boolean = false,
    val emailError: Boolean = false,
    val passwordError: Boolean = false,
    val password2Error: Boolean = false,
    val passwordMismatchError: Boolean = false,

    val createAccountButtonEnabled: Boolean = false,
)

data class ViewUserAccountsUiState(
    val isLoading: Boolean = false,
    val noAccountFoundError: Boolean = false,
    val accounts: MutableList<SimpleProfileState> = ArrayList()
)

fun CreateAccountUiState.asExternalModel() = User(
    username = username,
    firstName = firstName,
    lastName = lastName,
    email = email,
    password = password2,
    isAdmin = isAdmin,
    isTutor = !isAdmin, // Account is admin XOR tutor
)
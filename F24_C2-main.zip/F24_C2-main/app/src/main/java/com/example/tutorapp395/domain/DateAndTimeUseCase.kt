package com.example.tutorapp395.domain

import java.text.SimpleDateFormat
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

// Handle date and time accounting for user's timezone
class DateAndTimeUseCase {
    companion object { // Equivalent to static method
        private const val STORED_ZONE_ID = "UTC"

        // Different formats to use
        const val TIME_FORMAT: String = "hh:mm a"
        const val STORED_TIME_FORMAT: String = "HH:mm"
        const val STORED_DATE_FORMAT: String = "dd/MM/yyyy HH:mm:ss z"
        const val NUMBERED_DATE_FORMAT: String = "dd/MM/yyyy"

        // Raw format of the users current ZonedDateTime
        fun getZonedDateTimeNow(): ZonedDateTime {
            // e.g. 2024-09-24T15:37:41.535944+02:00[Europe/Paris]
            return ZonedDateTime.now()
        }

        // user's current time zone
        fun getUserTimeZone(): ZoneId {
            return ZonedDateTime.now().zone
        }

        // Convert user's local time to the stored timezones time
        fun convertToStoredTimeZone(date :ZonedDateTime): ZonedDateTime {
            return date.withZoneSameInstant(ZoneId.of(STORED_ZONE_ID))
        }
        // Convert formatted time into ZonedDateTime object
        fun convertFormattedToTime(date: String): ZonedDateTime {
            return ZonedDateTime.parse(date)
        }

        // Convert ZonedDateTime to a given format
        fun convertTimeToFormatted(date :ZonedDateTime, format: String): String {
            val formatter = DateTimeFormatter.ofPattern(format)
            return date.withZoneSameInstant(ZoneId.of(STORED_ZONE_ID)).format(formatter)
        }

        fun convertZonedToSting(date: ZonedDateTime): String {
            return date.toString()
        }

        // Convert time to the users timezone
        fun convertToUserTimeZone(date: ZonedDateTime): ZonedDateTime {
            return date.withZoneSameInstant(ZonedDateTime.now().zone)
        }

        // Get all zoneIDs
        fun getAllZoneIDs(): MutableSet<String>? {
            return ZoneId.getAvailableZoneIds()
        }

        fun convertMillisToDate(millis: Long): String {
            val formatter = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
            return formatter.format(Date(millis))
        }
    }
}
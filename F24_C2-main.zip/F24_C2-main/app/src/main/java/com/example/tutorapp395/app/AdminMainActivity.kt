package com.example.tutorapp395.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.presentation.navigation.admin.AdminNavGraph
import com.example.tutorapp395.presentation.theme.TutorApp395Theme
import dagger.hilt.android.AndroidEntryPoint

// Resource used: https://www.youtube.com/watch?v=wJKwsI5WUI4
//              : https://www.youtube.com/watch?v=c8XP_Ee7iqY

@AndroidEntryPoint
class AdminMainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        val userId = intent.getStringExtra("userId")
        Log.d(TAG, "Logged in as admin:$userId")

        // Create a new user with a first and last name

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TutorApp395Theme {
                val navController = rememberNavController()
                if (userId != null) {
                    AdminNavGraph(navController = navController, userId)
                } else{
                    val context = LocalContext.current // Gets the current context
                    val intent = Intent(context, LoginActivity::class.java)
                    Toast.makeText(context, "Oops, something went wrong with connecting to your account!", Toast.LENGTH_SHORT).show() // Error message

                    context.startActivity(intent)
                    (context as Activity).finish() // Closes the login activity
                }
            }
        }
    }
}

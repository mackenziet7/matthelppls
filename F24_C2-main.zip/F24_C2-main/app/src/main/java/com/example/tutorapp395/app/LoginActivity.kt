package com.example.tutorapp395.app

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.presentation.navigation.common.LoginNavGraph


import com.example.tutorapp395.presentation.theme.TutorApp395Theme
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.firestore.firestore
import dagger.hilt.android.AndroidEntryPoint
import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.util.Date

/*
* This activity was made using a tutorial from WhiteBatCodes
* https://www.youtube.com/watch?v=t5O3omAI-6c
* */
@AndroidEntryPoint
class LoginActivity : ComponentActivity() {
    //private val dataBase by lazy { TutorAppDatabase.getDatabase(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        foo()
        setContent(){
            TutorApp395Theme{
                val navController = rememberNavController()
                LoginNavGraph(navController)
            }
        }
    }
}

 //TEMP function to add an admin into the database
fun admin(){
    val db = Firebase.firestore
    val k = NetworkUser("", "admin3", "admin@gmail.com", "123", false, "Jonathan", "Doe", "7809999999", "1990/12/12", true, false, "UTC", "", "", Timestamp.now(), Timestamp.now())
    val result = db.collection("user")
        .add(k)
        .addOnSuccessListener { documentReference ->
            Log.d(TAG, "DocumentSnapshot written with ID: ${documentReference.id}")
            println("SUCCESS 1")
            val id = documentReference.id
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
            println("FAIL 1")
        }
}
data class date(
    val id: ZonedDateTime? = null,
    val data: Date? = null,
 //   val local: LocalDateTime? = null,

)


fun foo(){
    Log.d(TAG, "uo")
    val d = date(ZonedDateTime.now(), Date())// LocalDateTime.now())
    val db = Firebase.firestore
    val result = db.collection("date")
        .add(d)
        .addOnSuccessListener { documentReference ->
            Log.d(TAG, "DocumentSnapshot written with ID: ${documentReference.id}")
            println("SUCCESS 1")
            val id = documentReference.id
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
            println("FAIL 1")
        }
}
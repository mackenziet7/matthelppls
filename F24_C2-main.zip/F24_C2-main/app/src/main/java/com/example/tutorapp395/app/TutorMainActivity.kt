package com.example.tutorapp395.app

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.presentation.interfaces.tutor.Onboarding.OnboardingScreen
import com.example.tutorapp395.presentation.navigation.tutor.TutorNavGraph
import com.example.tutorapp395.presentation.theme.TutorApp395Theme
import dagger.hilt.android.AndroidEntryPoint

// Resource used: https://www.youtube.com/watch?v=wJKwsI5WUI4
//              : https://www.youtube.com/watch?v=c8XP_Ee7iqY

@AndroidEntryPoint
class TutorMainActivity : ComponentActivity() {
    private val needsOnboarding = true // Temporary flag TODO: change this so it gets from database

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        val userId = intent.getStringExtra("userId")
        Log.d(TAG, "Logged in as tutor:$userId")

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TutorApp395Theme {
                val navController = rememberNavController()
                if (userId != null) {
                    if (needsOnboarding) {
                        OnboardingScreen(onComplete = {
                            // Navigate to main content after onboarding
                            // TutorNavGraph(navController = navController, userId) TODO: figure out how to get back to main nav after onboarding
                        })
                    } else {
                        TutorNavGraph(navController = navController, userId)
                    }
                } else {
                    navigateToLogin()
                }
            }
        }
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        Toast.makeText(this, "Oops, something went wrong with connecting to your account!", Toast.LENGTH_SHORT).show()
        startActivity(intent)
        finish()
    }
}



package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.presentation.navigation.common.CalendarScreen
import com.example.tutorapp395.presentation.navigation.common.HomeScreen
import com.example.tutorapp395.presentation.navigation.common.InboxScreen
import com.example.tutorapp395.presentation.navigation.common.SessionsScreen

@Composable
fun BottomNavGraph(navController: NavHostController, mainNavController: NavController) {
    val modifier = Modifier
        .padding(top = 85.dp, bottom = 100.dp)
        .fillMaxSize()

    NavHost(
        navController = navController,
        startDestination = BottomBarItems.Home.route
    ) {
        composable(route = BottomBarItems.Home.route){
            HomeScreen(modifier)
        }
        composable(route = BottomBarItems.Inbox.route){
            InboxScreen(navController, mainNavController, modifier)
        }
        composable(route = BottomBarItems.Calendar.route){
            CalendarScreen(modifier)
        }
        composable(route = BottomBarItems.Sessions.route){
            SessionsScreen(modifier)
        }
    }
}
package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Tutor

@Entity(tableName = "tutor", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)
])data class TutorEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val userId: String, //PK, FK
    @ColumnInfo(index = true)
    val createdAt: String,
    @ColumnInfo(index = true)
    val isDeactivated: Boolean,
)

fun TutorEntity.asExternalModel() = Tutor(
    userId = userId, // PK
    createdAt = createdAt,
    isDeactivated = isDeactivated,
)


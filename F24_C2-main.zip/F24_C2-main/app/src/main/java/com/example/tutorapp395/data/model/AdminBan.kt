package com.example.tutorapp395.data.model

data class AdminBan(
    val userId: String, // PK, FK
    val adminId: String,
    val banDateTime: String,
    val unbanDateTime: String,
    val reason: String,
    val content: String,
)
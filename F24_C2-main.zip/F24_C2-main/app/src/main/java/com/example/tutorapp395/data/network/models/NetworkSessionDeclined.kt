package com.example.tutorapp395.data.network.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.local.entities.SessionDeclinedEntity
import com.example.tutorapp395.data.model.SessionDeclined
import kotlinx.serialization.Serializable
import java.time.ZonedDateTime
import java.util.Date

data class NetworkSessionDeclined(
    val sessionRequestId: String,
    val declinedDateTime: Date,
    val reason: String,
    val content: String,
    val userId: String, // FK
)

//fun NetworkSessionDeclined.asEntity() = SessionDeclinedEntity(
//    sessionRequestId = sessionRequestId, //PK, FK
//    declinedDateTime = declinedDateTime.toString(),
//    reason = reason,
//    content = content,
//    userId = userId, // FK
//)

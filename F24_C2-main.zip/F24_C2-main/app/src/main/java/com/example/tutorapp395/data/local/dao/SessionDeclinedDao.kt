package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.SessionDeclinedEntity
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionDeclined
import com.example.tutorapp395.data.model.TutorPayout
import com.example.tutorapp395.data.model.TutorWeeklyAvailability
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface SessionDeclinedDao {
    @Query("SELECT * FROM sessionDeclined")
    fun getAll(): List<SessionDeclinedEntity>

    @Insert
    fun insertAll(vararg sessionDeclined: SessionDeclinedEntity)

    @Delete
    fun delete(sessionDeclined: SessionDeclinedEntity)

    @Update
    fun update(sessionDeclined: SessionDeclinedEntity)
    
    @Query("DELETE FROM sessionDeclined")
    fun deleteAllValuesInTable()
}

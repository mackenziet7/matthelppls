package com.example.tutorapp395.presentation.interfaces.tutor.viewmodel

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.QualificationsRepository
import com.example.tutorapp395.domain.repository.SessionRequestRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.domain.repository.SubjectLevelRepository
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.domain.usecase.FindATutorUseCase
import com.example.tutorapp395.domain.usecase.RegisterUseCase
import com.example.tutorapp395.domain.usecase.UnexpectedResult
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginUiState
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.asExternalModel
import com.example.tutorapp395.presentation.uistate.StudentFindATutorUIState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.time.delay
import java.time.Duration
import javax.inject.Inject

@HiltViewModel
class TutorViewModel @Inject constructor(
    private val subjectLevelRepository: SubjectLevelRepository,
    private val qualificationsRepository: QualificationsRepository,
) : ViewModel() {
    private val _EditTutorProfileState: MutableStateFlow<EditTutorProfileUiState> = MutableStateFlow(EditTutorProfileUiState())
    val editTutorProfileUiState: StateFlow<EditTutorProfileUiState> = _EditTutorProfileState.asStateFlow()

    fun setEditTutorProfileState(newState: EditTutorProfileUiState){
        _EditTutorProfileState.value = newState
    }

    fun sendEdtTutorProfileEvent(event: EditTutorProfileUiEvent) {
        when (event) {
            EditTutorProfileUiEvent.goBackButtonCliked -> TODO()
            EditTutorProfileUiEvent.saveClicked -> TODO()
            is EditTutorProfileUiEvent.QualificationsListChanged -> TODO()
            is EditTutorProfileUiEvent.SubjectLevelListChanged -> TODO()
        }
    }
}
package com.example.tutorapp395.interfaces.admin
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

// Main screen for reports for an admin
@Composable
fun AdminReportsScreen(modifier: Modifier) {
    // Column Composable,
    Column(
        modifier = modifier,
        // Parameters set to place the items in center
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Icon Composable
        Icon(
            imageVector = Icons.Default.Feedback,
            contentDescription = "Reports",
            tint = Color(0xFF0F9D58)
        )
        // Text to Display the current Screen
        Text(text = "Reports", color = Color.Black)
    }
}

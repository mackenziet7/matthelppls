package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkStudentAvailability

data class StudentAvailability(
    val studentAvailabilityId: String? = null, // PK
    val sessionRequestId: String? = null,
    val weekday: String? = null,
    val startTime: String? = null,
    val endTime: String? = null,
    val sessionDuration: Int? = null,
)

fun StudentAvailability.asNetworkModel() = NetworkStudentAvailability(
    studentAvailabilityId = studentAvailabilityId,
    sessionRequestId = sessionRequestId,
    weekday = weekday,
    startTime = startTime,
    endTime = endTime,
    sessionDuration = sessionDuration
)
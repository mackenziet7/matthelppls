package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.network.models.NetworkStudentAvailability
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_STUDENT_AVAILABILITY
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class StudentAvailabilityCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): StudentAvailabilityRepository {
    override fun getStudentAvailability(): Flow<List<StudentAvailability>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertStudentAvailability(studentAvailability: StudentAvailability): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkStudentAvailability = studentAvailability.copy(studentAvailabilityId = id).asNetworkModel()
                Log.d(TAG, "$networkStudentAvailability")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY)
                        .document(id)
                        .set(networkStudentAvailability)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }

    override suspend fun getAllStudentAvailabilities(): Result<List<NetworkStudentAvailability?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkStudentAvailability>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun getStudentAvailabilityById(id: String): Result<List<NetworkStudentAvailability?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY)
                        .whereEqualTo("studentAvailabilityId", id)
                        .limit(1)
                        .get()
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkStudentAvailability>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteStudentAvailability(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY)
                        .document(id)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateStudentAvailability(studentAvailability: StudentAvailability): Result<Unit> {
        return try {
            val modifiedStudentAvailability = studentAvailability.asNetworkModel()
            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    modifiedStudentAvailability.studentAvailabilityId?.let {
                        cloudDb.collection(COLLECTION_PATH_STUDENT_AVAILABILITY)
                            .document(it)
                            .set(modifiedStudentAvailability)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
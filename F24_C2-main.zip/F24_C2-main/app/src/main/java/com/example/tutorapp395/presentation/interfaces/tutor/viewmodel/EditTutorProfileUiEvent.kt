package com.example.tutorapp395.presentation.interfaces.tutor.viewmodel

import com.example.tutorapp395.presentation.interfaces.student.viewmodel.FindATutorUiEvent

sealed class EditTutorProfileUiEvent {

    data class QualificationsListChanged(val id: String) : EditTutorProfileUiEvent()
    data class SubjectLevelListChanged(val id: String) : EditTutorProfileUiEvent()


    data object saveClicked: EditTutorProfileUiEvent()
    data object goBackButtonCliked: EditTutorProfileUiEvent()
}
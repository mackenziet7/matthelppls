package com.example.tutorapp395.presentation.interfaces.tutor.viewmodel

import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.network.models.NetworkQualifications
import com.example.tutorapp395.data.network.models.NetworkSubjectLevel


data class EditTutorProfileUiState(
    val isLoading: Boolean = false,

    val isModified: Boolean = false,

    val qualificationsList: MutableList<NetworkQualifications>? = null,
    val subjectLevelList: MutableList<NetworkSubjectLevel>? = null

    )
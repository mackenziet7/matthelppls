package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.motion.widget.MotionScene.Transition.TransitionOnClick
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.IconButtonComponent
import com.example.tutorapp395.presentation.theme.ThemeColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubTopBar(navController: NavController, title: String, onClick: () -> Unit = {}) {

    TopAppBar(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 15.dp)
            .padding(bottom = 10.dp),
//        colors = TopAppBarDefaults.topAppBarColors(
//            containerColor = MaterialTheme.colorScheme.background
//        ),
//        modifier = Modifier
//            .padding(horizontal = 15.dp, vertical = 5.dp),
        title = {

            Text(
                modifier = Modifier.padding(horizontal = 20.dp)
                    .padding(top = 10.dp),
                text = title,
                fontSize = 20.sp

            )
        },
        navigationIcon = {
            IconButtonComponent(
                Icons.Rounded.ArrowBackIosNew,
                "",
                onButtonClicked = {
                    navController.navigateUp()
                    onClick.invoke()
                })

        },

    )
}
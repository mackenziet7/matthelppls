package com.example.tutorapp395.presentation.navigation.common.viewmodel

import android.content.ContentValues.TAG
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository,
) : ViewModel() {

    private val _user: MutableStateFlow<User> = MutableStateFlow(User())
    val user: StateFlow<User> = _user.asStateFlow()

    private val _profileState: MutableStateFlow<UserProfileUiState> = MutableStateFlow(
        UserProfileUiState()
    )
    val profileState: StateFlow<UserProfileUiState> = _profileState.asStateFlow()

    // Set states
    private fun setProfileState(newState: UserProfileUiState){
        _profileState.value = newState
    }
    private fun setUser(user: User){
        _user.value = user
    }

    // Handle events
    fun sendEvent(event: UserUiEvent){
        reduce(event = event)
    }

    private fun reduce(event: UserUiEvent) {
        when (event){
            UserUiEvent.OnProfileClicked -> {
                // Retrieve from database only once unless refreshed
                // as view model stores the data to be used again if needed
                if (!profileState.value.retrievalSuccessful) {
                    getUserById()
                }
            }
            UserUiEvent.Refresh -> {
                getUserById()
            }

            UserUiEvent.GoBack -> {
                setProfileState(
                    _profileState.value.copy(
                        retrievalError = false
                    )
                )
            }
        }
    }
    fun setUserId(userId: String){
        setUser(_user.value.copy(userId = userId))
    }

    // Connect to database
    private fun getUserById() {
        viewModelScope.launch {
            when (val result =
                _user.value.userId?.let { userRepository.getUserById(it) }) {
                // Account creation failed to connect to database
                is Result.Failure -> {
                    Log.d(TAG, "CONNECTION FAILURE")
                    setProfileState(
                        _profileState.value.copy(
                            isLoading = false,
                        )
                    )
                    val errorMessage = result.exception.message
                        ?: "An error occurred when connecting to the internet"
                }
                // New Account c
                is Result.Success -> {

                    if (result.data.isEmpty()) {
                        Log.d(TAG, "CONNECTION SUCCESS: No such username found")

                        setProfileState(
                            _profileState.value.copy(
                                isLoading = false,
                                retrievalError = true,
                            )
                        )
                    } else {
                        Log.d(TAG, "CONNECTION SUCCESS ${result.data[0]}")
                        // Update userState
                        val userState =  result.data[0]

                        // Update Profile State: can further refactor this code
                        var label = "Student"
                        if (userState != null) {
                            if (userState.isTutor == true) {label = "Tutor"}
                        }
                        if (userState != null) {
                            if (userState.isAdmin == true) {label = "Admin"}
                        }

                        val profile = result.data[0]?.asSimpleProfileState(label)
                        // User found, store user if not empty
                        // ?.let handles null cases
                        profile?.let { // update profile state
                            _profileState.value.copy(
                                isLoading = false,
                                retrievalSuccessful = true,
                                profile = it
                            )
                        }?.let { setProfileState(it) }
                    }
                }

                null -> {
                    setProfileState(_profileState.value.copy(
                        isLoading = false,
                        retrievalError = true,
                    ))
                }
            }
        }
    }
}
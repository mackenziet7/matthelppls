package com.example.tutorapp395.data.model

data class RescheduledSession(
    val cancelledSessionId: String, //PK, FK -> Session
    val newSessionId: String
)
package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Chat
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkChat
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface ChatRepository {
    fun getChats(): Flow<List<NetworkChat>>

    suspend fun insertChat(chat: Chat): Result<String>

    suspend fun getAllChatByUserId(): Result<List<NetworkChat?>>

    suspend fun deleteChat(id: String): Result<Unit>

    suspend fun updateChat(chat: Chat): Result<Unit>
}

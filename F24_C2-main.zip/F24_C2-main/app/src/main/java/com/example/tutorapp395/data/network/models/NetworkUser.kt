package com.example.tutorapp395.data.network.models

import com.example.tutorapp395.data.local.entities.UserEntity
import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName
import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.Date
import java.util.UUID

/**
 * Network representation of user
 */
data class NetworkUser(
    val userId: String? = null,
    val username: String? = null,
    val email: String? = null,
    val password: String? = null,
    @field:JvmField // use this annotation if your Boolean field is prefixed with 'is'
    val isDeactivated: Boolean? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val phoneNumber: String? = null,
    val dateOfBirth: String? = null,
    @field:JvmField // use this annotation if your Boolean field is prefixed with 'is'
    val isAdmin: Boolean? = null,
    @field:JvmField // use this annotation if your Boolean field is prefixed with 'is'
    val isTutor: Boolean? = null,
    val timezone: String? = null,
    val acceptedTC: String? = null,
    val completedOnboarding: String? = null,
    val createdAt: Timestamp? = null,
    val modifiedAt: Timestamp? = null,
    )

/**
 * Converts network model to local model
 */
fun NetworkUser.asEntity() = UserEntity(
    userId = userId ?: "", // if null, it becomes an empty string instead
    username = username ?: "",
    email = email ?: "",
    password = password?: "",
    isDeactivated = isDeactivated?: false,
    firstName = firstName?: "",
    lastName = lastName?: "",
    phoneNumber = phoneNumber?:"",
    dateOfBirth = dateOfBirth?:"",
    isAdmin = isAdmin?: false,
    isTutor = isTutor?: false,
    timezone = timezone?: "",
    acceptedTC = acceptedTC?: "",
    completedOnboarding = completedOnboarding.toString(),
    createdAt = createdAt.toString(),
    modifiedAt = modifiedAt.toString(),
)


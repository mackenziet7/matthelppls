package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Qualifications
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkQualifications
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface QualificationsRepository {
    fun getQualifications(): Flow<List<NetworkQualifications>>

    suspend fun insertQualifications(qualifications: Qualifications): Result<String>

    suspend fun getAllQualifications(): Result<List<NetworkQualifications?>>
    suspend fun getQualificationsById(id: String):  Result<List<NetworkQualifications?>>

    suspend fun deleteQualifications(id: String): Result<Unit>

    suspend fun updateQualifications(qualifications: Qualifications): Result<Unit>
}

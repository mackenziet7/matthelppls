package com.example.tutorapp395.presentation.interfaces.student.viewmodel

sealed class FindATutorUiEvent {
    data object submitClicked: FindATutorUiEvent()
    data object reset: FindATutorUiEvent()
}
package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.SubjectLevel
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.model.asNewNetworkModel
import com.example.tutorapp395.data.network.models.NetworkSubjectLevel
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_USER
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.SubjectLevelRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_SUBJECT_LEVEL
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class SubjectLevelCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): SubjectLevelRepository {
    override fun getSubjectLevels(): Flow<List<NetworkSubjectLevel>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertSubjectLevel(subjectLevel: SubjectLevel): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(
                    COLLECTION_PATH_SUBJECT_LEVEL).document()
                val id = docRef.id
                val networkSubjectLevel = subjectLevel.copy(userId = id).asNetworkModel()

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SUBJECT_LEVEL)
                        .document(id)
                        .set(networkSubjectLevel)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }


    override suspend fun getAllSubjectLevelsByUserId(userId: String): Result<List<NetworkSubjectLevel?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SUBJECT_LEVEL)
                        .whereEqualTo("userId", userId)
                        .get()
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkSubjectLevel>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }


    override suspend fun deleteSubjectLevel(subjectLevelId: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_SUBJECT_LEVEL)
                        .document(subjectLevelId)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateSubjectLevel(subjectLevel: SubjectLevel): Result<Unit> {
        return try {
            val networkSubjectLevel = subjectLevel.asNetworkModel()

            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    networkSubjectLevel.userId?.let {
                        cloudDb.collection(COLLECTION_PATH_SUBJECT_LEVEL)
                            .document(it)
                            .set(networkSubjectLevel)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
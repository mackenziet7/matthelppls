package com.example.tutorapp395.data.network.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.local.entities.PaymentsEntity
import com.example.tutorapp395.data.model.Payments
import kotlinx.serialization.Serializable
import java.time.ZonedDateTime
import java.util.Date

data class NetworkPayments(
    val paymentsId: String,
    val hourlyRate: Float,
    val tutorFee: Float,
    val studentFee: Float,
    val announcementDateTime: Date,
    val changeDateTime: Date,
    val createdAt: Date,
)

//fun NetworkPayments.asEntity() = PaymentsEntity(
//    paymentsId = paymentsId, // PK
//    hourlyRate = hourlyRate,
//    tutorFee = tutorFee,
//    studentFee = studentFee,
//    announcementDateTime = announcementDateTime.toString(),
//    changeDateTime = changeDateTime.toString(),
//    createdAt = createdAt.toString()
//)
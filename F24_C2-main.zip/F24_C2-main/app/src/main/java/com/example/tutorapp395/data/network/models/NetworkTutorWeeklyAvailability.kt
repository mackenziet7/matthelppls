package com.example.tutorapp395.data.network.models

import com.example.tutorapp395.data.local.entities.TutorWeeklyAvailabilityEntity
import kotlinx.serialization.Serializable

@Serializable
data class NetworkTutorWeeklyAvailability(
    val weeklyAvailabilityId: String? = null,
    val weekday: String? = null,
    val startTime: String? = null,
    val endTime: String? = null,
    val tutorAvailabilityId: String? = null, // FK
)

//fun NetworkTutorWeeklyAvailability.asEntity() = TutorWeeklyAvailabilityEntity(
//    weeklyAvailabilityId = weeklyAvailabilityId, // PK
//    weekday = weekday,
//    startTime = startTime,
//    endTime = endTime,
//    tutorAvailabilityId = tutorAvailabilityId,
//)
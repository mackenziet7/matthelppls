package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.interfaces.components.SubHeaderTextComponent
import com.example.tutorapp395.presentation.navigation.common.viewmodel.UserViewModel
import com.example.tutorapp395.presentation.navigation.common.SubTopBar

@Composable
fun ProfileScreen(userViewModel: UserViewModel, navController: NavController, modifier: Modifier) {
    val uiState = userViewModel.profileState.collectAsState().value

    val firstName = uiState.profile.firstName
    val lastName = uiState.profile.lastName
    val label = uiState.profile.label
    val username = uiState.profile.username
    Column(
        modifier = Modifier
            .padding(top = 80.dp, bottom = 5.dp),

        ){
            // Header -> Full name and username
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 25.dp)
                    .padding(top = 20.dp)
            ) {

                // Refresh Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButtonComponent(Icons.Rounded.Refresh, "", onButtonClicked = {})
                }
                // Full name
                HeaderTextComponent("$firstName $lastName", textAlign = TextAlign.Start)
                // username and account type
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween

                ) {
                    SubHeaderTextComponent("@${username.toString()}")
                    LabelTextComponent(label.toString())
                }

            }


            // Labels (student and/or tutor)
        }

        SubTopBar(navController, "My Profile")


}
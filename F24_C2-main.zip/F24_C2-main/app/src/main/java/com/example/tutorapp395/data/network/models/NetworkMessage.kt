package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkMessage(
    val messageId: String? = null,
    val content: String? = null,
    val type: String? = null,
    val sentDateTime: String? = null,
    val senderId: String? = null, // FK
    val chatId: String? = null, //Fk
)

//fun NetworkMessage.asEntity() = MessageEntity(
//    content = content,
//    type = type,
//    sentDateTime = sentDateTime.toString(),
//    senderId = senderId,
//    chatId = chatId
//)


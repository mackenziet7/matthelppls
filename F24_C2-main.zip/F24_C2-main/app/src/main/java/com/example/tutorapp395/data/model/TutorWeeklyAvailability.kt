package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkTutorWeeklyAvailability

data class TutorWeeklyAvailability(
    val weeklyAvailabilityId: String? = null, // PK
    val weekday: String? = null,
    val startTime: String? = null,
    val endTime: String? = null,
    val tutorAvailabilityId: String? = null, // FK
)

fun TutorWeeklyAvailability.asNetworkModel() = NetworkTutorWeeklyAvailability(
    weeklyAvailabilityId = weeklyAvailabilityId,
    weekday = weekday,
    startTime = startTime,
    endTime = endTime,
    tutorAvailabilityId = tutorAvailabilityId
)
package com.example.tutorapp395.data.model

import android.net.Network
import com.example.tutorapp395.data.network.models.NetworkTutor
import com.example.tutorapp395.data.network.models.NetworkTutorAvailability
import java.util.Date

data class TutorAvailability(
    val tutorAvailabilityId: String? = null,
    val updatedOnDateTime: Date? = null,
    val month: Int? = null,
    val year: Int? = null,
    val userId: String? = null, // FK
)


fun TutorAvailability.asNetworkModel() = NetworkTutorAvailability(
    tutorAvailabilityId = tutorAvailabilityId,
    updatedOnDateTime = updatedOnDateTime,
    month = month,
    year = year,
    userId = userId,
)
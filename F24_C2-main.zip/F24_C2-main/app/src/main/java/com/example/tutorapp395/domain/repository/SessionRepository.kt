package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface SessionRepository {
    fun getSessions(): Flow<List<NetworkSession>>

    suspend fun insertSession(session: Session): Result<String>

    suspend fun getAllSessions(): Result<List<NetworkSession?>>
    suspend fun getSessionById(id: String):  Result<List<NetworkSession?>>

    suspend fun deleteSession(id: String): Result<Unit>

    suspend fun updateSession(session: Session): Result<Unit>
}

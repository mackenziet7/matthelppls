package com.example.tutorapp395.domain.usecase

import com.example.tutorapp395.domain.repository.UserRepository

class UserAnalyticsUseCase(
    private val repository: UserRepository

){

}
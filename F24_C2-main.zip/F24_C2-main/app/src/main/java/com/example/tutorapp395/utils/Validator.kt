package com.example.tutorapp395.utils

import android.content.ContentValues.TAG
import android.util.Log
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId


/**
 * Object for validating various inputs such as text fields, dates, and user credentials.
 */
object Validator {

    /**
     * Validates that the given text is non-empty.
     *
     * @param text The input text to validate.
     * @return ValidationResult indicating whether the text is non-empty.
     */
    fun validateNonEmpty(text: String): ValidationResult {
        return ValidationResult(
            (text.isNotEmpty())
        )
    }

    /**
     * Validates the given date of birth.
     * Ensures the date is not null and is not in the future.
     *
     * @param date The date of birth in milliseconds (nullable).
     * @return ValidationResult indicating whether the date of birth is valid (not null and not in the future).
     */
    fun validateDateOfBirth(date: Long?): ValidationResult {
        if (date == null) {
            return ValidationResult(false) // Date is null, validation fails.
        }

        // Convert the input date from milliseconds to LocalDate.
        val inputDate = Instant.ofEpochMilli(date).atZone(ZoneId.systemDefault()).toLocalDate()

        // Get the current date.
        val today = LocalDate.now()

        // Check if the input date is before or equal to today.
        return ValidationResult(
            inputDate.isBefore(today) || inputDate.isEqual(today)
        )
    }

    /**
     * Validates the given phone number.
     * Ensures the phone number is exactly 10 digits long.
     *
     * @param phoneNumber The input phone number as a string.
     * @return ValidationResult indicating whether the phone number is valid.
     */
    fun validatePhoneNumber(phoneNumber: String): ValidationResult {
        Log.d(TAG, "phone:" + phoneNumber.length)
        return ValidationResult(
            phoneNumber.length == 10
        )
    }

    /**
     * Validates that the given email is non-empty.
     * Note: Additional email format validation can be added here.
     *
     * @param email The input email to validate.
     * @return ValidationResult indicating whether the email is non-empty.
     */
    fun validateEmail(email: String): ValidationResult {
        return ValidationResult(
            email.isNotEmpty()
        )
    }

    /**
     * Validates the given username.
     * Ensures the username is non-empty and has at least 3 characters.
     *
     * @param username The input username to validate.
     * @return ValidationResult indicating whether the username is valid.
     */
    fun validateUsername(username: String): ValidationResult {
        return ValidationResult(
            username.isNotEmpty() && username.length >= 3
        )
    }

    /**
     * Validates that the given username does not already exist in the list of existing usernames.
     *
     * @param username The input username to validate.
     * @param existingUsernames A list of usernames already in use.
     * @return ValidationResult indicating whether the username is unique.
     */
    fun validateUsernameExisting(username: String, existingUsernames: List<String>): ValidationResult {
        Log.d(TAG, "$existingUsernames ++++ $username +++ ${!existingUsernames.contains(username)}")
        return ValidationResult(
            !existingUsernames.contains(username)
        )
    }

    /**
     * Validates the given password.
     * Ensures the password is non-empty and has at least 4 characters.
     *
     * @param password The input password to validate.
     * @return ValidationResult indicating whether the password is valid.
     */
    fun validatePassword(password: String): ValidationResult {
        return ValidationResult(
            (password.isNotEmpty() && password.length >= 4)
        )
    }

    /**
     * Validates that two passwords match.
     *
     * @param password1 The first password.
     * @param password2 The second password to compare.
     * @return ValidationResult indicating whether the passwords match.
     */
    fun validatePasswordMatch(password1: String, password2:String): ValidationResult {
        return ValidationResult(
            (password2 == password1)
        )
    }
}

/**
 * A data class representing the result of a validation.
 *
 * @property status Indicates whether the validation was successful. Defaults to false.
 */
data class ValidationResult(
    val status: Boolean = false
)
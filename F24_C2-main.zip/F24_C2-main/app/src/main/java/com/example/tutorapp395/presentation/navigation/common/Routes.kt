package com.example.tutorapp395.presentation.navigation.common

import kotlinx.serialization.Serializable

// Main Screen
@Serializable object AdminMain
@Serializable object StudentMain
@Serializable object TutorMain

@Serializable object Chat

// Side Menu - Profile
@Serializable object Profile

// Student
@Serializable object StudentFindATutor
@Serializable object TutorProfile

// Tutor
@Serializable object TutorSubmission
@Serializable object TutorWeeklySubmission
@Serializable object TutorUnavailabilitySubmission
@Serializable object EditTutorProfile



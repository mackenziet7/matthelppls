package com.example.tutorapp395.data.network.models

import com.example.tutorapp395.data.local.entities.SessionEntity
import kotlinx.serialization.Serializable
import java.time.ZonedDateTime
import java.util.Date

data class NetworkSession(
    val sessionId: String? = null,
    val startDateTime: Date? = null,
    val endDateTime: Date? = null,
    val cancelledDate: Date? = null,
    val cancelAccommodation: String? = null,
    val sessionRequestId: String? = null, //FK
)

//fun NetworkSession.asEntity() = SessionEntity(
//    sessionId = sessionId,
//    startDateTime = startDateTime.toString(),
//    endDateTime = endDateTime.toString(),
//    cancelledDate = cancelledDate.toString(),
//    cancelAccommodation = cancelAccommodation,
//    sessionRequestId = sessionId, // Foreign Key
//)


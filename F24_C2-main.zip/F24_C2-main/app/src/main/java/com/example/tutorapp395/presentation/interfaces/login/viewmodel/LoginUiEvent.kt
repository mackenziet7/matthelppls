package com.example.tutorapp395.presentation.interfaces.login.viewmodel

sealed class LoginUiEvent {
    data class UsernameChanged( val username: String) : LoginUiEvent()
    data class PasswordChanged( val password: String) : LoginUiEvent()
    data class RememberChanged(val rememberMe: Boolean) : LoginUiEvent()

    object LoginButtonClicked : LoginUiEvent()
    object Reset : LoginUiEvent()
}


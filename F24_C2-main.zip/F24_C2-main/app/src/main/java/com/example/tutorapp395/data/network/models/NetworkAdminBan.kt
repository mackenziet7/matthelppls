package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkAdminBan(
    val adminId: String,
    val banDateTime: Date,
    val unbanDateTime: Date,
    val reason: String,
    val content: String,
    )

//fun NetworkAdminBan.asEntity() = AdminBanEntity(
//    userId = userId, // PK, FK
//    banDateTime = banDateTime.toString(),
//    unbanDateTime = unbanDateTime.toString(),
//    reason = reason,
//    content = content,
//)
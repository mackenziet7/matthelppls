package com.example.tutorapp395.interfaces.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FullNameTextComponent(firstName: String, lastName: String) {
    val fullName = "$firstName $lastName"
    Text(text = fullName,
        modifier = Modifier
            .heightIn(min = 40.dp)
            .padding(top = 5.dp, bottom = 5.dp, end = 10.dp),
        style = MaterialTheme.typography.titleLarge,
    )

}
package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Qualifications
import java.util.UUID

@Entity(tableName = "qualifications", foreignKeys = [ForeignKey(
    entity = TutorEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])data class QualificationsEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val qualificationsId: String, // PK
    @ColumnInfo(index = true)
    val degree: String,
    @ColumnInfo(index = true)
    val startDate: String,
    @ColumnInfo(index = true)
    val endDate: String,
    @ColumnInfo(index = true)
    val institute: String,
    @ColumnInfo(index = true)
    val sortIndex: Int,
    @ColumnInfo(index = true)
    val userId: String // FK
)

fun QualificationsEntity.asExternalModel() = Qualifications(
    qualificationsId = qualificationsId, // PK
    degree = degree,
    startDate = startDate,
    endDate = endDate,
    institute = institute,
    sortIndex = sortIndex,
    userId = userId // FK
)
package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.SessionDeclined
import java.util.UUID

@Entity(tableName = "sessionDeclined", foreignKeys = [ForeignKey(
    entity = SessionRequestEntity::class,
    parentColumns = arrayOf("sessionRequestId"),
    childColumns = arrayOf("sessionRequestId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
), ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE)
])data class SessionDeclinedEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val sessionRequestId: String, //PK, FK
    @ColumnInfo(index = true)
    val declinedDateTime: String,
    @ColumnInfo(index = true)
    val reason: String,
    @ColumnInfo(index = true)
    val content: String,
    @ColumnInfo(index = true)
    val userId: String, // FK
)

fun SessionDeclinedEntity.asExternalModel() = SessionDeclined(
    sessionRequestId = sessionRequestId, //PK, FK
    declinedDateTime = declinedDateTime,
    reason = reason,
    content = content,
    userId = userId, // FK
)

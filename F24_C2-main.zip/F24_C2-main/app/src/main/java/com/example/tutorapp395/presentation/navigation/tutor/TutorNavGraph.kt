package com.example.tutorapp395.presentation.navigation.tutor

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.interfaces.tutor.TutorMonthlyAvailabilityScreen
import com.example.tutorapp395.presentation.interfaces.tutor.TutorProfileScreen
import com.example.tutorapp395.interfaces.tutor.TutorMainScreen
import com.example.tutorapp395.interfaces.tutor.TutorUnavailabilityScreen
import com.example.tutorapp395.presentation.interfaces.tutor.EditTutorProfileScreen
import com.example.tutorapp395.presentation.interfaces.tutor.TutorSubmissionScreen
import com.example.tutorapp395.presentation.navigation.common.Chat
import com.example.tutorapp395.presentation.navigation.common.EditTutorProfile
import com.example.tutorapp395.presentation.navigation.common.Profile
import com.example.tutorapp395.presentation.navigation.common.TutorMain
import com.example.tutorapp395.presentation.navigation.common.TutorSubmission
import com.example.tutorapp395.presentation.navigation.common.TutorUnavailabilitySubmission
import com.example.tutorapp395.presentation.navigation.common.TutorWeeklySubmission


@Composable
fun TutorNavGraph(navController: NavHostController, userId: String) {
    val modifier = Modifier
        .padding(top = 85.dp)
        .fillMaxSize()
    NavHost(
        navController = navController,
        startDestination = TutorMain
    ) {
        composable<TutorMain> {
            TutorMainScreen(navController)
        }
        composable<Profile> {
            TutorProfileScreen(navController, modifier, "My Profile")
        }

        composable<EditTutorProfile> {
            EditTutorProfileScreen(navController, modifier)
        }

        composable<TutorSubmission> {
            TutorSubmissionScreen(navController)
        }
        composable<TutorUnavailabilitySubmission> {
            TutorUnavailabilityScreen(navController)
        }
        composable<TutorWeeklySubmission> {
            TutorMonthlyAvailabilityScreen(navController)
        }

    }

}

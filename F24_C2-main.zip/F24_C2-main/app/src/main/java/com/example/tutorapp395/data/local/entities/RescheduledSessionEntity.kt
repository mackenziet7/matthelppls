package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.RescheduledSession

@Entity(tableName = "rescheduledSession", foreignKeys = [ForeignKey(
    entity = SessionEntity::class,
    parentColumns = arrayOf("sessionId"),
    childColumns = arrayOf("cancelledSessionId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])data class RescheduledSessionEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val cancelledSessionId: String, //PK, FK -> Session
    @ColumnInfo(index = true)
    val newSessionId: String
)

fun RescheduledSessionEntity.asExternalModel() = RescheduledSession(
    cancelledSessionId = cancelledSessionId, //PK, FK -> Session
    newSessionId = newSessionId
)

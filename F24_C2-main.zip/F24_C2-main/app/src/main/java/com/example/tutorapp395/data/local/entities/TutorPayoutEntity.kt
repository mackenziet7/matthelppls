package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.TutorPayout

@Entity(tableName = "tutorPayout", foreignKeys = [ForeignKey(
    entity = SessionEntity::class,
    parentColumns = arrayOf("sessionId"),
    childColumns = arrayOf("sessionId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class TutorPayoutEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val tutorPayoutId: String, // PK
    @ColumnInfo(index = true)
    val payoutTotal: Float,
    @ColumnInfo(index = true)
    val payoutDateTime: String,
    @ColumnInfo(index = true)
    val paymentStatus: String,
    @ColumnInfo(index = true)
    val sessionId: String, // FK
)

fun TutorPayoutEntity.asExternalModel() = TutorPayout(
    tutorPayoutId = tutorPayoutId, // PK
    payoutTotal = payoutTotal,
    payoutDateTime = payoutDateTime,
    paymentStatus = paymentStatus,
    sessionId = sessionId,
)
package com.example.tutorapp395.presentation.interfaces.admin.viewmodel

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.usecase.RegisterUseCase
import com.example.tutorapp395.domain.usecase.UnexpectedResult
import com.example.tutorapp395.domain.usecase.UserAnalyticsUseCase
import com.example.tutorapp395.domain.usecase.ViewUserAccountsUseCase
import com.example.tutorapp395.presentation.navigation.common.viewmodel.SimpleProfileState
import com.example.tutorapp395.presentation.navigation.common.viewmodel.asSimpleProfileState
import com.example.tutorapp395.utils.Validator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(
    private val registerUseCase: RegisterUseCase,
    private val viewUserAccountsUseCase: ViewUserAccountsUseCase,
    private val userAnalyticsUseCase: UserAnalyticsUseCase
) : ViewModel() {

    // Register admin/tutor Screen
    private val _createAccountState: MutableStateFlow<CreateAccountUiState> = MutableStateFlow(
        CreateAccountUiState())
    val createNewAccountState: StateFlow<CreateAccountUiState> = _createAccountState.asStateFlow()

    // View Accounts Screen (main screen 2nd button of bottom bar)
    private val _viewUserAccountsState: MutableStateFlow<ViewUserAccountsUiState> = MutableStateFlow(
        ViewUserAccountsUiState())
    val viewUserAccountsState: StateFlow<ViewUserAccountsUiState> = _viewUserAccountsState.asStateFlow()




    // Reduces chance of user changing a state
    fun sendCreateAccountEvent(event: CreateAccountUiEvent) {
        reduceCreateAccount(event = event, oldState = createNewAccountState.value)
    }

    fun sendViewUserAccountEvent(event: ViewAccountsUiEvent) {
        when (event){
            ViewAccountsUiEvent.ShowAllUserAccounts -> {
                viewModelScope.launch {
                    getAllUserAccounts(_viewUserAccountsState.value)
                }
            }
        }
    }

    fun setViewUserAccounts(newState: ViewUserAccountsUiState){
        _viewUserAccountsState.value = newState
    }

    private suspend fun getAllUserAccounts(oldState: ViewUserAccountsUiState) {
        val newAccounts: MutableList<SimpleProfileState> = ArrayList()
        when (val result = viewUserAccountsUseCase.invoke()) {
            is Result.Failure -> { // Failed to connect to database
                Log.d(TAG, "CONNECTION FAILURE")
                setViewUserAccounts(
                    _viewUserAccountsState.value.copy(
                        isLoading = false,
                    )
                )
            }

            is Result.Success -> {
                if (result.data.isEmpty()) { // Username exists
                    Log.d(TAG, "No user accounts found in the database")
                    setViewUserAccounts(
                        oldState.copy(
                            isLoading = false,
                            noAccountFoundError = true,
                        )
                    )
                } else {

                    for (item in result.data){
                        if (item != null) {
                            var label = "Student"
                            if (item.isAdmin == true) {label = "Admin"}
                            if (item.isTutor == true) {label = "Tutor"}
                            newAccounts.add(item.asSimpleProfileState(label))
                        }
                    }
                    Log.d(TAG, "${oldState.accounts}")
                    Log.d(TAG, "Accounts found")
                    setViewUserAccounts(
                        oldState.copy(
                            isLoading = false,
                            accounts = newAccounts
                        )
                    )
                }
            }
        }
    }

    private fun reduceCreateAccount(event: CreateAccountUiEvent, oldState: CreateAccountUiState) {
        when (event) {
            is CreateAccountUiEvent.AdminTutorChanged -> {
                Log.d(TAG, "${createNewAccountState.value}+++++${event.isAdmin}")
                setCreateAccountState(
                    createNewAccountState.value.copy(
                        isAdmin = event.isAdmin,
                    )
                )
            }

            is CreateAccountUiEvent.UsernameChanged -> {
                // Validate username
                val usernameResult = Validator.validateUsername(event.username)
                val usernameExistingResult =
                    Validator.validateUsernameExisting(event.username, oldState.existingUsernames)
                setCreateAccountState(
                    createNewAccountState.value.copy(
                        username = event.username,
                        usernameError = !usernameResult.status,
                        existingUsernameError = !usernameExistingResult.status
                    )
                )
            }
            is CreateAccountUiEvent.EmailChanged -> {
                val emailResult = Validator.validateUsername(event.email)
                setCreateAccountState(
                    createNewAccountState.value.copy(
                        email = event.email,
                        emailError = !emailResult.status
                    )
                )
            }
            is CreateAccountUiEvent.FirstNameChanged -> {
                val firstNameResult = Validator.validateUsername(event.firstName)
                setCreateAccountState(
                    createNewAccountState.value.copy(
                        firstName = event.firstName,
                        firstNameError = !firstNameResult.status
                    )
                )
            }
            is CreateAccountUiEvent.LastNameChanged -> {
                val lastNameResult = Validator.validateUsername(event.lastName)
                setCreateAccountState(
                    createNewAccountState.value.copy(
                        lastName = event.lastName,
                        lastNameError = !lastNameResult.status
                    )
                )
            }
            is CreateAccountUiEvent.PasswordChanged -> {
                val passwordMatchResult = Validator.validatePasswordMatch(event.password, oldState.password2)
                // Validate password
                val passwordResult = Validator.validatePassword(event.password)
                setCreateAccountState(oldState.copy(
                    passwordMismatchError = !passwordMatchResult.status,
                    password = event.password,
                    passwordError = !passwordResult.status))
            }

            is CreateAccountUiEvent.Password2Changed -> {
                // Check if passwords match
                val passwordMatchResult = Validator.validatePasswordMatch(oldState.password, event.password2)
                // Validate re-entered password
                val password2Result = Validator.validatePassword(event.password2)
                setCreateAccountState(oldState.copy(
                    passwordMismatchError = !passwordMatchResult.status,
                    password2 = event.password2,
                    password2Error = !password2Result.status))
            }
            CreateAccountUiEvent.CreateAccountButtonClicked -> {
                Log.d(TAG, "Setting up account...")
                if (setupNewAccountValid()){
                    viewModelScope.launch {
                        createAccount(oldState)
                    }
                }
            }

            CreateAccountUiEvent.Reset -> {
                setCreateAccountState(CreateAccountUiState())
            }

        }
        // cannot user oldState due to previous changes in when(event)
        setCreateAccountState( // Enables button if inputs are valid/ disables if invalid
            createNewAccountState.value.copy(
                createAccountButtonEnabled = setupNewAccountValid()
            )
        )
        Log.d(TAG, "${createNewAccountState.value}")

    }

    private fun setCreateAccountState(newState: CreateAccountUiState){
        _createAccountState.value = newState
    }

    private fun setupNewAccountValid(): Boolean {
        val usernameResult = Validator.validateUsername(createNewAccountState.value.username)
        val usernameExistingResult = Validator.validateUsernameExisting(createNewAccountState.value.username, createNewAccountState.value.existingUsernames)
        val emailResult = Validator.validateUsername(createNewAccountState.value.email)
        val firstNameResult = Validator.validateUsername(createNewAccountState.value.firstName)
        val lastNameResult = Validator.validateUsername(createNewAccountState.value.lastName) // Validate password
        val passwordResult = Validator.validatePassword(createNewAccountState.value.password)
        val passwordMatchResult = Validator.validatePasswordMatch(createNewAccountState.value.password, createNewAccountState.value.password2)
        val password2Result = Validator.validatePassword(createNewAccountState.value.password2)

        return usernameResult.status
                && usernameExistingResult.status
                && emailResult.status
                && firstNameResult.status
                &&lastNameResult.status
                && passwordResult.status
                && password2Result.status
                && passwordMatchResult.status
    }

    private suspend fun createAccount(oldState: CreateAccountUiState){
        when (val result = registerUseCase(createNewAccountState.value.asExternalModel())) {
            is Result.Failure -> { // Failed to connect to database
                Log.d(TAG, "CONNECTION FAILURE")
                setCreateAccountState(
                    oldState.copy(
                        isLoading = false,
                    )
                )
            }
            is Result.Success -> { // Username exists
                Log.d(TAG, "Username Exists")
                if (result.data == UnexpectedResult.ExistingInput) { // Username exists
                    oldState.existingUsernames.add(oldState.username)
                    setCreateAccountState(
                        oldState.copy(
                            isLoading = false,
                            existingUsernameError = true,
                        )
                    )
                }
                else { // Successfully created user
                    Log.d(TAG, "Created User")
                    setCreateAccountState(
                        oldState.copy(
                            isLoading = false,
                            registerSuccessful = true,
                            retrievedUserId = result.data.toString()
                        )
                    )
                }
            }
        }
    }
}


package com.example.tutorapp395.interfaces.tutor

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import java.text.SimpleDateFormat
import java.util.*

data class Unavailability(
    val start: String,
    val end: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            TutorUnavailabilityScreen(navController)
        }
    }
}

@Composable
fun TutorUnavailabilityScreen(navController: NavController) {
    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }
    var unavailabilityList by remember { mutableStateOf(listOf<Unavailability>()) }

    var showStartDatePicker by remember { mutableStateOf(false) }
    var showStartTimePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }
    var showEndTimePicker by remember { mutableStateOf(false) }

    val calendar = Calendar.getInstance()
    var startYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
    var startMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
    var startDay by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }
    var startHour by remember { mutableStateOf(calendar.get(Calendar.HOUR_OF_DAY)) }
    var startMinute by remember { mutableStateOf(calendar.get(Calendar.MINUTE)) }

    var endYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
    var endMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
    var endDay by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }
    var endHour by remember { mutableStateOf(calendar.get(Calendar.HOUR_OF_DAY)) }
    var endMinute by remember { mutableStateOf(calendar.get(Calendar.MINUTE)) }

    Box(modifier = Modifier.fillMaxSize()) {
        SubTopBar(navController, "Unavailable Date")

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 90.dp)
                .padding(vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Upcoming:", fontSize = 20.sp, modifier = Modifier.padding(bottom = 15.dp).align(Alignment.Start))

            // Display list of all unavailability dates as cards
            LazyColumn(modifier = Modifier.height(400.dp)) {
                items(unavailabilityList) { unavailability ->
                    UnavailabilityCard(unavailability = unavailability)
                }
            }

            Text(text = "Select Start Date and Time:", fontSize = 18.sp)
            Row {
                TextButton(onClick = { showStartDatePicker = true }) {
                    Text(text = if (startDate.isEmpty()) "Pick Start Date" else startDate.split(" ")[0])
                }
                TextButton(onClick = { showStartTimePicker = true }) {
                    Text(text = if (startDate.isEmpty()) "Pick Start Time" else startDate.split(" ")[1])
                }
            }

            Text(text = "Select End Date and Time:", fontSize = 18.sp)
            Row {
                TextButton(onClick = { showEndDatePicker = true }) {
                    Text(text = if (endDate.isEmpty()) "Pick End Date" else endDate.split(" ")[0])
                }
                TextButton(onClick = { showEndTimePicker = true }) {
                    Text(text = if (endDate.isEmpty()) "Pick End Time" else endDate.split(" ")[1])
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = {
                    if (startDate.isNotBlank() && endDate.isNotBlank()) {
                        unavailabilityList = unavailabilityList + Unavailability(startDate, endDate)
                        startDate = ""
                        endDate = ""
                    }
                }) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Add Unavailability",
                        modifier = Modifier
                            .size(50.dp)
                            .border(1.dp, Color.DarkGray, RoundedCornerShape(5.dp))
                            .background(Color.White, RoundedCornerShape(5.dp))
                    )
                }
            }
        }
    }

    if (showStartDatePicker) {
        DatePickerDialog(
            LocalContext.current,
            { _, year, month, dayOfMonth ->
                startYear = year
                startMonth = month
                startDay = dayOfMonth
                startDate = formatDateTime(startYear, startMonth, startDay, startHour, startMinute)
                showStartDatePicker = false
            },
            startYear, startMonth, startDay
        ).show()
    }

    if (showStartTimePicker) {
        TimePickerDialog(
            LocalContext.current,
            { _, hourOfDay, minute ->
                startHour = hourOfDay
                startMinute = minute
                startDate = formatDateTime(startYear, startMonth, startDay, startHour, startMinute)
                showStartTimePicker = false
            },
            startHour, startMinute, false
        ).show()
    }

    if (showEndDatePicker) {
        DatePickerDialog(
            LocalContext.current,
            { _, year, month, dayOfMonth ->
                endYear = year
                endMonth = month
                endDay = dayOfMonth
                endDate = formatDateTime(endYear, endMonth, endDay, endHour, endMinute)
                showEndDatePicker = false
            },
            endYear, endMonth, endDay
        ).show()
    }

    if (showEndTimePicker) {
        TimePickerDialog(
            LocalContext.current,
            { _, hourOfDay, minute ->
                endHour = hourOfDay
                endMinute = minute
                endDate = formatDateTime(endYear, endMonth, endDay, endHour, endMinute)
                showEndTimePicker = false
            },
            endHour, endMinute, false
        ).show()
    }
}

private fun formatDateTime(year: Int, month: Int, day: Int, hour: Int, minute: Int): String {
    val calendar = Calendar.getInstance().apply {
        set(year, month, day, hour, minute)
    }
    val formatter = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())
    return formatter.format(calendar.time)
}

@Composable
fun UnavailabilityCard(unavailability: Unavailability) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, Color.Gray, RoundedCornerShape(10.dp)),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "From:", fontSize = 16.sp)
            Text(text = unavailability.start, fontSize = 14.sp, modifier = Modifier.padding(start = 30.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "To:", fontSize = 16.sp)
            Text(text = unavailability.end, fontSize = 14.sp, modifier = Modifier.padding(start = 30.dp))
        }
    }
}

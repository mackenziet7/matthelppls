package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkSessionRequest(
    val sessionRequestId: String? = null, // PK
    val requestDateTime: String? = null,
    val acceptDateTime: String? = null,
    val confirmDateTime: String? = null,
    val startDateTime: String? = null,
    val endDateTime: String? = null,
    val totalDays: Int? = null,
    val totalHours: Int? = null,
    val totalCost: Float? = null,
    val gradeLevel: String,
    val subject: String? = null, // FK
    val chatId: String,

    val tutorUserId: String? = null, // FK - userId
    val studentUserId: String? = null, // FK - userId

    val studentColorLabel: String,
    val tutorColorLabel: String,
    )

//fun NetworkSessionRequest.asEntity() = SessionRequestEntity(
//    sessionRequestId = sessionRequestId, // PK
//    requestDateTime = requestDateTime.toString(),
//    acceptDateTime = acceptDateTime.toString(),
//    confirmDateTime = confirmDateTime.toString(),
//    startDateTime = startDateTime.toString(),
//    endDateTime = endDateTime.toString(),
//    totalHours = totalHours,
//    totalCost = totalCost,
//    gradeLevel = gradeLevel,
//    subjectId = subjectId, // FK
//    tutorUserId = tutorUserId, // FK - userId
//    studentUserId = tutorUserId, // FK - userId
//)

package com.example.tutorapp395.presentation.interfaces.student.viewmodel

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.SessionRequestRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.domain.usecase.FindATutorUseCase
import com.example.tutorapp395.domain.usecase.RegisterUseCase
import com.example.tutorapp395.domain.usecase.UnexpectedResult
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginUiState
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.asExternalModel
import com.example.tutorapp395.presentation.uistate.StudentFindATutorUIState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.time.delay
import java.time.Duration
import javax.inject.Inject

@HiltViewModel
class StudentViewModel @Inject constructor(
    private val studentAvailabilityRepository: StudentAvailabilityRepository,
    private val sessionRequestRepository: SessionRequestRepository,
    private val findATutorUseCase: FindATutorUseCase
) : ViewModel() {
    private val _findATutorState: MutableStateFlow<FindATutorUiState> = MutableStateFlow(FindATutorUiState())
    val findATutorState: StateFlow<FindATutorUiState> = _findATutorState.asStateFlow()

    fun setFindTutorState(newSTate: FindATutorUiState){
        _findATutorState.value = newSTate
    }
    fun sendFindATutorEvent(event: FindATutorUiEvent){
        when (event){
            FindATutorUiEvent.submitClicked -> {
                viewModelScope.launch {
                    delay(Duration.ofSeconds(3))

                }
            }

            FindATutorUiEvent.reset -> TODO()
        }
    }

    //TODO()
    suspend fun createNewSessionRequest(){
        findATutorUseCase.invoke(User())
    }

}
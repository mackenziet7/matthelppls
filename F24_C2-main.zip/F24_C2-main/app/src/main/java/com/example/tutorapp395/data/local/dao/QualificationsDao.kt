package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.QualificationsEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface QualificationsDao {
    @Query("SELECT * FROM qualifications")
    fun getAll(): List<QualificationsEntity>

    @Insert
    fun insertAll(vararg qualifications: QualificationsEntity)

    @Delete
    fun delete(qualifications: QualificationsEntity)

    @Update
    fun update(qualifications: QualificationsEntity)
    
    @Query("DELETE FROM qualifications")
    fun deleteAllValuesInTable()
}
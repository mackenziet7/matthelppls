package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.Message
import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.model.asNetworkModel
import com.example.tutorapp395.data.network.models.NetworkMessage
import com.example.tutorapp395.data.network.models.NetworkStudentAvailability
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.MessageRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_MESSAGE
import com.example.tutorapp395.utils.COLLECTION_PATH_QUALIFICATIONS
import com.example.tutorapp395.utils.COLLECTION_PATH_STUDENT_AVAILABILITY
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class MessageCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): MessageRepository {
    override fun getMessages(): Flow<List<NetworkMessage>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertMessage(message: Message): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_MESSAGE).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkMessage = message.copy(messageId = id).asNetworkModel()
                Log.d(TAG, "$networkMessage")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_MESSAGE)
                        .document(id)
                        .set(networkMessage)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }

    override suspend fun getAllMessagesByUserId(): Result<List<NetworkMessage?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_MESSAGE)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkMessage>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteMessage(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_MESSAGE)
                        .document(id)
                        .delete()
                }
                if (deleteTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateMessage(message: Message): Result<Unit> {
        return try {
            val modifiedMessage = message.asNetworkModel()
            withContext(ioDispatcher) {
                val updateTimeout = withTimeoutOrNull(10000L){
                    modifiedMessage.messageId?.let {
                        cloudDb.collection(COLLECTION_PATH_MESSAGE)
                            .document(it)
                            .set(modifiedMessage)
                    }
                }
                if (updateTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
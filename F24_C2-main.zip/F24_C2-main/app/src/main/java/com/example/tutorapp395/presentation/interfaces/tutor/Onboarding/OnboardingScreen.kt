package com.example.tutorapp395.presentation.interfaces.tutor.Onboarding

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter


@Composable
fun OnboardingScreen(onComplete: () -> Unit) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "onboarding1"
    ) {
        composable("onboarding1") {
            OnboardingStep1(onNext = { navController.navigate("onboarding2") })
        }
        composable("onboarding2") {
            OnboardingStep2(onNext = { navController.navigate("onboarding3") })
        }

        composable("onboarding3") {
            OnboardingStep3(onComplete = onComplete)
        }
    }
}

//@Preview(name = "Onboarding Step 1", showBackground = true)
@Composable
fun OnboardingStep1(onNext: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome to the app!")
        Text("Lets go through a few things before we begin.")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onNext) {
            Text("Next")
        }
    }
}

//@Preview(name = "Onboarding Step 2", showBackground = true)
@Composable
fun OnboardingStep2(
    onNext: () -> Unit = {},
    googleDriveLink: String = "https://drive.google.com/drive/folders/1fms6MEViZ5VuEPqSZE8_1b7s2i6TWh3z"
) {
    val context = LocalContext.current
    var isAcknowledged by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("First, please watch and save the videos and manuals in the following link:")
        Spacer(modifier = Modifier.height(8.dp))
        ClickableText(
            text = AnnotatedString("Google Drive Link"),
            style = TextStyle(
                color = MaterialTheme.colorScheme.primary,
                textDecoration = TextDecoration.Underline
            ),
            onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(googleDriveLink))
                context.startActivity(intent) // Correctly uses LocalContext here
            }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isAcknowledged,
                onCheckedChange = { isAcknowledged = it }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("I have watched the videos and read the manuals.")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onNext,
            enabled = isAcknowledged // Button is enabled only if the checkbox is checked
        ) {
            Text("Next")
        }
    }
}

@Preview(name = "Onboarding Step 3", showBackground = true)
@Composable
fun OnboardingStep3(onComplete: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Just a few more things!")
        Spacer(modifier = Modifier.height(16.dp))
        Text("When you enter the app be sure to add your availability and")
        Text( "complete your profile so you can start helping students")
        Spacer(modifier = Modifier.height(16.dp))
        Text("You're all set!.")
        Text("Thank you for choosing our app!.")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onComplete) {
            Text("Finish")
        }
    }
}

package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

import com.example.tutorapp395.domain.CalendarUseCase
import com.example.tutorapp395.interfaces.components.CalendarContent
import com.example.tutorapp395.interfaces.components.CalendarHeader
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter


// a sub-main screen that shows the calendar screen : can be reused for all users

/**
 * Based on the calendar app created by meyta.taliti.
 */


@Preview(showBackground = true)
@Composable
fun CalendarScreenPreview() {
    CalendarScreen(
        modifier = Modifier.fillMaxSize(),
        onSelectedDateChange = {}
    )
}

//temp class to help display events
data class Event(
    val title: String,
    val date: LocalDate,
    val startTime: String, // You can use LocalTime if needed
    val endTime: String, // You can use LocalTime if needed
    val Topic: String
)


@Composable
fun CalendarScreen(
    modifier: Modifier = Modifier,
    onSelectedDateChange: (LocalDate) -> Unit = {}
) {
    val dataSource = CalendarUseCase()
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var calendarUiModel by remember { mutableStateOf(dataSource.getMonthData(currentMonth)) }

    // Sample events list
    val allEvents = listOf(
        Event("Session 1", LocalDate.of(2024, 11, 3), "10:00 AM", "11:00 AM", "English 12"),
        Event("Session 2", LocalDate.of(2024, 11, 20), "01:00 PM", "02:00 PM","Math 12"),
        Event("Session 3", LocalDate.of(2024, 11, 22), "03:00 PM", "04:00 PM","Science 10"),
        Event("Session 4", LocalDate.of(2024, 11, 10), "09:00 AM", "10:00 AM","Physics 11") // Past event for testing
    )

    // Track selected date and toggle for all events
    var selectedDate by remember { mutableStateOf<LocalDate?>(LocalDate.now()) }
    var showAllEventsInMonth by remember { mutableStateOf(false) }

    // Displayed events based on selectedDate and showAllEventsInMonth toggle
    val displayedEvents = if (showAllEventsInMonth) {
        allEvents.filter { it.date.month == currentMonth.month } // Show all events in the month
    } else {
        allEvents.filter { it.date == selectedDate } // Show only events for the selected date
    }

    // Wrap the content in a Box with a limited height
    Box(
        modifier = modifier
            .padding(16.dp)
            .fillMaxWidth()
            .heightIn(min = 400.dp, max = 375.dp) // Adjust the height range as needed
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            CalendarHeader(
                currentMonth = currentMonth,
                onPrevClickListener = {
                    currentMonth = currentMonth.minusMonths(1)
                    calendarUiModel = dataSource.getMonthData(currentMonth)
                },
                onNextClickListener = {
                    currentMonth = currentMonth.plusMonths(1)
                    calendarUiModel = dataSource.getMonthData(currentMonth)
                }
            )

            // Content
            CalendarContent(
                data = calendarUiModel,
                events = allEvents, // Pass all events to highlight on the calendar
                onDateClickListener = { date ->
                    selectedDate = date.date
                    showAllEventsInMonth = false // Reset to show only selected date's events
                    calendarUiModel = calendarUiModel.copy(
                        selectedDate = date,
                        visibleDates = calendarUiModel.visibleDates.map {
                            it.copy(isSelected = it.date.isEqual(date.date))
                        }
                    )
                    onSelectedDateChange(date.date)
                }
            )

            // Button to toggle displaying all events in the month
            Button(onClick = {
                showAllEventsInMonth = !showAllEventsInMonth
            }) {
                Text(text = if (showAllEventsInMonth) "Show Only Selected Date" else "Show All Events in Month")
            }

            // add the EventList
            EventList(events = displayedEvents, currentMonth = currentMonth)
        }
    }
}


@Composable
fun EventList(events: List<Event>, currentMonth: YearMonth) {
    Column {
        Text(
            text = "Sessions",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(8.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize() // Makes the list fill the available space
        ) {
            items(events.filter { it.date.month == currentMonth.month }) { event ->
                Card(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.LightGray) // Grey background
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = event.title,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Text(
                                text = "Topic: ${event.Topic}",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        Text(
                            text = "Date: ${event.date.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Text(
                            text = "Start: ${event.startTime}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "End: ${event.endTime}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}



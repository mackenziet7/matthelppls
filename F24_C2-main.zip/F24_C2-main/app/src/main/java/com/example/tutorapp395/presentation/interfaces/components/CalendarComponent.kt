package com.example.tutorapp395.interfaces.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.tutorapp395.presentation.navigation.common.Event
import com.example.tutorapp395.presentation.uistate.CalendarUiState
import java.time.YearMonth
import java.time.format.DateTimeFormatter


@Composable
fun CalendarHeader(
    currentMonth: YearMonth, // Pass the currentMonth variable here
    onPrevClickListener: () -> Unit,
    onNextClickListener: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrevClickListener) {
            Icon(
                imageVector = Icons.Filled.ChevronLeft,
                contentDescription = "Previous month"
            )
        }
        // Format the currentMonth to display the proper month and year
        Text(
            text = currentMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.headlineSmall
        )
        IconButton(onClick = onNextClickListener) {
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "Next month"
            )
        }
    }
    // Add a spacer to increase the space between the weekday header and the calendar grid
    Spacer(modifier = Modifier.height(16.dp))
}

@Composable
fun CalendarContent(
    data: CalendarUiState,
    events: List<Event>, // Add events as a parameter
    onDateClickListener: (CalendarUiState.Date) -> Unit,
) {
    val weekdays = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    Column {
        // Weekday Header remains the same...

        // Calculate how many empty boxes we need at the start of the calendar
        val firstDayOfWeek = data.visibleDates.first().date.dayOfWeek.value % 7

        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            contentPadding = PaddingValues(8.dp)
        ) {
            // Add empty boxes for the preceding days from the previous month
            items(firstDayOfWeek) {
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .aspectRatio(1f) // Maintain a square aspect ratio
                ) {
                    // Leave this box empty to represent the blank space
                }
            }

            // Now, display the actual dates for the current month
            items(data.visibleDates) { date ->
                ContentItem(
                    date = date,
                    events = events, // Pass events here
                    onClickListener = onDateClickListener
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentItem(
    date: CalendarUiState.Date,
    events: List<Event>, // Add events as a parameter
    onClickListener: (CalendarUiState.Date) -> Unit,
) {
    // Check if there are any events for this date
    val hasEvent = events.any { it.date.isEqual(date.date) }

    Card(
        modifier = Modifier
            .padding(4.dp)
            .aspectRatio(1f)
            .clickable { onClickListener(date) },
        colors = CardDefaults.cardColors(
            containerColor = when {
                hasEvent -> Color(0xFF2196F3) // Purple color for days with events
                date.isSelected -> MaterialTheme.colorScheme.primary
                date.isToday -> MaterialTheme.colorScheme.secondary
                else -> MaterialTheme.colorScheme.surface
            }
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = date.date.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = if (date.isSelected || date.isToday || hasEvent) Color.White else Color.Unspecified
            )
        }
    }
}

package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.tutorapp395.interfaces.components.FullNameTextComponent
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.presentation.uistate.ContactsItem
import com.example.tutorapp395.presentation.uistate.InboxUIState

// a sub-main screen that shows the inbox : can be reused for all users
@Composable
fun SessionsScreen(modifier: Modifier) {

    val contacts = listOf(
        ContactsItem("Joe", "Foo", "yojipjjpijpijpijmmmmmmmmmm", "yesterday", "Math 12", "12", "123"),
        ContactsItem("Scott", "Williams", "hello", "yesterday", "Math 12", "12", "123"),
        ContactsItem("Lee", "Johnson", "...", "yesterday", "Math 12", "12", "123"),
        ContactsItem("Ryan", "Bone", "request", "yesterday", "Math 12", "12", "123"),
    )
    val inbox = InboxUIState(contacts)

    // Column Composable,
    LazyColumn(
        modifier = modifier,
        // Parameters set to place the items in center
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(inbox.contactsList) { item ->
            Row(
                modifier = Modifier
                    .height(150.dp)
                    .fillParentMaxWidth()
                    .border(
                        width = 0.1.dp,
                        color = Color.Gray,
                    ),
            ){
                Column(
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(top = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FullNameTextComponent(item.firstName, item.lastName)
                        LabelTextComponent(item.label)
                    }
                    Text(item.lastDateTime)

                    Text(item.lastMessage, color = Color.Gray)


                }

            }
        }
    }
}

package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.StudentAvailability
import java.util.UUID

@Entity(tableName = "studentAvailability",
    foreignKeys = [ForeignKey(
    entity = SessionRequestEntity::class,
    parentColumns = arrayOf("sessionRequestId"),
    childColumns = arrayOf("sessionRequestId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class StudentAvailabilityEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val studentAvailabilityId: String, // PK
    @ColumnInfo(index = true)
    val sessionRequestId: String, // FK
    @ColumnInfo(index = true)
    val weekday: String,
    @ColumnInfo(index = true)
    val startTime: String,
    @ColumnInfo(index = true)
    val sessionDuration: Int,
    @ColumnInfo(index = true)
    val endTime: String,
)

fun StudentAvailabilityEntity.asExternalModel() = StudentAvailability(
    studentAvailabilityId = studentAvailabilityId, // PK
    sessionRequestId = sessionRequestId , // FK
    weekday = weekday,
    sessionDuration = sessionDuration,
    startTime = startTime,
    endTime = endTime,
)
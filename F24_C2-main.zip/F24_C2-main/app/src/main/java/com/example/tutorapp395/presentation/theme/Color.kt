package com.example.tutorapp395.presentation.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.NavigationBarItemColors
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

sealed class ThemeColors(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val background: Color
) {
    data object StudentTheme: ThemeColors(
        primary = Purple80,
        secondary = Purple80,
        tertiary = Purple80,
        background = Purple80
    )
    data object TutorTheme: ThemeColors(
        primary = Purple40,
        secondary = Pink40,
        tertiary = Purple80,
        background = Purple80
    )
    data object AdminTheme: ThemeColors(
        primary = Purple40,
        secondary = Pink40,
        tertiary = Purple80,
        background = Purple80
    )
}
val Blue40 = Color(0xff4353d0)
val greyBlue = Color(0xff5f627f)
val Lightblue = Color(0xff4c56b2)

val Blue20 = Color(0xff8e98e7)
val greyBlue20 = Color(0xffc1c5eb)
val Lightblue20 = Color(0xffa6abd8)
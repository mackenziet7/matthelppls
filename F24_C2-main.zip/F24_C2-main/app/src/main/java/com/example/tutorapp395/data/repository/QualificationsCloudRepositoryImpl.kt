package com.example.tutorapp395.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.Qualifications

import com.example.tutorapp395.data.network.models.NetworkQualifications

import com.example.tutorapp395.data.network.models.asNetworkModel
import com.example.tutorapp395.di.modules.IoDispatcher
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.IllegalStateException
import javax.inject.Inject
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.QualificationsRepository
import com.example.tutorapp395.utils.COLLECTION_PATH_QUALIFICATIONS
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.tasks.await

class QualificationsCloudRepositoryImpl @Inject constructor(
    private val cloudDb: FirebaseFirestore,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
): QualificationsRepository {
    override fun getQualifications(): Flow<List<NetworkQualifications>> {
        TODO("Not yet implemented")
    }

    override suspend fun insertQualifications(qualifications: Qualifications): Result<String> {
        return try {
            withContext(ioDispatcher) {
                val docRef = cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS).document()
                val id = docRef.id
                Log.d(TAG, id)
                val networkQualifications = qualifications.copy(qualificationsId = id).asNetworkModel()
                Log.d(TAG, "$networkQualifications")

                val addUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS)
                        .document(id)
                        .set(networkQualifications)
                        .addOnSuccessListener { documentReference ->
                            Log.d(TAG, "Document Successfully added to collections $COLLECTION_PATH_QUALIFICATIONS with id: $id")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                }
                if (addUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(id)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)

        }
    }

    override suspend fun getAllQualifications(): Result<List<NetworkQualifications?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(100000L){
                    cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS)
                        .get()
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkQualifications>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun getQualificationsById(id: String): Result<List<NetworkQualifications?>> {
        return try {
            withContext(ioDispatcher){
                val fetchUsersTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS)
                        .whereEqualTo("qualificationsId", id)
                        .limit(1)
                        .get()
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Error adding document", e)
                        }
                        .await()
                        .documents.map{document ->
                            document.toObject<NetworkQualifications>()
                        }
                }
                if (fetchUsersTimeout == null) {
                    Result.Failure(IllegalStateException(CONNECTION_FAILED))
                }
                Result.Success(fetchUsersTimeout?.toList() ?: emptyList())
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun deleteQualifications(id: String): Result<Unit> {
        return try {
            withContext(ioDispatcher) {
                val deleteUserTimeout = withTimeoutOrNull(10000L){
                    cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS)
                        .document(id)
                        .delete()
                }
                if (deleteUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

    override suspend fun updateQualifications(qualifications: Qualifications): Result<Unit> {
        return try {
            val modifiedQualifications = qualifications.asNetworkModel()
            withContext(ioDispatcher) {
                val updateUserTimeout = withTimeoutOrNull(10000L){
                    modifiedQualifications.qualificationsId?.let {
                        cloudDb.collection(COLLECTION_PATH_QUALIFICATIONS)
                            .document(it)
                            .set(modifiedQualifications)
                    }
                }
                if (updateUserTimeout == null) {
                    Result.Failure(
                        IllegalStateException(
                            CONNECTION_FAILED
                        )
                    )
                }
                Result.Success(Unit)
            }
        } catch (exception: Exception) {
            Result.Failure(exception = exception)
        }
    }

}
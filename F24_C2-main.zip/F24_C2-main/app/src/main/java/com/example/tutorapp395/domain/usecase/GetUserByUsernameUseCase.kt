package com.example.tutorapp395.domain.usecase

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.network.models.NetworkUser
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.SideEffects
import com.example.tutorapp395.utils.Validator

//TODO - Create Use Cases to refactor code over at the view model if time
class GetUserByUsernameUseCase(
    private val repository: UserRepository
) {
    suspend operator fun invoke(
        username: String
    ): Result<List<NetworkUser?>> {
        return repository.getUserByUsername(username)
    }
}
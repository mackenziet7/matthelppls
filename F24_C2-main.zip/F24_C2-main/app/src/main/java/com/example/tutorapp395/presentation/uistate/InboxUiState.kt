package com.example.tutorapp395.presentation.uistate



data class InboxUIState(
    val contactsList: List<ContactsItem>
)

data class ContactsItem(
    val firstName: String,
    val lastName: String,
    val lastMessage : String,
    val lastDateTime: String,
    val label: String,

    val chatId: String,
    val sessionRequestId: String,
)

data class ChatUIState(
    val firstName: String,
    val lastName: String,
    val messageList: List<MessageItem>,
    val sessionRequest: SessionRequestUIState
)

data class MessageItem(
    val content: String,
    val type: String,
    val sentTime: String,
    val senderId: String,
)

data class SessionRequestUIState(
    val requestDate: String,
    val acceptDate: String,
    val confirmDate: String,
    val startDate: String,
    val endDate: String,
    val sessionCost: String,
    val totalHours: String,
    val subject: String,
    val level: String,
)
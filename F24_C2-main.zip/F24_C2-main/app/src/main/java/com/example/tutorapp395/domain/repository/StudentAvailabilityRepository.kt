package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.StudentAvailability
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkStudentAvailability
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface StudentAvailabilityRepository {
    fun getStudentAvailability(): Flow<List<StudentAvailability>>

    suspend fun insertStudentAvailability(studentAvailability: StudentAvailability): Result<String>

    suspend fun getAllStudentAvailabilities(): Result<List<NetworkStudentAvailability?>>
    suspend fun getStudentAvailabilityById(id: String):  Result<List<NetworkStudentAvailability?>>

    suspend fun deleteStudentAvailability(id: String): Result<Unit>

    suspend fun updateStudentAvailability(studentAvailability: StudentAvailability): Result<Unit>
}

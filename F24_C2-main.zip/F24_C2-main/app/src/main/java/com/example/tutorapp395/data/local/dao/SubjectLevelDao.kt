package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.SubjectLevelEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface SubjectLevelDao {
    @Query("SELECT * FROM subjectLevel")
    fun getAll(): List<SubjectLevelEntity>

    @Insert
    fun insertAll(vararg subjectLevel: SubjectLevelEntity)

    @Delete
    fun delete(subjectLevel: SubjectLevelEntity)

    @Update
    fun update(subjectLevel: SubjectLevelEntity)
    
    @Query("DELETE FROM subjectLevel")
    fun deleteAllValuesInTable()
}
package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.AdminBanEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface AdminBanDao {
    @Query("SELECT * FROM adminBan")
    fun getAll(): List<AdminBanEntity>

    @Insert
    fun insertAll(vararg adminBan: AdminBanEntity)

    @Delete
    fun delete(adminBan: AdminBanEntity)

    @Update
    fun update(adminBan: AdminBanEntity)
    
    @Query("DELETE FROM adminBan")
    fun deleteAllValuesInTable()
}
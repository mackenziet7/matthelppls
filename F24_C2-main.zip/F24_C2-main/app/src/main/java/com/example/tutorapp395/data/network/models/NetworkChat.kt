package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkChat(
    val chatId: String? = null, // PK
    val userOneId: String? = null,
    val userTwoId: String? = null,
    val lastMessage: String? = null,
    val lastDateTime: String? = null,
    val hasSeen: Boolean? = null
)

//fun NetworkChat.asEntity() = ChatEntity(
//    chatId = chatId,
//    userOneId = userOneId,
//    userTwoId = userTwoId,
//    lastMessage = lastMessage,
//    lastDateTime = lastDateTime.toString()
//)
package com.example.tutorapp395.presentation.interfaces.student.viewmodel

import com.example.tutorapp395.data.model.StudentAvailability

data class FindATutorUiState(
    val isLoading: Boolean = false,

    val studentAvailability: StudentAvailability = StudentAvailability(),
)
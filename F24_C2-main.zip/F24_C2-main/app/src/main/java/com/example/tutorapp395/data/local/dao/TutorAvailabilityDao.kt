package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.TutorAvailabilityEntity

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface TutorAvailabilityDao {
    @Query("SELECT * FROM tutorAvailability")
    fun getAll(): List<TutorAvailabilityEntity>

    @Insert
    fun insertAll(vararg tutorAvailability: TutorAvailabilityEntity)

    @Delete
    fun delete(tutorAvailability: TutorAvailabilityEntity)

    @Update
    fun update(tutorAvailability: TutorAvailabilityEntity)
    
    @Query("DELETE FROM tutorAvailability")
    fun deleteAllValuesInTable()
}
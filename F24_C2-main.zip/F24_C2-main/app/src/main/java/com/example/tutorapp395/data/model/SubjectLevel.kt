package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkSubjectLevel
import kotlinx.serialization.Serializable

data class SubjectLevel(
    val subjectLevelId: String? = null,
    val userId: String? = null,
    val subject: String? = null, // FK
    val gradeLevels: List<String>? = null,
    val sortIndex: Int? = null,
)


fun SubjectLevel.asNetworkModel() = NetworkSubjectLevel(
    subjectLevelId = subjectLevelId,
    userId = userId,
    gradeLevels = gradeLevels,
    subject = subject,
    sortIndex = sortIndex
)
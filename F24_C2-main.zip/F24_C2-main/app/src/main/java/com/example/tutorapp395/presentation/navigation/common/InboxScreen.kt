package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.tutorapp395.interfaces.components.FullNameTextComponent
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.presentation.navigation.common.Chat
import com.example.tutorapp395.presentation.uistate.ContactsItem
import com.example.tutorapp395.presentation.uistate.InboxUIState

@Composable
fun InboxScreen(mainNavController: NavController, navController: NavController, modifier: Modifier) {
    val contacts = listOf(
        ContactsItem("Joe", "Foo", "Sample message 1", "Yesterday", "Math 12", "12", "123"),
        ContactsItem("Scott", "Williams", "Sample message 2", "Yesterday", "Math 12", "12", "123"),
    )
    val inbox = InboxUIState(contacts)

    LazyColumn(
        modifier = Modifier
            .padding(top = 100.dp)
            .height(1000.dp)
            .background(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(40.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(vertical = 20.dp, horizontal = 20.dp),
    ) {
        items(inbox.contactsList) { item ->
            Row(
                modifier = Modifier
                    .padding(vertical = 5.dp)
                    .height(150.dp)
                    .fillParentMaxWidth()
                    .shadow(5.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.background)
                    .clickable {
                        navController.navigate(
                            route = Chat
                        )
                    }
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FullNameTextComponent(item.firstName, item.lastName)
                        Text(item.lastDateTime)
                    }
                    LabelTextComponent(item.label)
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(item.lastMessage, color = Color.Gray, maxLines = 2)
                }
            }
        }
        item { Spacer(modifier = Modifier.height(90.dp)) }
    }
}

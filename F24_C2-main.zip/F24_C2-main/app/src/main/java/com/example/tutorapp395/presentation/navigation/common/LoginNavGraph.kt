package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.presentation.interfaces.login.RegisterAccountScreen
import com.example.tutorapp395.presentation.interfaces.login.LoginForm
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginViewModel
import kotlinx.serialization.Serializable

// Main login Screen
@Serializable object Login

@Serializable object CreateAccount


@Composable
fun LoginNavGraph(navController: NavHostController) {
    val loginViewModel: LoginViewModel = hiltViewModel()
    NavHost(
        navController = navController,
        startDestination = Login
    ) {
        composable<Login> {
            LoginForm(navController = navController, loginViewModel)
        }
        composable<CreateAccount>{
            RegisterAccountScreen(navController = navController, loginViewModel)
        }
    }

}

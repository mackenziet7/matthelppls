package com.example.tutorapp395.data.network.models

import java.util.Date

data class NetworkRefundedSession(
    val refundedSessionId: String,
    val refundCost: Float,
    val refundZonedDateTime: Date,
    val refundStatus: String,
)

//fun NetworkRefundedSession.asEntity() = RefundedSessionEntity(
//    cancelledSessionId = cancelledSessionId, //PK, FK -> Session
//    refundCost = refundCost,
//    refundZonedDateTime = refundZonedDateTime.toString(),
//    refundStatus = refundStatus,
//)
package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.TutorPayoutEntity
import com.example.tutorapp395.data.model.TutorPayout
import com.example.tutorapp395.data.model.TutorWeeklyAvailability
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface TutorPayoutDao {
    @Query("SELECT * FROM tutorPayout")
    fun getAll(): List<TutorPayoutEntity>

    @Insert
    fun insertAll(vararg tutorPayout: TutorPayoutEntity)

    @Delete
    fun delete(tutorPayout: TutorPayoutEntity)

    @Update
    fun update(tutorPayout: TutorPayoutEntity)
    
    @Query("DELETE FROM tutorPayout")
    fun deleteAllValuesInTable()
}

package com.example.tutorapp395.data.network.models

import com.example.tutorapp395.data.local.entities.TutorPayoutEntity

import kotlinx.serialization.Serializable
import java.util.Date

data class NetworkTutorPayout(
    val tutorPayoutId: String,
    val payoutTotal: Float,
    val payoutDateTime: Date?,
    val paymentStatus: String,
    val sessionId: String, // FK
)

//fun NetworkTutorPayout.asEntity() = TutorPayoutEntity(
//    tutorPayoutId = tutorPayoutId, // PK
//    payoutTotal = payoutTotal,
//    payoutDateTime = payoutDateTime.toString(),
//    paymentStatus = paymentStatus,
//    sessionId = sessionId,
//)
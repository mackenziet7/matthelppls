package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.TutorAvailability

@Entity(tableName = "tutorAvailability", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])
data class TutorAvailabilityEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val tutorAvailabilityId: String, // PK
    @ColumnInfo(index = true)
    val updatedOnDateTime: String,
    @ColumnInfo(index = true)
    val month: Int,
    @ColumnInfo(index = true)
    val year: Int,
    @ColumnInfo(index = true)
    val userId: String, // FK
)
//
//fun TutorAvailabilityEntity.asExternalModel() = TutorAvailability(
//    tutorAvailabilityId = tutorAvailabilityId, // PK
//    updatedOnDateTime = updatedOnDateTime,
//    month = month,
//    year = year,
//    userId = userId
//)

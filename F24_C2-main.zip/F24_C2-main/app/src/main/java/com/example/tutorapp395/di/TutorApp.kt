package com.example.tutorapp395.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TutorApp: Application()
package com.example.tutorapp395.data.model

import com.example.tutorapp395.data.network.models.NetworkMessage
import java.util.Date

data class Message(
    val messageId: String? = null,
    val content: String? = null,
    val type: String? = null,
    val sentDateTime: String? = null,
    val senderId: String? = null, // FK
    val chatId: String? = null, //Fk
)

fun Message.asNetworkModel() = NetworkMessage(
    messageId = messageId,
    content = content,
    type = type,
    sentDateTime = sentDateTime,
    senderId = senderId,
    chatId = chatId,
)
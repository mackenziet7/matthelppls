package com.example.tutorapp395.data.network.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.local.entities.TutorAvailabilityEntity
import com.example.tutorapp395.data.model.Tutor
import com.example.tutorapp395.data.model.TutorAvailability
import kotlinx.serialization.Serializable
import java.time.ZonedDateTime
import java.util.Date

data class NetworkTutorAvailability(
    val tutorAvailabilityId: String? = null,
    val updatedOnDateTime: Date? = null,
    val month: Int? = null,
    val year: Int? = null,
    val userId: String? = null, // FK
)

//fun NetworkTutorAvailability.asEntity() = TutorAvailabilityEntity(
//    tutorAvailabilityId = tutorAvailabilityId, // PK
//    updatedOnDateTime = updatedOnDateTime.toString(),
//    month = month,
//    year = year,
//    userId = userId
//)

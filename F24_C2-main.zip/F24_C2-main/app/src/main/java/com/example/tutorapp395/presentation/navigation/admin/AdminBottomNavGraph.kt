package com.example.tutorapp395.presentation.navigation.admin

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tutorapp395.interfaces.admin.AdminAccountsScreen
import com.example.tutorapp395.interfaces.admin.AdminAnalyticsScreen
import com.example.tutorapp395.interfaces.admin.AdminReportsScreen
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.AdminViewModel
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.ViewAccountsUiEvent
import com.example.tutorapp395.presentation.navigation.common.InboxScreen
import com.example.tutorapp395.presentation.navigation.common.BottomBarItems
import kotlinx.serialization.Serializable

// Admin
@Serializable
object AdminCreateNewAccount

@Composable
fun AdminBottomNavGraph(navController: NavHostController, mainNavController: NavHostController) {
    val adminViewModel: AdminViewModel = hiltViewModel()
    val modifier = Modifier
        .padding(top = 90.dp, bottom = 100.dp)
        .fillMaxSize()
    NavHost(
        navController = navController,
        startDestination = BottomBarItems.Inbox.route
    ) {
        composable(route = BottomBarItems.Inbox.route){
            InboxScreen(navController, mainNavController, modifier)
        }
        composable(route = BottomBarItems.Accounts.route){
            adminViewModel.sendViewUserAccountEvent(event = ViewAccountsUiEvent.ShowAllUserAccounts)
            AdminAccountsScreen(navController, mainNavController, adminViewModel)
        }

        composable(route = BottomBarItems.Analytics.route){
            AdminAnalyticsScreen(modifier)
        }
        composable(route = BottomBarItems.Reports.route){
            AdminReportsScreen(modifier)
        }

    }
}

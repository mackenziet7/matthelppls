package com.example.tutorapp395.interfaces.admin

import android.content.ContentValues.TAG
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tutorapp395.app.admin
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.IconButtonComponent
import com.example.tutorapp395.interfaces.components.LabelTextComponent
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.MediumButtonComponent
import com.example.tutorapp395.interfaces.components.SearchTextFieldComponent
import com.example.tutorapp395.interfaces.components.SubHeaderTextComponent
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.AdminViewModel
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.ViewAccountsUiEvent
import com.example.tutorapp395.presentation.navigation.admin.AdminCreateNewAccount
import com.example.tutorapp395.presentation.theme.ThemeColors

// a sub-main screen that will manage all accounts as an admin
@Composable
fun AdminAccountsScreen(navController: NavController, menuNavController: NavController, adminViewModel: AdminViewModel) {
    val uiState = adminViewModel.viewUserAccountsState.collectAsState().value
    // FilterAdd new Account, Refresh

    if (uiState.isLoading){
        CircularProgressIndicator()
    }
    Box{
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(1000.dp)
                .padding(top = 120.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(40.dp)
                ),

            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(vertical = 20.dp, horizontal = 20.dp),
        ) {
            // Space so that top card is below the search and buttons
            item{
                Spacer(modifier = Modifier.height(100.dp)) // Space before login button
            }
            items(uiState.accounts){ item ->
               // Log.d(TAG, "${uiState.accounts}")
                Box(
                    modifier = Modifier
                        .padding(vertical = 5.dp)
                        .height(120.dp)
                        .fillParentMaxWidth()
                        .shadow(5.dp, RoundedCornerShape(28.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.background)
                        .padding(horizontal = 20.dp)

                ){
                    Column {
                        HeaderTextComponent("${item.firstName} ${item.lastName}", textAlign = TextAlign.Start)
                        SubHeaderTextComponent("@${item.username}")

                    }
                    Row(
                        modifier = Modifier
                            .padding(top = 20.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.End

                    ) {
                        LabelTextComponent("${item.label}")
                    }
                }
                // Space so bottom card is shown
            }
            item{
                Spacer(modifier = Modifier.height(90.dp)) // Space before login button
            }

        }
        Column(
            modifier = Modifier
                .padding(top = 90.dp)
                .padding(horizontal = 20.dp)
        ) {
            Row(
                modifier = Modifier
                    //  .height(50.dp)
                    .shadow(12.dp, shape = RoundedCornerShape(50.dp))
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(50.dp)
                    )
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .padding(bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                SearchTextFieldComponent(
                    "Search",
                    errorStatus = false,
                    icon = Icons.Default.Search,
                    onTextSelected = {})
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButtonComponent(Icons.Rounded.FilterList, "Filter", onButtonClicked = {

                    })
                Spacer(modifier = Modifier.weight(1.0F))

                IconButtonComponent(Icons.Rounded.Add, "Add Account", onButtonClicked = {
                        menuNavController.navigate(route = AdminCreateNewAccount)
                    })
                Spacer(modifier = Modifier.size(20.dp))

                IconButtonComponent(Icons.Rounded.Refresh, "Refresh", onButtonClicked = {
                    adminViewModel.sendViewUserAccountEvent(event = ViewAccountsUiEvent.ShowAllUserAccounts)
                    })



              //  IconButtonComponent(Icons.Rounded.KeyboardArrowUp, "Back On Top")

            }
        }
    }
}

package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.ChatEntity
import com.example.tutorapp395.data.model.Chat
import com.example.tutorapp395.data.model.User

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface ChatDao {
    @Query("SELECT * FROM chat")
    fun getAll(): List<ChatEntity>

    @Insert
    fun insertAll(vararg chat: ChatEntity)

    @Delete
    fun delete(chat: ChatEntity)

    @Update
    fun update(chat: ChatEntity)

    @Query("DELETE FROM chat")
    fun deleteAllValuesInTable()
}
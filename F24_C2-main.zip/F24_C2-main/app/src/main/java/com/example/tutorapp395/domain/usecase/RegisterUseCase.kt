package com.example.tutorapp395.domain.usecase

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.utils.CONNECTION_FAILED
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.UserRepository

class RegisterUseCase(
    private val repository: UserRepository
) {
    suspend operator fun invoke(
        user: User
    ): Result<Any> {
        // Catches for empty inputs
        if (user.username == null) {
            Log.d(TAG, "username empty ${user.username}")
            return Result.Failure(NullPointerException("Username inputted is empty"))
        }

        when (val result = repository.getUserByUsername(user.username)) {
            is Result.Failure -> {
                Log.d(TAG, CONNECTION_FAILED)

                Result.Failure(Exception(CONNECTION_FAILED))
            }

            is Result.Success -> {
                Log.d(TAG, "CONNECT ${result.data}")

                // Username is unique
                if (result.data.isEmpty()) {

                    return when (val result2 = repository.insertUser(user)) {
                        is Result.Failure -> {
                            Log.d(TAG, "CONNECT FAILED IN INSERT USER")

                            Result.Failure(Exception(CONNECTION_FAILED))

                        }
                        is Result.Success -> {
                            Log.d(TAG, "CONNECTED ${result.data}")

                            Result.Success(result2.data)
                        }
                    }
                }
                else {
                    Log.d(TAG, "Existing Username ${result.data}")
                    return Result.Success(UnexpectedResult.ExistingInput) }
            }
        }
        return Result.Failure(Exception())
    }
}



sealed class UnexpectedResult{
    object ExistingInput
}

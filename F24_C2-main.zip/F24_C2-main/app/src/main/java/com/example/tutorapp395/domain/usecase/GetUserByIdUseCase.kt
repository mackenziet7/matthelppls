package com.example.tutorapp395.domain.usecase

import com.example.tutorapp395.domain.repository.UserRepository

class GetUserByIdUseCase(
    private val respository: UserRepository
) {
    suspend operator fun invoke(
        id: String
    ){

    }
}
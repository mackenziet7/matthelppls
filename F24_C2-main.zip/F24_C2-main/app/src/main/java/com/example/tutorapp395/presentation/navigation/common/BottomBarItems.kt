package com.example.tutorapp395.presentation.navigation.common

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.ui.graphics.vector.ImageVector

// contains the buttons and their routes for the admin bottom bar screen
sealed class BottomBarItems (
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val hasNews: Boolean,
    val badgeCount: Int? = null
    ) {
        object Inbox : BottomBarItems(
            route = "inbox",
            title = "Inbox",
            selectedIcon = Icons.Filled.Inbox,
            unselectedIcon = Icons.Outlined.Inbox,
            hasNews = false,
            badgeCount = 34 // TODO: this is a temp value, change to dynamic
        )
        object Calendar : BottomBarItems(
            route = "calendar",
            title = "calendar",
            selectedIcon = Icons.Filled.CalendarMonth,
            unselectedIcon = Icons.Outlined.CalendarMonth,
            hasNews = false,
        )
        object Sessions : BottomBarItems(
            route = "sessions",
            title = "Sessions",
            selectedIcon = Icons.Filled.CollectionsBookmark,
            unselectedIcon = Icons.Outlined.CollectionsBookmark,
            hasNews = false,
        )
        object Home : BottomBarItems(
            route = "home",
            title = "Home",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            hasNews = true,
        )

        object Accounts : BottomBarItems(
            route = "accounts",
            title = "Accounts",
            selectedIcon = Icons.Filled.Groups,
            unselectedIcon = Icons.Outlined.Groups,
            hasNews = false,
        )
        object Analytics : BottomBarItems(
            route = "analytics",
            title = "Analytics",
            selectedIcon = Icons.Filled.Analytics,
            unselectedIcon = Icons.Outlined.Analytics,
            hasNews = false,
        )
        object Reports : BottomBarItems(
            route = "reports",
            title = "Reports",
            selectedIcon = Icons.Filled.Feedback,
            unselectedIcon = Icons.Outlined.Feedback,
            hasNews = true,
        )
}

package com.example.tutorapp395.presentation.uistate

data class SessionsUIState(
    val sessionsList: List<SessionItem>
)

data class SessionItem(
    val userId: String,
    val startTime: String,
    val endTime: String,
    val label: String,
    val cancelDate: String,
    val firstName: String,
    val lastName: String
)
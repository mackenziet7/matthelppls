
package com.example.tutorapp395.presentation.interfaces.login

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.app.AdminMainActivity
import com.example.tutorapp395.app.StudentMainActivity
import com.example.tutorapp395.presentation.navigation.common.CreateAccount
import com.example.tutorapp395.presentation.navigation.common.LoginNavGraph
import com.example.tutorapp395.presentation.theme.TutorApp395Theme
import androidx.compose.ui.unit.sp
import com.example.tutorapp395.app.TutorMainActivity
import com.example.tutorapp395.interfaces.components.CheckboxComponent
import com.example.tutorapp395.interfaces.components.HeaderTextComponent
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.PasswordFieldComponent
import com.example.tutorapp395.interfaces.components.TextFieldComponent
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginUiEvent
import com.example.tutorapp395.presentation.interfaces.login.viewmodel.LoginViewModel
import kotlin.math.log

/*
* This activity was made using a tutorial from WhiteBatCodes
* https://www.youtube.com/watch?v=t5O3omAI-6c
* */

// Main Composable function for the login form.
@Composable
fun LoginForm(navController: NavController, loginViewModel: LoginViewModel) {
    val uiState = loginViewModel.loginState.collectAsState().value
    val context = LocalContext.current // Gets the current context

    Surface(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Holds the login credentials state

        Column(
            verticalArrangement = Arrangement.Center,
            //horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .size(30.dp)
                .padding(horizontal = 45.dp) // Adds padding to the sides

        ) {
            HeaderTextComponent("Login")

            // Login input field
            TextFieldComponent(
                "Username",
                Icons.Default.AccountCircle,
                onTextSelected = {loginViewModel.sendLoginEvent(event = LoginUiEvent.UsernameChanged(it))},
                errorStatus = uiState.usernameError,
            )
            // Password input field
            PasswordFieldComponent(
                "Password",
                onTextSelected = {loginViewModel.sendLoginEvent(event = LoginUiEvent.PasswordChanged(it))},
                errorStatus = uiState.passwordError,
                )

            if (uiState.wrongInputError){
                Text(text ="*Invalid username/password",
                    color = Color.Red,
                    fontSize = 12.sp
                )
            }

            // Checkbox for "Remember Me" functionality
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CheckboxComponent("Remember Me",
                    onCheckedChanged = {loginViewModel.sendLoginEvent(event = LoginUiEvent.RememberChanged(it))})
            }
            Spacer(modifier = Modifier.height(20.dp)) // Space before login button
            // Login button
            // Register Account Button
            LargeButtonComponent("Login",
                onButtonClicked = {
                    loginViewModel.sendLoginEvent(event = LoginUiEvent.LoginButtonClicked)
                                  },
                enabledStatus = uiState.loginButtonEnabled
            )

            if (uiState.loginSuccessful){ // handle null cases
                uiState.retrievedUser.userId?.let {
                    uiState.retrievedUser.isAdmin?.let { it1 ->
                        uiState.retrievedUser.firstName?.let { it2 ->
                            uiState.retrievedUser.isTutor?.let { it3 ->
                                loginViewModel.login(
                                    userId = it,
                                    isAdmin = it1,
                                    isTutor = it3,
                                    name = it2,
                                    context, false
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp)) // Space before login button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text(text = "Don't have an account? ",
                    color = MaterialTheme.colorScheme.onBackground)
                Text(
                    text = "Sign Up",
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable {
                            loginViewModel.sendLoginEvent(LoginUiEvent.Reset)
                            navController.navigate(route = CreateAccount)
                        })
            }
        }
    }
    if (uiState.isLoading){
        Log.d(TAG, "LOADING")
        CircularProgressIndicator()
    }

}

// Previews for the LoginForm composable
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun GreetingPreview() {
    TutorApp395Theme {
        val navController = rememberNavController()
        LoginNavGraph(navController) // Preview of the LoginForm
    }
}

package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.RefundedSession
import java.util.UUID

@Entity(tableName = "refundedSession", foreignKeys = [ForeignKey(
    entity = SessionEntity::class,
    parentColumns = arrayOf("sessionId"),
    childColumns = arrayOf("cancelledSessionId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])data class RefundedSessionEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val cancelledSessionId: String, //PK, FK -> Session
    @ColumnInfo(index = true)
    val refundCost: Float,
    @ColumnInfo(index = true)
    val refundZonedDateTime: String,
    @ColumnInfo(index = true)
    val refundStatus: String,
)

fun RefundedSessionEntity.asExternalModel() = RefundedSession(
    cancelledSessionId = cancelledSessionId, //PK, FK -> Session
    refundCost = refundCost,
    refundZonedDateTime =refundZonedDateTime,
    refundStatus = refundStatus,
)
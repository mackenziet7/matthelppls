package com.example.tutorapp395.data.model

import android.net.Network
import com.example.tutorapp395.data.network.models.NetworkChat

data class Chat(
    val chatId: String? = null, // PK
    val userOneId: String? = null,
    val userTwoId: String? = null,
    val lastMessage: String? = null,
    val lastDateTime: String? = null,
    val hasSeen: Boolean? = null
)

fun Chat.asNetworkModel() = NetworkChat(
    chatId = chatId,
    userOneId = userOneId,
    userTwoId = userTwoId,
    lastMessage = lastMessage,
    lastDateTime = lastDateTime,
    hasSeen = hasSeen,
)
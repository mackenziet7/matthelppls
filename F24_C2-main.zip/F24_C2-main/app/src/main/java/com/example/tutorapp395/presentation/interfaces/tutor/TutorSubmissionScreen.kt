package com.example.tutorapp395.presentation.interfaces.tutor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

import com.example.tutorapp395.domain.CalendarUseCase
import com.example.tutorapp395.interfaces.components.CalendarHeader
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import com.example.tutorapp395.presentation.navigation.common.TutorUnavailabilitySubmission
import com.example.tutorapp395.presentation.uistate.CalendarUiState
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth

// Temp class to hold unavailability
data class UnavailableDates(
    val startDate: LocalDate,
    val endDate: LocalDate,
    val startTime: LocalTime = LocalTime.MIN, // Default start time set to 12:00 AM
    val endTime: LocalTime = LocalTime.MAX // Default end time set to 11:59 PM
)
// Sample unavailable dates
public val allUnavailabilityDates = listOf(
    UnavailableDates(LocalDate.of(2024, 11, 3), LocalDate.of(2024, 11, 3)),
    UnavailableDates(LocalDate.of(2024, 11, 9), LocalDate.of(2024, 11, 12+1), LocalTime.of(10, 0), LocalTime.of(14, 0))
)

@Composable
fun TutorSubmissionScreen(navController: NavController) {
    // Column Composable
    Box {
        // Top Bar
        SubTopBar(navController, "My Availability Submission")

        // Content
        Column(
            modifier = Modifier
                .padding(top = 90.dp)
        ) {
            Calendar()
            TutorWeeklyAvailabilityComponent(navController)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate(route = TutorUnavailabilitySubmission) }
                    .background(color = MaterialTheme.colorScheme.primary)
                    .padding(vertical = 20.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Unavailable Dates")
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = null,
                    modifier = Modifier
                        .padding(start = 16.dp, end = 8.dp)
                        .size(27.dp)
                )
            }
            TutorUnavailableComponent(navController, unavailabilityDates = allUnavailabilityDates)

        }
    }
}

@Composable
fun Calendar(onSelectedDateChange: (LocalDate) -> Unit = {}) {
    val dataSource = CalendarUseCase()
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var calendarUiModel by remember { mutableStateOf(dataSource.getMonthData(currentMonth)) }


    // Get the current date
    val currentDate = LocalDate.now()

    // Filter the unavailable dates to include future dates
    val futureUnavailableDays = allUnavailabilityDates.filter { it.endDate.isEqual(currentDate) || it.endDate.isAfter(currentDate) }

    // State variable to toggle past events visibility
    var showPastUnavailableDays by remember { mutableStateOf(false) }

    // Combine future and past unavailable days based on the toggle
    val displayedUnavailableDays = if (showPastUnavailableDays) {
        allUnavailabilityDates // Show all unavailable days
    } else {
        futureUnavailableDays // Show only future unavailable days
    }

    CalendarHeader(
        currentMonth = currentMonth,
        onPrevClickListener = {
            currentMonth = currentMonth.minusMonths(1)
            calendarUiModel = dataSource.getMonthData(currentMonth)
        },
        onNextClickListener = {
            currentMonth = currentMonth.plusMonths(1)
            calendarUiModel = dataSource.getMonthData(currentMonth)
        }
    )

    // Content
    UnavailabilityCalendarContent(
        data = calendarUiModel,
        unavailableDays = displayedUnavailableDays, // Pass the filtered unavailable days
        onDateClickListener = { date ->
            calendarUiModel = calendarUiModel.copy(
                selectedDate = date,
                visibleDates = calendarUiModel.visibleDates.map {
                    it.copy(isSelected = it.date.isEqual(date.date))
                }
            )
            onSelectedDateChange(date.date)
        }
    )
}

@Composable
fun UnavailabilityCalendarContent(
    data: CalendarUiState,
    unavailableDays: List<UnavailableDates>, // Use the UnavailabileDates list
    onDateClickListener: (CalendarUiState.Date) -> Unit,
) {
    val weekdays = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    Column {
        // Weekday Header remains the same...

        // Calculate how many empty boxes we need at the start of the calendar
        val firstDayOfWeek = data.visibleDates.first().date.dayOfWeek.value % 7

        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            contentPadding = PaddingValues(8.dp)
        ) {
            // Add empty boxes for the preceding days from the previous month
            items(firstDayOfWeek) {
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .aspectRatio(1f) // Maintain a square aspect ratio
                ) {
                    // Leave this box empty to represent the blank space
                }
            }

            // Now, display the actual dates for the current month
            items(data.visibleDates) { date ->
                ContentItem(
                    date = date,
                    // Check if this date has any associated UnavailabileDates
                    unavailableDays = unavailableDays.filter {
                        it.startDate.isEqual(date.date) || (date.date.isAfter(it.startDate) && date.date.isBefore(it.endDate))
                    },
                    onClickListener = onDateClickListener
                )
            }
        }
    }
}


@Composable
fun ContentItem(
    date: CalendarUiState.Date,
    unavailableDays: List<UnavailableDates>, // Use UnavailabileDates instead of events
    onClickListener: (CalendarUiState.Date) -> Unit,
) {
    // Access the actual LocalDate from the CalendarUiState.Date object
    val localDate = date.date // Ensure 'date' has a property 'date' of type LocalDate

    // Check if there are any unavailable days for this date
    val isUnavailable = unavailableDays.any {
        localDate.isEqual(it.startDate) ||
                (localDate.isAfter(it.startDate) && localDate.isBefore(it.endDate))
    }

    Card(
        modifier = Modifier
            .padding(4.dp)
            .aspectRatio(1f)
            .clickable { onClickListener(date) },
        colors = CardDefaults.cardColors(
            containerColor = when {
                isUnavailable -> Color(0xFFB71C1C) // Red color for unavailable days
                date.isSelected -> MaterialTheme.colorScheme.primary
                date.isToday -> MaterialTheme.colorScheme.secondary
                else -> MaterialTheme.colorScheme.surface
            }
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = localDate.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = if (date.isSelected || date.isToday || isUnavailable) Color.White else Color.Unspecified
            )
        }
    }
}

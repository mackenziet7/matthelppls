package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Payments
import java.util.UUID

@Entity(tableName = "payments")
data class PaymentsEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val paymentsId: String, // PK
    @ColumnInfo(index = true)
    val hourlyRate: Float,
    @ColumnInfo(index = true)
    val tutorFee: Float,
    @ColumnInfo(index = true)
    val studentFee: Float,
    @ColumnInfo(index = true)
    val announcementDateTime: String,
    @ColumnInfo(index = true)
    val changeDateTime: String,
    @ColumnInfo(index = true)
    val createdAt: String
)

fun PaymentsEntity.asExternalModel() = Payments(
    paymentsId = paymentsId, // PK
    hourlyRate = hourlyRate,
    tutorFee = tutorFee,
    studentFee = studentFee,
    announcementDateTime = announcementDateTime,
    changeDateTime = changeDateTime,
    createdAt = createdAt
)
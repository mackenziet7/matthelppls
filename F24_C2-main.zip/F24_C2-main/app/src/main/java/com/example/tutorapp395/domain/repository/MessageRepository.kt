package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.Message
import com.example.tutorapp395.data.model.Session
import com.example.tutorapp395.data.model.SessionRequest
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkMessage
import com.example.tutorapp395.data.network.models.NetworkSession
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface MessageRepository {
    fun getMessages(): Flow<List<NetworkMessage>>

    suspend fun insertMessage(message: Message): Result<String>

    suspend fun getAllMessagesByUserId(): Result<List<NetworkMessage?>>

    suspend fun deleteMessage(id: String): Result<Unit>

    suspend fun updateMessage(message: Message): Result<Unit>
}

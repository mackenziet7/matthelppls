package com.example.tutorapp395.presentation.interfaces.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.interfaces.components.LargeButtonComponent
import com.example.tutorapp395.interfaces.components.PasswordFieldComponent
import com.example.tutorapp395.interfaces.components.TextFieldComponent
import com.example.tutorapp395.presentation.interfaces.components.DoubleRadioButtonComponent
import com.example.tutorapp395.presentation.navigation.common.SubTopBar
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.AdminViewModel
import com.example.tutorapp395.presentation.interfaces.admin.viewmodel.CreateAccountUiEvent

@Composable
fun AdminSetupNewAccountScreen(navController: NavController, adminViewModel: AdminViewModel, modifier: Modifier){
    val uiState = adminViewModel.createNewAccountState.collectAsState().value
    val context = LocalContext.current // Gets the current context

    SubTopBar(
        navController,
        "Create New Account",
        onClick = {
            adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.Reset)
        })

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 45.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Select:", color = MaterialTheme.colorScheme.onBackground)
            DoubleRadioButtonComponent(
                "Admin", "Tutor",
                onButtonSelected = {
                adminViewModel.sendCreateAccountEvent(event = CreateAccountUiEvent.AdminTutorChanged(it))}
                )
        }

        TextFieldComponent(
            "First Name",
            Icons.Default.Person,
            onTextSelected = { adminViewModel.sendCreateAccountEvent(event = CreateAccountUiEvent.FirstNameChanged(it)) },
            uiState.firstNameError
        )
        TextFieldComponent(
            "Last Name",
            Icons.Default.Person,
            onTextSelected = {adminViewModel.sendCreateAccountEvent(event = CreateAccountUiEvent.LastNameChanged(it)) },
            uiState.lastNameError
        )

        TextFieldComponent(
            "Email",
            Icons.Default.Email,
            onTextSelected = {
                adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.EmailChanged(it)) },
            uiState.emailError
        )
        // Account
        TextFieldComponent(
            "Username",
            Icons.Default.AccountCircle,
            onTextSelected = {
                adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.UsernameChanged(it)) },
            errorStatus = uiState.usernameError || uiState.existingUsernameError
        )
        if  (uiState.usernameError){
            Text(text ="Username length must be at least 3 characters long",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        if  (uiState.existingUsernameError){
            Text(text ="Username already exists",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        // Passwords
        PasswordFieldComponent(
            "Password",
            onTextSelected = {
                adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.PasswordChanged(it)) },
            uiState.passwordError || uiState.passwordMismatchError
        )
        PasswordFieldComponent(
            "Re-enter Password",
            onTextSelected = {
                adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.Password2Changed(it)) },
            uiState.passwordError || uiState.passwordMismatchError

        )

        //TODO: REFACTOR ERROR TEXTS
        if  (uiState.passwordMismatchError){
            Text(text ="*Passwords do not match",
                color = Color.Red,
                fontSize = 12.sp
            )
        }
        if (uiState.passwordError){
            Text(text ="*Password length must be at least 4 character long",
                color = Color.Red,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp)) // Space before login button


        // Register Account Button
        LargeButtonComponent("Create New Account",
            onButtonClicked = {
                adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.CreateAccountButtonClicked)
                              },
            enabledStatus = uiState.createAccountButtonEnabled
        )

        if (uiState.registerSuccessful){
            Toast.makeText(context, "Account created!", Toast.LENGTH_SHORT).show() // Error message
            adminViewModel.sendCreateAccountEvent(CreateAccountUiEvent.Reset)
            navController.navigateUp()

        }
        Spacer(modifier = Modifier.height(40.dp)) // Space before login button

    }

}
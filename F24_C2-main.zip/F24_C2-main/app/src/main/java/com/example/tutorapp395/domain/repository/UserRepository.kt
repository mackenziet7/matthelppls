package com.example.tutorapp395.domain.repository

import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.data.network.models.NetworkUser
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import com.example.tutorapp395.domain.Result
import com.google.firebase.firestore.DocumentSnapshot

interface UserRepository {
    fun getUsers(): Flow<List<User>>

    suspend fun insertUser(user: User): Result<String>

    suspend fun getAllUsers(): Result<List<NetworkUser?>>
    suspend fun getUserById(id: String):  Result<List<NetworkUser?>>
    suspend fun getUserByUsername(username: String):  Result<List<NetworkUser?>>

    suspend fun deleteUser(id: String): Result<Unit>

    suspend fun updateUser(user: User): Result<Unit>
}
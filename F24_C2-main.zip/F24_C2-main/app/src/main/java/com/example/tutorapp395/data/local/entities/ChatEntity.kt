package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.Chat
import java.util.UUID

@Entity(tableName = "chat", foreignKeys = [ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userOneId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
),ForeignKey(
    entity = UserEntity::class,
    parentColumns = arrayOf("userId"),
    childColumns = arrayOf("userTwoId"),
    onDelete = ForeignKey.CASCADE,
    onUpdate = ForeignKey.CASCADE
)])data class ChatEntity(
    @PrimaryKey
    val chatId: String, //
    @ColumnInfo(index = true)
    val userOneId: String, //FK
    @ColumnInfo(index = true)
    val userTwoId: String, //FK
    @ColumnInfo(index = true)
    val lastMessage: String,
    @ColumnInfo(index = true)
    val lastDateTime: String,
)

fun ChatEntity.asExternalModel() = Chat(
    chatId = chatId,
    userOneId = userOneId,
    userTwoId = userTwoId,
    lastMessage = lastMessage,
    lastDateTime = lastDateTime
)
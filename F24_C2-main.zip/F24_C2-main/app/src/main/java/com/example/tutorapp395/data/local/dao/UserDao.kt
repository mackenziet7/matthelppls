package com.example.tutorapp395.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.tutorapp395.data.local.entities.UserEntity
import com.example.tutorapp395.data.model.User
import kotlinx.coroutines.flow.Flow

// Resource Used: https://developer.android.com/training/data-storage/room
@Dao
interface UserDao {
    @Query("SELECT * FROM user")
    fun getAll(): Flow<List<UserEntity>>


    @Query("SELECT * FROM user WHERE username = :username LIMIT 1")
    suspend fun findByUsername(username: String): UserEntity?

    @Query("SELECT * FROM user WHERE userId = :userId LIMIT 1")
    suspend fun findByUserId(userId: String): UserEntity?

    @Insert
    suspend fun insertAll(vararg users: UserEntity)

    @Delete
    suspend fun delete(user: UserEntity)

    @Update
    suspend fun update(user: UserEntity)

    @Query("DELETE FROM user")
    suspend fun deleteAllValuesInTable()
}
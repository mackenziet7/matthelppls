package com.example.tutorapp395.domain.usecase

import android.content.ContentValues.TAG
import android.util.Log
import com.example.tutorapp395.data.model.User
import com.example.tutorapp395.domain.Result
import com.example.tutorapp395.domain.repository.SessionRepository
import com.example.tutorapp395.domain.repository.SessionRequestRepository
import com.example.tutorapp395.domain.repository.StudentAvailabilityRepository
import com.example.tutorapp395.domain.repository.UserRepository
import com.example.tutorapp395.utils.CONNECTION_FAILED

class FindATutorUseCase(
    private val sessionRequestRepository: SessionRequestRepository,
    private val sessionRepository: SessionRepository,
    private val studentAvailabilityRepository: StudentAvailabilityRepository
) {
    suspend operator fun invoke(
        user: User
    ): Result<Any> {
        // Catches for empty inputs
        return Result.Failure(Exception("Failure"))
    }
}

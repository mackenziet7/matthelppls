package com.example.tutorapp395.presentation.uistate

import java.time.LocalDate
import java.time.format.DateTimeFormatter.ofPattern

data class CalendarUiState(
    val selectedDate: Date,
    val visibleDates: List<Date>
) {

    val startDate: Date = visibleDates.first()
    val endDate: Date = visibleDates.last()

    data class Date(
        val date: LocalDate,
        val isSelected: Boolean,
        val isToday: Boolean
    ) {
        val day: String = date.format(ofPattern("E"))
    }
}
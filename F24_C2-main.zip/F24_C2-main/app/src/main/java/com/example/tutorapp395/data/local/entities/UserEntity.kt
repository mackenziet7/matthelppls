package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.User
import java.util.UUID

// resource used: https://developer.android.com/topic/architecture/data-layer/offline-first
@Entity(tableName = "user")
data class UserEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val userId: String,
    @ColumnInfo(index = true)
    val username: String,
    @ColumnInfo(index = true)
    val email: String,
    @ColumnInfo(index = true)
    val password: String,
    @ColumnInfo(index = true)
    val isDeactivated: Boolean,
    @ColumnInfo(index = true)
    val firstName: String,
    @ColumnInfo(index = true)
    val lastName: String,
    @ColumnInfo(index = true)
    val phoneNumber: String,
    @ColumnInfo(index = true)
    val dateOfBirth: String,
    @ColumnInfo(index = true)
    val isAdmin: Boolean,
    @ColumnInfo(index = true)
    val isTutor: Boolean,
    @ColumnInfo(index = true)
    val timezone: String,
    @ColumnInfo(index = true)
    val acceptedTC: String,
    @ColumnInfo(index = true)
    val completedOnboarding: String,
    @ColumnInfo(index = true)
    val createdAt: String,
    @ColumnInfo(index = true)
    val modifiedAt: String,
)

/**
 * Converts local model to external model for use by layers external to the data layer
 */
//fun UserEntity.asExternalModel() = User(
//    userId = userId,
//    username = username,
//    email = email,
//    password = password,
//    isDeactivated = isDeactivated,
//    firstName = firstName,
//    lastName = lastName,
//    phoneNumber = phoneNumber,
//    dateOfBirth = dateOfBirth,
//    isAdmin = isAdmin,
//    isTutor = isTutor,
//    timezone = timezone,
//    acceptedTC = acceptedTC,
//    completedOnboarding = completedOnboarding,
//    createdAt = null,
//    modifiedAt = null
//)
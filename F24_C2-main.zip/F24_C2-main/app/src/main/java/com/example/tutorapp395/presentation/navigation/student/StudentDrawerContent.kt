package com.example.tutorapp395.presentation.navigation.student

import android.app.Activity
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.automirrored.rounded.Help
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwitchAccount
import androidx.compose.ui.modifier.modifierLocalMapOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.tutorapp395.app.LoginActivity
import com.example.tutorapp395.app.TutorMainActivity
import com.example.tutorapp395.presentation.navigation.common.Profile
import com.example.tutorapp395.presentation.navigation.common.StudentFindATutor

@Composable
fun StudentDrawerContent(MainNavController: NavController){
    val context = LocalContext.current // Gets the current context

    Text(
        text = "Tutor App",
        fontSize = 24.sp,
        modifier = Modifier.padding(16.dp)
    )
    Column()
    {

        HorizontalDivider( modifier = Modifier.padding(horizontal = 20.dp))
        NavigationDrawerItem(
            icon = {
                Icon(
                    imageVector = Icons.Rounded.AccountCircle,
                    contentDescription = "My Profile",
                    modifier = Modifier
                        .size(27.dp))

            },
            label = {
                Text(
                    text = "My Profile",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            },
            selected = false,
            onClick = {MainNavController.navigate(route = Profile)}
        )
        NavigationDrawerItem(
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = "Find A Tutor",
                    modifier = Modifier
                        .size(27.dp))

            },
            label = {
                Text(
                    text = "Find A Tutor",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            },
            selected = false,
            onClick = {MainNavController.navigate(route = StudentFindATutor)}
        )
        Spacer(modifier = Modifier.weight(0.1f)) // Space before login button
        HorizontalDivider( modifier = Modifier.padding(horizontal = 20.dp))
        NavigationDrawerItem(
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Settings",
                    modifier = Modifier
                        .size(27.dp))

            },
            label = {
                Text(
                    text = "Settings",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            },
            selected = false,
            onClick = {
            }
        )
        NavigationDrawerItem(
            icon = {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Help,
                    contentDescription = "Help",
                    modifier = Modifier
                        .size(27.dp))

            },
            label = {
                Text(
                    text = "Help",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            },
            selected = false,
            onClick = {
            }
        )

        NavigationDrawerItem(
            icon = {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Logout,
                    contentDescription = "Log Out",
                    modifier = Modifier
                        .size(27.dp))

            },
            label = {
                Text(
                    text = "Log Out",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(16.dp)
                )
            },
            selected = false,
            onClick = {
                context.startActivity(Intent(context, LoginActivity::class.java))
                Toast.makeText(context, "Logging Out", Toast.LENGTH_SHORT).show() // Success message
                (context as Activity).finish() // Closes the login activity
            }
        )
        Spacer(modifier = Modifier.height(50.dp)) // Space before login button
    }
}


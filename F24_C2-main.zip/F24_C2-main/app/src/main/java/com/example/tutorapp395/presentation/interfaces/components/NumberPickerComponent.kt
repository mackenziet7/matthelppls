package com.example.tutorapp395.presentation.interfaces.components

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tutorapp395.interfaces.components.IconButtonComponent

@Composable
fun NumberPickerComponent(title: String) {
    val number = remember {mutableIntStateOf(0)}

    Row(
        modifier = Modifier
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            textAlign = TextAlign.Center,
        //    fontSize = 20.sp,
        //    modifier = Modifier.padding(15.dp)
        )
        Spacer(modifier = Modifier.weight(1.0F))
        IconButtonComponent(
            Icons.Default.Remove,
            "",
            onButtonClicked = { number.intValue -= 1 })
        Text(
            text = number.intValue.toString(),
            textAlign = TextAlign.Center,
            fontSize = 20.sp,
            modifier = Modifier.padding(15.dp)
        )
        IconButtonComponent(
            Icons.Default.Add, "",
            onButtonClicked = {  number.intValue += 1 }
        )
    }

}
package com.example.tutorapp395.data.model

import android.net.Network
import com.example.tutorapp395.data.network.models.NetworkSessionRequest
import java.util.Date

data class SessionRequest(
    val sessionRequestId: String? = null, // PK
    val requestDateTime: String? = null,
    val acceptDateTime: String? = null,
    val confirmDateTime: String? = null,
    val startDateTime: String? = null,
    val endDateTime: String? = null,
    val totalDays: Int? = null,
    val totalHours: Int? = null,
    val totalCost: Float? = null,
    val gradeLevel: String,
    val subject: String? = null, // FK
    val chatId: String,

    val tutorUserId: String? = null, // FK - userId
    val studentUserId: String? = null, // FK - userId

    val studentColorLabel: String,
    val tutorColorLabel: String,
)

fun SessionRequest.asNetworkModel() = NetworkSessionRequest(
    sessionRequestId = sessionRequestId,
    requestDateTime = requestDateTime,
    acceptDateTime = acceptDateTime,
    confirmDateTime = confirmDateTime,
    startDateTime = startDateTime,
    endDateTime = endDateTime,
    totalDays = totalDays,
    totalHours = totalHours,
    totalCost = totalCost,
    gradeLevel = gradeLevel,
    subject = subject,
    chatId = chatId,
    tutorUserId = tutorUserId,
    studentUserId = studentUserId,
    studentColorLabel = studentColorLabel,
    tutorColorLabel = tutorColorLabel
)
package com.example.tutorapp395.interfaces.student

import android.annotation.SuppressLint
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.tutorapp395.presentation.navigation.common.BottomBar
import com.example.tutorapp395.presentation.navigation.common.BottomBarItems
import com.example.tutorapp395.presentation.navigation.student.StudentDrawerContent
import com.example.tutorapp395.presentation.navigation.common.BottomNavGraph
import com.example.tutorapp395.presentation.navigation.common.TopBar
import kotlinx.coroutines.launch

// The main Student screen that holds the navigation bars
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun StudentMainScreen(mainNavController: NavController) { // Main Student Screen
    val navController = rememberNavController()
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(
        state = rememberTopAppBarState()
    )
    val drawerState = rememberDrawerState(
        initialValue = DrawerValue.Closed
    )
    val scope = rememberCoroutineScope()

    val screens = listOf(
        BottomBarItems.Home,
        BottomBarItems.Inbox,
        BottomBarItems.Calendar,
        BottomBarItems.Sessions
    )
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                StudentDrawerContent(mainNavController)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopBar(
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.apply {
                                if (isClosed) open() else close()
                            }
                        }
                    }
                )
            },

            bottomBar = { BottomBar(navController = navController, screens) }
        ) { //padding ->
            BottomNavGraph(navController = navController, mainNavController)
        }
    }
}


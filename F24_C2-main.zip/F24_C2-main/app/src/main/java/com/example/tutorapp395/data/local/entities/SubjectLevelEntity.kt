package com.example.tutorapp395.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.tutorapp395.data.model.SubjectLevel
import com.example.tutorapp395.data.model.TutorAvailability

@Entity(tableName = "subjectLevel",)
data class SubjectLevelEntity(
    @PrimaryKey
    @ColumnInfo(index = true)
    val subjectLevelId: String, // PK
    @ColumnInfo(index = true)
    val subject: String,
    @ColumnInfo(index = true)
    val gradeLevels: String,
    @ColumnInfo(index = true)
    val tutorAvailabilityId: String // FK
)

//fun SubjectLevelEntity.asExternalModel() = SubjectLevel(
//    subjectLevelId = subjectLevelId, // PK
//    subject = subject,
//    tutorAvailabilityId = tutorAvailabilityId,
//    gradeLevels = gradeLevels,
//)

package com.example.tutorapp395.utils

const val COLLECTION_PATH_USER = "user"
const val COLLECTION_PATH_QUALIFICATIONS = "qualifications"
const val COLLECTION_PATH_STUDENT_AVAILABILITY = "studentAvailability"
const val COLLECTION_PATH_SESSION_REQUEST = "sessionRequest"
const val COLLECTION_PATH_SESSION = "user"
const val COLLECTION_PATH_SUBJECT_LEVEL = "subjectLevel"
const val COLLECTION_PATH_CHAT = "chat"
const val COLLECTION_PATH_MESSAGE = "message"

const val COLLECTION_PATH_adminBan = "adminBan"
const val CONNECTION_FAILED = "Error: Please check your internet connection and try again."

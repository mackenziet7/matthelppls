package com.example.tutorapp395.domain

data class SubjectsAndGradeLevels(
    val subjects: List<String> = listOf(
        "Math",
        "Science",
        "English",
        "Social Studies",
    ),
    val gradeLevels: List<String> = listOf(
        "Nursery/Kindergarten",
        "1-3",
        "4-6",
        "7-9",
        "10-12",
        "University/College"
    )
)